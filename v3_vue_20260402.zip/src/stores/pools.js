import { defineStore } from 'pinia'
import { ref, computed } from 'vue'
import poolsData from '@data/pools.json'
import { poolsApi } from '../api/pools'
import { useVmsStore } from './vms'

const USE_MOCK = import.meta.env.VITE_USE_MOCK !== 'false'

export const usePoolsStore = defineStore('pools', () => {
  const pools   = ref([])
  const loading = ref(false)
  const error   = ref(null)

  const siteNames = {
    'tp-main': '台北主中心',
    'tc-dr':   '台中異備',
    'e7-main': '東七',
    'tw-main': '台灣',
  }

  async function init() {
    if (pools.value.length) return
    loading.value = true
    error.value   = null
    try {
      pools.value = USE_MOCK ? poolsData : await poolsApi.list()
    } catch (e) {
      error.value = e.message
    } finally {
      loading.value = false
    }
  }

  // 計算每個 pool 的 cpu/mem/disk used（由 vms 加總）
  const poolsWithUsed = computed(() => {
    const vmsStore = useVmsStore()
    return pools.value.map(pool => {
      const poolVms   = vmsStore.vms.filter(vm => vm.pool_id === pool.id)
      const cpu_used  = poolVms.reduce((s, v) => s + (v.vcpu   ?? 0), 0)
      const mem_used  = poolVms.reduce((s, v) => s + (v.ram_gb  ?? 0), 0)
      const disk_used = poolVms.reduce((s, v) => s + (v.disk_gb ?? 0), 0)
      return {
        ...pool,
        siteName: siteNames[pool.site_id] ?? pool.site_id,
        cpu:  { t: pool.cpu_total,      u: cpu_used  },
        mem:  { t: pool.mem_total_gb,   u: mem_used  },
        disk: { t: pool.disk_total_tb,  u: disk_used },
      }
    })
  })

  async function addPool(data) {
    const created = USE_MOCK ? data : await poolsApi.create(data)
    pools.value.push({ ...created, status: created.status ?? 'active' })
  }

  async function updatePool(data) {
    if (!USE_MOCK) await poolsApi.update(data.id, data)
    const i = pools.value.findIndex(p => p.id === data.id)
    if (i !== -1) pools.value[i] = { ...pools.value[i], ...data }
  }

  async function toggleStatus(id) {
    if (!USE_MOCK) await poolsApi.toggleStatus(id)
    const p = pools.value.find(p => p.id === id)
    if (p) p.status = p.status === 'active' ? 'inactive' : 'active'
  }

  return { pools, loading, error, siteNames, poolsWithUsed, init, addPool, updatePool, toggleStatus }
})
