import { ref } from 'vue'

// 單例模式：Promise-based confirm dialog
const visible = ref(false)
const title   = ref('')
const message = ref('')
let _resolve  = null

export function useConfirm() {
  function confirm(t, m = '') {
    title.value   = t
    message.value = m
    visible.value = true
    return new Promise(resolve => { _resolve = resolve })
  }
  function ok()     { visible.value = false; _resolve?.(true)  }
  function cancel() { visible.value = false; _resolve?.(false) }
  return { visible, title, message, confirm, ok, cancel }
}
