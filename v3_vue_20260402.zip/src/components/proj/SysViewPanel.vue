<template>
  <div>
    <!-- System selector grid -->
    <div class="grid gap-2.5 mb-5" style="grid-template-columns: repeat(auto-fill, minmax(150px, 1fr))">
      <div
        v-for="(sd, sysName) in sysView" :key="sysName"
        class="bg-white border border-bord rounded-[8px] p-3.5 cursor-pointer text-center transition-all shadow-sm hover:-translate-y-0.5 hover:border-or hover:shadow-md"
        :class="selectedSys === sysName ? 'border-or bg-or-l' : ''"
        @click="selectedSys = sysName"
      >
        <div class="text-[22px] mb-1.5">{{ sd.icon }}</div>
        <div class="text-[14px] font-bold text-ink">{{ sysName }}</div>
        <div class="text-[11px] text-ink-4 font-mono mt-0.5">{{ sd.pools.length }} pools</div>
      </div>
      <div v-if="!Object.keys(sysView).length" class="col-span-full text-xs text-ink-4 py-8 text-center">
        此專案尚無系統資源
      </div>
    </div>

    <!-- Pools by cloud for selected system -->
    <div v-if="selectedSys && sysView[selectedSys]" class="grid gap-3" style="grid-template-columns: repeat(auto-fill, minmax(270px, 1fr))">
      <div
        v-for="(cd, ci) in poolsByCloud" :key="cd.label"
        class="bg-white border border-bord rounded-[8px] overflow-hidden shadow-sm"
        :style="{ animationDelay: ci * 60 + 'ms' }"
      >
        <!-- Cloud header -->
        <div class="flex items-center gap-2 px-3 py-2.5 border-b border-bord bg-surf-2">
          <div class="w-2 h-2 rounded-[2px]" :style="{ background: cd.color }" />
          <span class="text-[14px] font-bold">{{ cd.label }}</span>
          <span class="ml-auto text-[10px] text-ink-4">{{ cd.rows.length }} pools</span>
        </div>

        <!-- Pool rows -->
        <div class="p-3 flex flex-col gap-1.5">
          <div
            v-for="pool in cd.rows" :key="pool.id"
            class="flex items-center gap-2 px-3 py-2.5 bg-surf-2 border border-bord rounded-[5px] text-[13px]"
          >
            <span
              class="font-mono text-[11px] font-semibold px-[7px] py-[3px] rounded-[3px] flex-shrink-0"
              :class="pool.type === 'dedicated' ? 'bg-ded-l text-ded border border-ded-m' : 'bg-shr-l text-shr border border-shr-m'"
            >{{ pool.id }}</span>
            <span class="text-ink-3 flex-1 text-[12px]">{{ pool.site }}</span>
            <span
              class="text-[9px] font-bold uppercase px-1.5 py-0.5 rounded-[3px] border"
              :class="pool.type === 'dedicated' ? 'bg-ded-l text-ded border-ded-m' : 'bg-shr-l text-shr border-shr-m'"
            >{{ pool.type }}</span>
            <span
              class="text-[9px] font-bold uppercase px-1.5 py-0.5 rounded-[3px] border"
              :class="pool.env === 'Prod' ? 'bg-grn-l text-grn border-grn-m' : 'bg-pur-l text-pur border-pur-m'"
            >{{ pool.env }}</span>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, computed, watch } from 'vue'

const CLOUD_META = {
  private: { label: '私有雲', color: '#2563eb' },
  hicloud: { label: 'hiCloud', color: '#0e7490' },
  aws:     { label: 'AWS',     color: '#b45309' },
}

const props = defineProps({
  sysView: { type: Object, default: () => ({}) },
})

const selectedSys = ref(null)

// Auto-select first system when sysView changes
watch(() => props.sysView, (sv) => {
  const first = Object.keys(sv)[0]
  selectedSys.value = first ?? null
}, { immediate: true })

const poolsByCloud = computed(() => {
  if (!selectedSys.value || !props.sysView[selectedSys.value]) return {}
  const pools = props.sysView[selectedSys.value].pools
  const byCloud = {}
  for (const pool of pools) {
    const ck = Object.keys(CLOUD_META).find(k => CLOUD_META[k].label === pool.cloud) ?? pool.cloud
    if (!byCloud[ck]) byCloud[ck] = { label: pool.cloud, color: CLOUD_META[ck]?.color ?? '#0f0f0f', rows: [] }
    byCloud[ck].rows.push(pool)
  }
  return byCloud
})
</script>

<style scoped>
@reference "../../assets/main.css";
</style>
