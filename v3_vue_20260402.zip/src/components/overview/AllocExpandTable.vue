<template>
  <table class="w-full border-collapse">
    <thead>
      <tr>
        <th class="th">專案</th>
        <th class="th">系統</th>
        <th class="th">環境</th>
        <th class="th">CPU 配額</th>
        <th class="th">Memory 配額</th>
      </tr>
    </thead>
    <tbody>
      <tr v-for="a in allocs" :key="a.id" class="hover:bg-or/[0.03] transition-colors">
        <td class="td font-semibold text-ink">{{ a.projectName }}</td>
        <td class="td text-ink-3">{{ a.systemName }}</td>
        <td class="td"><EnvBadge :env="a.env" /></td>
        <td class="td">
          <div class="flex items-center gap-2">
            <div class="w-20 h-1 rounded-full bg-bord overflow-hidden">
              <div class="h-full rounded-full bg-shr" style="width: 50%" />
            </div>
            <span class="font-mono text-[10px] text-ink-3">{{ a.quota_cpu }} C</span>
          </div>
        </td>
        <td class="td">
          <div class="flex items-center gap-2">
            <div class="w-20 h-1 rounded-full bg-bord overflow-hidden">
              <div class="h-full rounded-full bg-shr" style="width: 50%" />
            </div>
            <span class="font-mono text-[10px] text-ink-3">{{ a.quota_mem_gb }} GB</span>
          </div>
        </td>
      </tr>
      <tr v-if="!allocs.length">
        <td colspan="5" class="py-6 text-center text-xs text-ink-4">此 Pool 尚無 Allocation</td>
      </tr>
    </tbody>
  </table>
</template>

<script setup>
import EnvBadge from '../common/EnvBadge.vue'
defineProps({ allocs: { type: Array, default: () => [] } })
</script>

<style scoped>
@reference "../../assets/main.css";
.th { @apply px-3.5 py-2 text-left text-[9px] font-bold uppercase tracking-[.12em] text-ink-4 bg-white border-b-2 border-bord whitespace-nowrap; }
.td { @apply px-3.5 py-2.5 border-b border-bord text-xs align-middle; }
</style>
