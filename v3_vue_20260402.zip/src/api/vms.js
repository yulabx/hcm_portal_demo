import { request } from './request'

export const vmsApi = {
  list:   ()         => request('/api/vms'),
  create: (data)     => request('/api/vms',         { method: 'POST',   body: data }),
  delete: (id)       => request(`/api/vms/${id}`,   { method: 'DELETE' }),
}
