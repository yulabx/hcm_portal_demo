<template>
  <div class="bg-white border border-bord rounded-[10px] shadow-sm overflow-hidden">
    <!-- Header -->
    <div class="px-5 py-4 border-b border-bord flex flex-wrap items-start gap-3">
      <div class="flex-1 min-w-0">
        <div class="flex items-center gap-2 flex-wrap">
          <span class="font-mono text-xs font-bold text-ink">{{ req.id }}</span>
          <span class="badge border bg-amb-l text-amb border-amb-m">待執行</span>
        </div>
        <div class="text-xs text-ink-3 mt-1">
          專案：<span class="font-semibold text-ink">{{ req.project }}</span>
          　申請人：{{ req.applicant }}　{{ req.created }}
        </div>
      </div>
    </div>

    <!-- Systems + mounts -->
    <div class="divide-y divide-bord">
      <div v-for="sys in req.systems" :key="sys.code" class="px-5 py-4">
        <div class="flex items-center gap-2 mb-3">
          <span class="text-xs font-bold text-ink">{{ sys.name }}</span>
          <span class="font-mono text-[10px] text-ink-4">{{ sys.code }}</span>
          <span
            class="badge border text-[9px]"
            :class="sys.env === 'Prod' ? 'bg-grn-l text-grn border-grn-m' : 'bg-pur-l text-pur border-pur-m'"
          >{{ sys.env }}</span>
        </div>
        <div class="flex flex-col gap-2">
          <div
            v-for="mount in sys.mounts" :key="mount.pool_id + mount._key"
            class="flex items-start gap-3 p-3 rounded-[6px] border"
            :class="mount._done ? 'border-grn-m bg-grn-l' : 'border-bord bg-surf-2'"
          >
            <span
              class="font-mono text-[10px] font-bold px-1.5 py-0.5 rounded-[3px] border flex-shrink-0 mt-0.5"
              :class="isSharedPool(mount.pool_id) ? 'bg-shr-l text-shr border-shr-m' : 'bg-ded-l text-ded border-ded-m'"
            >{{ mount.pool_id }}</span>
            <div class="flex-1 min-w-0">
              <div class="text-xs font-semibold text-ink">{{ poolName(mount.pool_id) }}</div>
              <div v-if="isSharedPool(mount.pool_id)" class="text-[10px] text-ink-4 mt-0.5">
                使用者預估：CPU {{ mount.est_cpu ?? '—' }}C · Mem {{ mount.est_mem ?? '—' }}GB
                <span v-if="mount.note" class="ml-2 italic text-ink-3">{{ mount.note }}</span>
              </div>
              <div v-else class="text-[10px] text-ink-4 mt-0.5">Dedicated Pool — 無需設定 Allocation</div>
            </div>
            <template v-if="isSharedPool(mount.pool_id)">
              <span v-if="mount._done" class="text-[10px] font-bold text-grn flex-shrink-0">✓ 已設定</span>
              <button
                v-else
                class="set-btn flex-shrink-0"
                @click="$emit('set-alloc', { req, sys, mount })"
              >設定配額 →</button>
            </template>
            <span v-else class="text-[10px] text-ink-4 flex-shrink-0">自動處理</span>
          </div>
        </div>
      </div>
    </div>

    <!-- Footer -->
    <div class="px-5 py-3 bg-surf-2 border-t border-bord flex items-center justify-between">
      <span class="text-[11px] text-ink-4">
        {{ doneMounts }} / {{ totalSharedMounts }} 個 Shared Pool 已設定配額
      </span>
      <button
        class="exec-btn"
        :class="allDone ? 'bg-grn hover:bg-grn/80 cursor-pointer' : 'bg-bord-2 text-ink-4 cursor-not-allowed'"
        :disabled="!allDone"
        @click="allDone && $emit('execute', req)"
      >▶ 執行開通</button>
    </div>
  </div>
</template>

<script setup>
import { computed } from 'vue'

const props = defineProps({
  req:         { type: Object, required: true },
  sharedPools: { type: Array,  default: () => [] }, // pool objects (type=shared)
})
defineEmits(['set-alloc', 'execute'])

function isSharedPool(poolId) { return props.sharedPools.some(p => p.id === poolId) }
function poolName(poolId) {
  const SITE_LABELS = { 'tp-main':'台北主中心','tc-dr':'台中異備中心','e7-main':'東七主中心','tw-main':'台灣主中心' }
  const p = props.sharedPools.find(x => x.id === poolId)
  return p ? p.name : poolId
}

const allSharedMounts = computed(() =>
  props.req.systems.flatMap(s => s.mounts.filter(m => isSharedPool(m.pool_id)))
)
const totalSharedMounts = computed(() => allSharedMounts.value.length)
const doneMounts        = computed(() => allSharedMounts.value.filter(m => m._done).length)
const allDone           = computed(() => totalSharedMounts.value > 0 && doneMounts.value === totalSharedMounts.value)
</script>

<style scoped>
@reference "../../assets/main.css";
.badge   { @apply text-[9px] font-bold uppercase tracking-wide px-1.5 py-0.5 rounded-[3px]; }
.set-btn { @apply px-3 py-1.5 text-[10px] font-bold bg-shr text-white rounded-[5px] hover:bg-shr/80 transition-all cursor-pointer; }
.exec-btn { @apply px-4 py-1.5 text-[10px] font-bold text-white rounded-[5px] transition-all; }
</style>
