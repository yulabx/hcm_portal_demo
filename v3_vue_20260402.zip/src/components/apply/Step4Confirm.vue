<template>
  <div class="flex flex-col gap-5">

    <!-- Project section -->
    <div class="flex flex-col gap-2">
      <div class="section-title">
        <div class="w-[3px] h-3 bg-or rounded-full" />
        專案
      </div>
      <div class="flex items-center gap-3 px-4 py-3 bg-surf-2 border border-bord rounded-[8px]">
        <div class="w-8 h-8 rounded-full bg-gradient-to-br from-ded to-shr flex items-center justify-center text-white text-xs font-bold flex-shrink-0">
          {{ applyStore.selectedProject?.name?.charAt(0) }}
        </div>
        <div>
          <div class="text-xs font-bold text-ink">{{ applyStore.selectedProject?.name }}</div>
          <div class="text-[10px] text-ink-4 font-mono">{{ applyStore.selectedProject?.id }}{{ applyStore.selectedProject?.isNew ? ' · 新建' : ' · 既有' }}</div>
        </div>
      </div>
    </div>

    <!-- Systems + mounts section -->
    <div class="flex flex-col gap-2">
      <div class="section-title">
        <div class="w-[3px] h-3 bg-or rounded-full" />
        系統與 Pool 掛載
      </div>

      <div v-for="s in applyStore.systems" :key="s.uid" class="border border-bord rounded-[8px] overflow-hidden">
        <!-- System header -->
        <div class="px-4 py-2.5 bg-surf-2 border-b border-bord flex items-center gap-2">
          <span class="text-xs font-bold text-ink">{{ s.name }}</span>
          <span class="font-mono text-[10px] text-ink-4">{{ s.code }}</span>
          <div class="ml-auto flex gap-1">
            <span
              v-for="env in s.envs" :key="env"
              class="text-[9px] font-bold uppercase tracking-wide px-1.5 py-0.5 rounded-[3px] border"
              :class="envBadge(env)"
            >{{ env }}</span>
          </div>
        </div>

        <!-- Env rows -->
        <div v-for="env in s.envs" :key="env" class="border-t border-bord">
          <div class="px-4 py-2 bg-surf-2 flex items-center gap-2">
            <div class="w-1.5 h-1.5 rounded-full" :class="envDot(env)" />
            <span class="text-[10px] font-bold uppercase" :class="envText(env)">{{ env }}</span>
          </div>
          <div class="divide-y divide-bord">
            <!-- Dedicated -->
            <template v-if="dedicatedPool(s.uid, env)">
              <div class="px-4 py-2.5 flex items-start gap-3">
                <span class="font-mono text-[10px] font-semibold px-1.5 py-0.5 rounded-[3px] border bg-ded-l text-ded border-ded-m flex-shrink-0 mt-0.5">{{ dedicatedPool(s.uid, env).id }}</span>
                <div class="flex-1 min-w-0">
                  <div class="text-xs font-semibold text-ink">{{ dedicatedPool(s.uid, env).name }}</div>
                  <div class="text-[10px] text-ink-4 mt-0.5">{{ cloudLabel(dedicatedPool(s.uid, env).cloud) }} · Dedicated · 專屬綁定</div>
                </div>
              </div>
            </template>
            <!-- Shared -->
            <template v-for="sh in sharedMounts(s.uid, env)" :key="sh.pool_id">
              <div v-if="poolById(sh.pool_id)" class="px-4 py-2.5 flex items-start gap-3">
                <span class="font-mono text-[10px] font-semibold px-1.5 py-0.5 rounded-[3px] border bg-shr-l text-shr border-shr-m flex-shrink-0 mt-0.5">{{ sh.pool_id }}</span>
                <div class="flex-1 min-w-0">
                  <div class="text-xs font-semibold text-ink">{{ poolById(sh.pool_id)?.name }}</div>
                  <div class="text-[10px] text-ink-4 mt-0.5">
                    {{ cloudLabel(poolById(sh.pool_id)?.cloud) }} · Shared{{ sh.est_cpu ? ` · CPU ${sh.est_cpu}C` : '' }}{{ sh.est_mem ? ` · Mem ${sh.est_mem}GB` : '' }}{{ sh.est_disk ? ` · Disk ${sh.est_disk}GB` : '' }}
                  </div>
                </div>
              </div>
            </template>
            <!-- No mounts -->
            <div
              v-if="!dedicatedPool(s.uid, env) && !sharedMounts(s.uid, env).filter(sh => sh.pool_id).length"
              class="px-4 py-2.5 text-[10px] text-ink-4 italic"
            >（未掛載 Pool）</div>
          </div>
        </div>
      </div>
    </div>

  </div>
</template>

<script setup>
import { useApplyStore } from '../../stores/apply'
import { usePoolsStore } from '../../stores/pools'

const applyStore = useApplyStore()
const poolsStore = usePoolsStore()

const CLOUD_LABELS = { private: '私有雲', hicloud: 'hiCloud', aws: 'AWS' }
const ENV_STYLE = {
  Prod: { badge: 'bg-grn-l text-grn border-grn-m', dot: 'bg-grn', text: 'text-grn' },
  UAT:  { badge: 'bg-pur-l text-pur border-pur-m', dot: 'bg-pur', text: 'text-pur' },
}

function cloudLabel(c) { return CLOUD_LABELS[c] ?? c }
function envBadge(env) { return (ENV_STYLE[env] ?? ENV_STYLE.UAT).badge }
function envDot(env)   { return (ENV_STYLE[env] ?? ENV_STYLE.UAT).dot }
function envText(env)  { return (ENV_STYLE[env] ?? ENV_STYLE.UAT).text }

function mountOf(uid, env) {
  return applyStore.poolMounts[`${uid}:${env}`] ?? { dedicated: null, shared: [] }
}
function poolById(id) {
  return id ? poolsStore.poolsWithUsed.find(p => p.id === id) ?? null : null
}
function dedicatedPool(uid, env) {
  const id = mountOf(uid, env).dedicated
  return id ? poolById(id) : null
}
function sharedMounts(uid, env) {
  return mountOf(uid, env).shared ?? []
}
</script>

<style scoped>
@reference "../../assets/main.css";
.section-title { @apply text-[10px] font-bold uppercase tracking-[.1em] text-ink-4 flex items-center gap-2; }
</style>
