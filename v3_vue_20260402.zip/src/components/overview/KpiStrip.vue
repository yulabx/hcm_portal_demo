<template>
  <div class="grid border border-bord rounded-[8px] overflow-hidden bg-white shadow-sm mb-5"
    style="grid-template-columns: repeat(5, 1fr)">
    <div
      v-for="(kpi, i) in kpis" :key="kpi.label"
      class="px-5 py-4 border-r border-bord last:border-r-0 relative"
    >
      <!-- Orange accent bar on first cell -->
      <div v-if="i === 0" class="absolute top-0 left-0 right-0 h-[3px] bg-or rounded-tl-[8px]" />
      <div class="text-[28px] font-extrabold tracking-[-0.04em] text-ink leading-none mb-1">{{ kpi.value }}</div>
      <div class="text-[11px] font-semibold text-ink-2">{{ kpi.label }}</div>
      <div class="text-[10px] text-ink-4 mt-0.5 font-mono">{{ kpi.sub }}</div>
    </div>
  </div>
</template>

<script setup>
defineProps({
  kpis: { type: Array, required: true },
  // [{ value, label, sub }]
})
</script>
