import { defineStore } from 'pinia'
import { ref, computed } from 'vue'
import systemsData from '@data/systems.json'
import { systemsApi } from '../api/systems'

const USE_MOCK = import.meta.env.VITE_USE_MOCK !== 'false'

export const useSystemsStore = defineStore('systems', () => {
  const systems = ref([])
  const loading = ref(false)
  const error   = ref(null)

  async function init() {
    if (systems.value.length) return
    loading.value = true
    error.value   = null
    try {
      systems.value = USE_MOCK ? systemsData : await systemsApi.list()
    } catch (e) {
      error.value = e.message
    } finally {
      loading.value = false
    }
  }

  const systemMap = computed(() =>
    Object.fromEntries(systems.value.map(s => [s.id, s]))
  )

  function byProject(projectId) {
    return systems.value.filter(s => s.project_id === projectId)
  }

  async function addSystem(data) {
    const created = USE_MOCK ? data : await systemsApi.create(data)
    systems.value.push(created)
  }

  async function updateSystem(data) {
    if (!USE_MOCK) await systemsApi.update(data.id, data)
    const i = systems.value.findIndex(s => s.id === data.id)
    if (i !== -1) systems.value[i] = { ...systems.value[i], ...data }
  }

  return { systems, loading, error, systemMap, byProject, init, addSystem, updateSystem }
})
