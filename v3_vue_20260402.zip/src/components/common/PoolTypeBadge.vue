<template>
  <span
    class="text-[9px] font-bold uppercase tracking-wide px-1.5 py-0.5 rounded-[3px] border"
    :class="type === 'dedicated'
      ? 'bg-ded-l text-ded border-ded-m'
      : 'bg-shr-l text-shr border-shr-m'"
  >
    {{ type === 'dedicated' ? 'Dedicated' : 'Shared' }}
  </span>
</template>

<script setup>
defineProps({
  type: { type: String, required: true },  // 'dedicated' | 'shared'
})
</script>
