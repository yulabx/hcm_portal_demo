import { ref } from 'vue'

// 單例模式：任何元件呼叫 useToast().show() 都會觸發同一個 ToastNotify 實例
const message = ref('')
const visible = ref(false)
const isError = ref(false)
let _timer = null

export function useToast() {
  function show(msg, error = false) {
    message.value = msg
    isError.value = error
    visible.value = true
    clearTimeout(_timer)
    _timer = setTimeout(() => { visible.value = false }, 2600)
  }
  return { message, visible, isError, show }
}
