<template>
  <!-- Card only — expand panel is rendered outside the grid by CloudViewPanel -->
  <div
    class="border rounded-[7px] overflow-hidden cursor-pointer transition-all relative min-h-[92px]"
    :class="[
      type === 'dedicated' ? 'bg-ded-l border-ded-m' : 'bg-shr-l border-shr-m',
      open ? '!border-or shadow-[0_0_0_1px_#ea580c]' : 'hover:border-bord-2 hover:shadow-sm',
    ]"
    @click="$emit('toggle', poolId)"
  >
    <!-- Top bar accent -->
    <div
      class="absolute top-0 left-0 right-0 h-[2px]"
      :style="{ background: open ? '#ea580c' : type === 'dedicated' ? '#2563eb' : '#0d9488' }"
    />

    <!-- Pool ID + name + count -->
    <div class="flex items-center gap-2 px-[14px] pt-[14px] pb-[2px]">
      <span
        class="font-mono text-[11px] font-semibold px-[7px] py-[3px] rounded-[3px] flex-shrink-0"
        :class="type === 'dedicated' ? 'bg-ded-l text-ded border border-ded-m' : 'bg-shr-l text-shr border border-shr-m'"
      >{{ poolId }}</span>
      <span class="text-[12px] font-semibold text-ink flex-1 min-w-0 truncate">{{ poolName }}</span>
      <span class="text-[10px] font-semibold text-ink-3 bg-white border border-bord px-1.5 py-0.5 rounded-[3px] flex-shrink-0 ml-auto mr-1">
        {{ itemCount }} {{ type === 'dedicated' ? 'VMs' : 'Allocs' }}
      </span>
      <span
        class="text-[12px] text-ink-4 flex-shrink-0 transition-transform duration-200"
        :class="open ? 'rotate-180 !text-or' : ''"
      >▾</span>
    </div>

    <!-- Tags -->
    <div class="flex gap-1 flex-wrap px-[14px] pb-[14px] pt-[8px]">
      <span class="mpt" :class="type === 'dedicated' ? 'mpt-ded' : 'mpt-shr'">{{ type }}</span>
      <span class="mpt" :class="env === 'Prod' ? 'mpt-prod' : 'mpt-uat'">{{ env }}</span>
      <span v-if="sysName" class="mpt mpt-sys">{{ sysName }}</span>
    </div>
  </div>
</template>

<script setup>
import { computed } from 'vue'

const props = defineProps({
  poolId:    { type: String,  required: true },
  poolName:  { type: String,  default: '' },
  type:      { type: String,  default: 'dedicated' },
  env:       { type: String,  default: 'Prod' },
  sysName:   { type: String,  default: '' },
  itemCount: { type: Number,  default: 0 },
  open:      { type: Boolean, default: false },
})
defineEmits(['toggle'])
</script>

<style scoped>
@reference "../../assets/main.css";
.mpt      { @apply text-[10px] font-bold px-[7px] py-[2px] rounded-[3px] uppercase tracking-[.05em] whitespace-nowrap; }
.mpt-ded  { @apply bg-ded-l text-ded border border-ded-m; }
.mpt-shr  { @apply bg-shr-l text-shr border border-shr-m; }
.mpt-prod { @apply bg-grn-l text-grn border border-grn-m; }
.mpt-uat  { @apply bg-pur-l text-pur border border-pur-m; }
.mpt-sys  { @apply bg-surf-2 text-ink-3 border border-bord; }
</style>
