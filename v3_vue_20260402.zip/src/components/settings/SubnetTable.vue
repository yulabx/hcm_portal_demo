<template>
  <div class="bg-white border border-bord rounded-[8px] shadow-sm overflow-hidden">
    <div class="overflow-x-auto">
      <table class="w-full text-sm border-collapse">
        <thead>
          <tr class="border-b border-bord bg-surf-2">
            <th class="th">Subnet ID</th>
            <th class="th">名稱</th>
            <th class="th">CIDR</th>
            <th class="th">類型</th>
            <th class="th">Cloud</th>
            <th class="th">Site</th>
            <th class="th">狀態</th>
            <th class="th">操作</th>
          </tr>
        </thead>
        <tbody>
          <tr v-if="!subnets.length">
            <td colspan="8">
              <div class="flex flex-col items-center justify-center py-16 text-ink-4">
                <div class="text-4xl mb-3 opacity-25">🌐</div>
                <div class="text-sm font-semibold text-ink-3">找不到符合條件的 Subnet</div>
              </div>
            </td>
          </tr>
          <tr
            v-for="(sn, i) in subnets"
            :key="sn.id"
            class="border-b border-bord hover:bg-surf-2 transition-colors"
            :style="{ animationDelay: i * 20 + 'ms' }"
          >
            <td class="td font-mono text-xs font-semibold text-ink-3">{{ sn.id }}</td>
            <td class="td text-xs font-semibold text-ink">{{ sn.name }}</td>
            <td class="td font-mono text-xs text-ink-3">{{ sn.cidr }}</td>
            <td class="td">
              <span class="text-[9px] font-bold uppercase tracking-wide px-1.5 py-0.5 rounded-[3px] border bg-surf-2 text-ink-3 border-bord">
                {{ sn.type }}
              </span>
            </td>
            <td class="td"><CloudBadge :cloud="sn.cloud" /></td>
            <td class="td text-xs text-ink-3">{{ sn.site }}</td>
            <td class="td"><StatusBadge :status="sn.status ?? 'active'" /></td>
            <td class="td">
              <div class="flex items-center gap-1.5">
                <button class="btn-action" @click="$emit('edit', sn)">編輯</button>
                <button
                  class="btn-action border-red-m bg-red-l text-red hover:bg-red hover:text-white"
                  @click="$emit('delete', sn)"
                >刪除</button>
              </div>
            </td>
          </tr>
        </tbody>
      </table>
    </div>
  </div>
</template>

<script setup>
import StatusBadge from '../common/StatusBadge.vue'
import CloudBadge  from '../common/CloudBadge.vue'

defineProps({ subnets: { type: Array, default: () => [] } })
defineEmits(['edit', 'delete'])
</script>

<style scoped>
@reference "../../assets/main.css";
.th { @apply px-4 py-3 text-left text-[10px] font-bold uppercase tracking-[.1em] text-ink-4 whitespace-nowrap; }
.td { @apply px-4 py-3; }
.btn-action { @apply px-2.5 py-1 text-[10px] font-semibold border border-bord rounded-[4px] bg-white text-ink-3 hover:border-bord-2 hover:bg-surf-2 transition-all; }
</style>
