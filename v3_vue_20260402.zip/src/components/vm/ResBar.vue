<template>
  <div>
    <div class="flex justify-between text-[10px] text-ink-4 mb-1">
      <span>{{ label }}</span>
      <span class="font-mono">{{ displayUsed }}/{{ displayTotal }} {{ unit }} ({{ pct }}%)</span>
    </div>
    <div class="h-1 bg-bord rounded-[2px] overflow-hidden">
      <div
        class="h-full rounded-[2px] transition-all duration-300"
        :style="{ width: pct + '%', background: barColor }"
      />
    </div>
  </div>
</template>

<script setup>
import { computed } from 'vue'

const props = defineProps({
  label:    { type: String, required: true },
  used:     { type: Number, default: 0 },
  total:    { type: Number, default: 0 },
  unit:     { type: String, default: '' },
  decimals: { type: Number, default: 0 },
})

const pct      = computed(() => props.total ? Math.min(100, Math.round(props.used / props.total * 100)) : 0)
const barColor = computed(() => pct.value >= 85 ? '#dc2626' : pct.value >= 70 ? '#d97706' : '#16a34a')
const fmt      = (v) => props.decimals ? +v.toFixed(props.decimals) : Math.round(v)
const displayUsed  = computed(() => fmt(props.used))
const displayTotal = computed(() => fmt(props.total))
</script>
