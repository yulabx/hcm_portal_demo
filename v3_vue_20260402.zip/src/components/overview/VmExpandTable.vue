<template>
  <table class="w-full border-collapse">
    <thead>
      <tr>
        <th class="th">VM 名稱</th>
        <th class="th">狀態</th>
        <th class="th">規格 (vCPU / RAM / Disk)</th>
        <th class="th">環境</th>
        <th class="th">IP 位址</th>
      </tr>
    </thead>
    <tbody>
      <tr v-for="vm in vms" :key="vm.id" class="hover:bg-or/[0.03] transition-colors">
        <td class="td">
          <div class="flex items-center gap-2">
            <span class="w-2 h-2 rounded-full flex-shrink-0"
              :class="vm.status === 'running' ? 'bg-grn' : 'bg-ink-4'" />
            <span class="text-xs font-semibold text-ink font-mono">{{ vm.name }}</span>
          </div>
        </td>
        <td class="td"><StatusBadge :status="vm.status" /></td>
        <td class="td">
          <span class="text-xs text-ink-3 font-mono">
            {{ vm.vcpu }} vCPU · {{ vm.ram_gb }} GB · {{ vm.disk_gb }} GB
          </span>
        </td>
        <td class="td"><EnvBadge :env="vm.tags?.env ?? '—'" /></td>
        <td class="td">
          <span class="font-mono text-[11px] text-ink-3">{{ vm.ip ?? '—' }}</span>
        </td>
      </tr>
      <tr v-if="!vms.length">
        <td colspan="5" class="py-6 text-center text-xs text-ink-4">此 Pool 尚無 VM</td>
      </tr>
    </tbody>
  </table>
</template>

<script setup>
import StatusBadge from '../common/StatusBadge.vue'
import EnvBadge   from '../common/EnvBadge.vue'
defineProps({ vms: { type: Array, default: () => [] } })
</script>

<style scoped>
@reference "../../assets/main.css";
.th { @apply px-3.5 py-2 text-left text-[9px] font-bold uppercase tracking-[.12em] text-ink-4 bg-white border-b-2 border-bord whitespace-nowrap; }
.td { @apply px-3.5 py-2.5 border-b border-bord text-sm align-middle last-of-type:border-b-0; }
</style>
