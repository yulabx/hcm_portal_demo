<template>
  <div class="overflow-x-auto">
    <table class="w-full text-xs border-collapse" style="font-size:12px">
      <thead>
        <tr class="bg-surf-2 border-b border-bord">
          <th class="th">VM 名稱 / 角色</th>
          <th class="th">狀態</th>
          <th class="th">規格</th>
          <th class="th">映像檔</th>
          <th class="th">磁碟</th>
          <th class="th">IP / Subnet</th>
          <th class="th">操作</th>
        </tr>
      </thead>
      <tbody>
        <tr
          v-for="vm in vms" :key="vm.id"
          class="border-b border-bord hover:bg-surf-2 transition-colors"
          style="border-bottom-color:#f0f0f0"
        >
          <!-- Name / Role -->
          <td class="td">
            <div class="flex items-center gap-1.5">
              <span class="dot" :class="vm.status === 'running' ? 'dot-run' : 'dot-stop'" />
              <div>
                <div class="font-mono text-[12px] font-semibold">{{ vm.name }}</div>
                <div class="text-[10px] text-ink-4">{{ vm.hostname || vm.name }} · <span class="text-ink-3">{{ vm.roleLabel || vm.tags?.role || '—' }}</span></div>
              </div>
            </div>
          </td>
          <!-- Status -->
          <td class="td">
            <span class="badge-s" :class="vm.status === 'running' ? 'bg-grn-l text-grn border-grn-m' : 'bg-surf-2 text-ink-3 border-bord'">
              {{ vm.status === 'running' ? 'Running' : 'Stopped' }}
            </span>
          </td>
          <!-- Spec -->
          <td class="td">
            <div class="font-mono text-[11px] font-semibold text-ink-2">{{ vm.vcpu }}C / {{ vm.ram_gb }}GB</div>
            <div class="text-[10px] text-ink-4">{{ vm.flavor || 'custom' }}</div>
          </td>
          <!-- Image -->
          <td class="td text-[11px] text-ink-3">{{ vm.image || '—' }}</td>
          <!-- Disk -->
          <td class="td">
            <div class="text-[11px] font-mono">{{ diskDisp(vm.disk_gb) }}</div>
            <div class="text-[10px] text-ink-4 uppercase">{{ vm.disk_type || '—' }}</div>
          </td>
          <!-- IP / Subnet -->
          <td class="td">
            <div class="font-mono text-[11px] text-ink-3">{{ vm.ip || '—' }}</div>
            <div class="text-[10px] text-ink-4">{{ subnetName(vm.subnet_id) }}</div>
          </td>
          <!-- Actions -->
          <td class="td">
            <div class="flex items-center gap-1">
              <button
                class="text-[11px] px-2 py-1 rounded-[4px] border border-bord hover:bg-surf-2 transition-colors text-ink-3 cursor-pointer whitespace-nowrap"
                @click="$emit('toggle-status', vm)"
              >{{ vm.status === 'running' ? '⏹ 停止' : '▶ 啟動' }}</button>
              <button
                class="text-[11px] px-2 py-1 rounded-[4px] border border-bord hover:bg-red-l hover:border-red-m hover:text-red transition-colors text-ink-3 cursor-pointer"
                @click="$emit('delete', vm)"
              >🗑</button>
            </div>
          </td>
        </tr>
        <tr v-if="!vms.length">
          <td colspan="7" class="td text-center text-ink-4 py-6">尚無 VM，點下方按鈕新增</td>
        </tr>
      </tbody>
    </table>
  </div>
</template>

<script setup>
const props = defineProps({
  vms:       { type: Array,  default: () => [] },
  subnetMap: { type: Object, default: () => ({}) },
})
defineEmits(['toggle-status', 'delete'])

function diskDisp(gb) { return gb >= 1024 ? +(gb / 1024).toFixed(1) + ' TB' : (gb || 0) + ' GB' }
function subnetName(id) {
  if (!id) return '—'
  const s = props.subnetMap[id]
  return s ? s.name : id
}
</script>

<style scoped>
@reference "../../assets/main.css";
.th      { @apply px-2.5 py-2 text-left text-[10px] font-bold uppercase tracking-[.08em] text-ink-4 whitespace-nowrap; }
.td      { @apply px-2.5 py-2.5; vertical-align: middle; }
.dot     { @apply inline-block w-1.5 h-1.5 rounded-full mr-1 flex-shrink-0; vertical-align: middle; }
.dot-run { background: #16a34a; box-shadow: 0 0 4px rgba(22,163,74,.4); }
.dot-stop { @apply bg-bord-2; }
.badge-s { @apply text-[10px] font-bold px-1.5 py-0.5 rounded-full border; }
</style>
