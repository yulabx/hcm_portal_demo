<template>
  <div class="overflow-x-auto">
    <table class="w-full text-xs border-collapse">
      <thead>
        <tr class="bg-surf-2 border-b border-bord">
          <th class="th">系統</th>
          <th class="th">專案</th>
          <th class="th">環境</th>
          <th class="th text-right">CPU (C)</th>
          <th class="th text-right">Mem (GB)</th>
          <th class="th text-right">Disk (TB)</th>
          <th class="th">操作</th>
        </tr>
      </thead>
      <tbody>
        <tr
          v-for="a in allocs" :key="a.id"
          class="border-b border-bord hover:bg-surf-2 transition-colors"
        >
          <td class="td font-semibold text-ink whitespace-nowrap">{{ a.systemName }}</td>
          <td class="td text-ink-3 whitespace-nowrap">{{ a.projectName }}</td>
          <td class="td whitespace-nowrap">
            <span
              class="text-[9px] font-bold uppercase tracking-wide px-1.5 py-0.5 rounded-[3px] border"
              :class="a.env === 'Prod' ? 'bg-grn-l text-grn border-grn-m' : 'bg-pur-l text-pur border-pur-m'"
            >{{ a.env }}</span>
          </td>
          <td class="td text-right font-mono text-ink-2">{{ a.quota_cpu }}</td>
          <td class="td text-right font-mono text-ink-2">{{ a.quota_mem_gb }}</td>
          <td class="td text-right font-mono text-ink-2">{{ a.quota_disk_tb }}</td>
          <td class="td whitespace-nowrap">
            <div class="flex gap-1.5">
              <button class="act-btn" @click="$emit('edit', a)">調整</button>
              <button class="act-btn-del" @click="$emit('remove', a)">移除</button>
            </div>
          </td>
        </tr>
        <!-- Total row -->
        <tr class="bg-surf-2 font-bold">
          <td class="td text-[10px] text-ink-4 uppercase tracking-wide" colspan="3">合計</td>
          <td class="td text-right font-mono text-xs" :class="cpuPct >= 85 ? 'text-red' : ''">
            {{ totalCpu }}<span class="text-ink-4 font-normal">/{{ pool.cpu.t }}</span>
          </td>
          <td class="td text-right font-mono text-xs" :class="memPct >= 85 ? 'text-red' : ''">
            {{ totalMem }}<span class="text-ink-4 font-normal">/{{ pool.mem.t }}</span>
          </td>
          <td class="td text-right font-mono text-xs" :class="diskPct >= 85 ? 'text-red' : ''">
            {{ totalDisk.toFixed(1) }}<span class="text-ink-4 font-normal">/{{ pool.disk.t }}</span>
          </td>
          <td class="td"></td>
        </tr>
      </tbody>
    </table>
  </div>
</template>

<script setup>
import { computed } from 'vue'

const props = defineProps({
  allocs: { type: Array,  required: true },
  pool:   { type: Object, required: true },
})
defineEmits(['edit', 'remove'])

const totalCpu  = computed(() => props.allocs.reduce((s, a) => s + (a.quota_cpu      ?? 0), 0))
const totalMem  = computed(() => props.allocs.reduce((s, a) => s + (a.quota_mem_gb   ?? 0), 0))
const totalDisk = computed(() => props.allocs.reduce((s, a) => s + (a.quota_disk_tb  ?? 0), 0))
const cpuPct    = computed(() => props.pool.cpu.t  ? Math.round(totalCpu.value  / props.pool.cpu.t  * 100) : 0)
const memPct    = computed(() => props.pool.mem.t  ? Math.round(totalMem.value  / props.pool.mem.t  * 100) : 0)
const diskPct   = computed(() => props.pool.disk.t ? Math.round(totalDisk.value / props.pool.disk.t * 100) : 0)
</script>

<style scoped>
@reference "../../assets/main.css";
.th  { @apply px-4 py-2.5 text-left text-[9px] font-bold uppercase tracking-[.1em] text-ink-4 whitespace-nowrap; }
.td  { @apply px-4 py-2.5; }
.act-btn     { @apply px-2 py-1 text-[9px] font-semibold border border-bord rounded-[3px] bg-white text-ink-3 hover:border-bord-2 hover:bg-surf-2 transition-all cursor-pointer; }
.act-btn-del { @apply px-2 py-1 text-[9px] font-semibold border border-red-m rounded-[3px] bg-red-l text-red hover:bg-red hover:text-white transition-all cursor-pointer; }
</style>
