import { request } from './request'

export const poolsApi = {
  list:         ()         => request('/api/pools'),
  create:       (data)     => request('/api/pools',           { method: 'POST',  body: data }),
  update:       (id, data) => request(`/api/pools/${id}`,     { method: 'PUT',   body: data }),
  toggleStatus: (id)       => request(`/api/pools/${id}/toggle`, { method: 'PATCH' }),
}
