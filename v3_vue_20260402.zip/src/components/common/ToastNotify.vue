<template>
  <Teleport to="body">
    <Transition name="toast">
      <div
        v-if="visible"
        class="fixed bottom-7 left-1/2 -translate-x-1/2 z-[99] px-5 py-2.5 rounded-lg text-xs font-semibold text-white shadow-lg pointer-events-none whitespace-nowrap"
        :class="isError ? 'bg-red' : 'bg-ink'"
      >
        {{ message }}
      </div>
    </Transition>
  </Teleport>
</template>

<script setup>
import { useToast } from '../../composables/useToast'
const { message, visible, isError } = useToast()
</script>

<style scoped>
.toast-enter-active,
.toast-leave-active { transition: opacity .2s ease; }
.toast-enter-from,
.toast-leave-to     { opacity: 0; }
</style>
