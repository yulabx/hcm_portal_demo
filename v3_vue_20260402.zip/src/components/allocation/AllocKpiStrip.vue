<template>
  <div class="grid border border-bord rounded-[8px] overflow-hidden bg-white shadow-sm mb-6"
       style="grid-template-columns: repeat(4, 1fr)">
    <div class="px-5 py-4 border-r border-bord relative">
      <div class="absolute top-0 left-0 right-0 h-[3px] bg-shr rounded-tl-[8px]" />
      <div class="text-[28px] font-extrabold tracking-tight leading-none mb-1 text-shr">{{ sharedPoolCount }}</div>
      <div class="text-[11px] font-semibold text-ink-2">Shared Pools</div>
      <div class="text-[10px] text-ink-4 font-mono mt-0.5">管理配額分配</div>
    </div>
    <div class="px-5 py-4 border-r border-bord">
      <div class="text-[28px] font-extrabold tracking-tight leading-none mb-1">{{ allocCount }}</div>
      <div class="text-[11px] font-semibold text-ink-2">Allocations</div>
      <div class="text-[10px] text-ink-4 font-mono mt-0.5">已分配筆數</div>
    </div>
    <div class="px-5 py-4 border-r border-bord">
      <div class="text-[28px] font-extrabold tracking-tight leading-none mb-1 text-amb">{{ pendingCount }}</div>
      <div class="text-[11px] font-semibold text-ink-2">待執行申請</div>
      <div class="text-[10px] text-ink-4 font-mono mt-0.5">需設定配額</div>
    </div>
    <div class="px-5 py-4">
      <div class="text-[28px] font-extrabold tracking-tight leading-none mb-1 text-red">{{ overCount }}</div>
      <div class="text-[11px] font-semibold text-ink-2">容量警示</div>
      <div class="text-[10px] text-ink-4 font-mono mt-0.5">使用率 ≥ 85%</div>
    </div>
  </div>
</template>

<script setup>
defineProps({
  sharedPoolCount: { type: Number, default: 0 },
  allocCount:      { type: Number, default: 0 },
  pendingCount:    { type: Number, default: 0 },
  overCount:       { type: Number, default: 0 },
})
</script>
