import { request } from './request'

export const subnetsApi = {
  list:   ()         => request('/api/subnets'),
  create: (data)     => request('/api/subnets',        { method: 'POST',   body: data }),
  update: (id, data) => request(`/api/subnets/${id}`,  { method: 'PUT',    body: data }),
  delete: (id)       => request(`/api/subnets/${id}`,  { method: 'DELETE' }),
}
