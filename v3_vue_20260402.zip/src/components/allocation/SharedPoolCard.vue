<template>
  <div
    class="bg-white rounded-[10px] shadow-sm overflow-hidden"
    :class="hasWarn ? 'border border-red-m' : 'border border-bord'"
  >
    <!-- Pool header -->
    <div class="px-5 py-4 border-b border-bord flex flex-wrap items-center gap-3">
      <div class="flex items-center gap-2.5 flex-1 min-w-0">
        <span class="font-mono text-xs font-bold px-2 py-0.5 rounded-[3px] bg-shr-l text-shr border border-shr-m flex-shrink-0">
          {{ pool.id }}
        </span>
        <div class="min-w-0">
          <div class="text-sm font-bold text-ink truncate">{{ pool.name }}</div>
          <div class="text-[10px] text-ink-4 font-mono">{{ cloudLabel }} · {{ siteLabel }}</div>
        </div>
      </div>
      <div class="flex items-center gap-2 flex-shrink-0">
        <span v-if="hasWarn" class="badge border bg-red-l text-red border-red-m">容量警示</span>
        <span class="badge border" :class="pool.env === 'Prod' ? 'bg-grn-l text-grn border-grn-m' : 'bg-pur-l text-pur border-pur-m'">
          {{ pool.env }}
        </span>
        <span class="text-[10px] text-ink-4 font-mono">{{ allocs.length }} allocs</span>
        <button class="add-btn" @click="$emit('add', pool)">＋ 新增 Allocation</button>
      </div>
    </div>

    <!-- Resource bars -->
    <div class="px-5 py-4 grid gap-6 border-b border-bord" style="grid-template-columns: repeat(3, 1fr)">
      <CapacityBar label="CPU"  :used="totalCpu"  :total="pool.cpu.t"  unit="C"  />
      <CapacityBar label="Mem"  :used="totalMem"  :total="pool.mem.t"  unit="GB" />
      <CapacityBar label="Disk" :used="totalDisk" :total="pool.disk.t" unit="TB" />
    </div>

    <!-- Allocation table -->
    <AllocTable :allocs="allocs" :pool="pool" @edit="$emit('edit', $event)" @remove="$emit('remove', $event)" />
  </div>
</template>

<script setup>
import { computed } from 'vue'
import AllocTable  from './AllocTable.vue'
import CapacityBar from './CapacityBar.vue'

const CLOUD_LABELS = { private: '私有雲', hicloud: 'hiCloud', aws: 'AWS' }
const SITE_LABELS  = { 'tp-main': '台北主中心', 'tc-dr': '台中異備中心', 'e7-main': '東七主中心', 'tw-main': '台灣主中心' }

const props = defineProps({
  pool:   { type: Object, required: true },
  allocs: { type: Array,  default: () => [] },
})
defineEmits(['add', 'edit', 'remove'])

const cloudLabel = computed(() => CLOUD_LABELS[props.pool.cloud] ?? props.pool.cloud)
const siteLabel  = computed(() => SITE_LABELS[props.pool.site_id] ?? props.pool.site_id)
const totalCpu   = computed(() => props.allocs.reduce((s, a) => s + (a.quota_cpu     ?? 0), 0))
const totalMem   = computed(() => props.allocs.reduce((s, a) => s + (a.quota_mem_gb  ?? 0), 0))
const totalDisk  = computed(() => props.allocs.reduce((s, a) => s + (a.quota_disk_tb ?? 0), 0))
const cpuPct     = computed(() => props.pool.cpu.t  ? Math.round(totalCpu.value  / props.pool.cpu.t  * 100) : 0)
const memPct     = computed(() => props.pool.mem.t  ? Math.round(totalMem.value  / props.pool.mem.t  * 100) : 0)
const hasWarn    = computed(() => cpuPct.value >= 85 || memPct.value >= 85)
</script>

<style scoped>
@reference "../../assets/main.css";
.badge   { @apply text-[9px] font-bold uppercase tracking-wide px-1.5 py-0.5 rounded-[3px]; }
.add-btn { @apply flex items-center gap-1 px-3 py-1.5 text-[10px] font-bold bg-shr text-white rounded-[5px] hover:bg-shr/80 transition-all cursor-pointer; }
</style>
