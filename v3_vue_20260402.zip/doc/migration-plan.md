# HCM Portal — Vue Migration Plan

> 目標：保留現有 UI，將 6 個 HTML 頁面遷移為 Vue 3 SPA。
> 不重新設計，只重組結構。

---

## 1. Vue 元件拆分

### 共用（全頁面）

```
components/common/
  AppSidebar.vue       ← 側邊欄，含收折動畫
  CapacityBar.vue      ← CPU/Mem/Disk 進度條 + 三色警示邏輯
  StatusBadge.vue      ← running/stopped/active/inactive
  EnvBadge.vue         ← Prod / UAT
  PoolTypeBadge.vue    ← Dedicated / Shared
  CloudBadge.vue       ← private / hicloud / aws
  ConfirmDialog.vue    ← 二次確認對話框
  ToastNotify.vue      ← 操作回饋 toast
```

---

### resource-pool-overview（Cloud 維度鑽取）

```
views/ResourcePoolOverview.vue
  components/overview/
    KpiStrip.vue            ← 5 個統計數字
    CloudCard.vue           ← Level 1，含資源進度條
    SiteCard.vue            ← Level 2
    PoolGroupList.vue        ← Level 3 容器，Ded/Shared 分組
    PoolRow.vue             ← 可展開列
      VmExpandTable.vue     ← Dedicated Pool 展開
      AllocExpandTable.vue  ← Shared Pool 展開
```

---

### proj-overview（專案維度）

```
views/ProjDimension.vue
  components/proj/
    ProjTabBar.vue          ← 水平可滾動專案 Tab
    FilterBar.vue           ← 環境 + 類型篩選
    CloudViewPanel.vue
      CloudBlock.vue
      SiteBlock.vue
      MiniPoolCard.vue      ← 可展開
    SystemViewPanel.vue
      SysCard.vue           ← 系統選擇卡片
      SysPoolRow.vue        ← 該系統的 Pool 清單
```

---

### apply（四步驟嚮導）

```
views/Apply.vue
  components/apply/
    StepIndicator.vue
    Step1Project.vue        ← 搜尋或新建專案
    Step2Systems.vue        ← 系統清單 + 新增系統列
    Step3Mounts.vue         ← poolMounts 設定，Ded + Shared 各自 UI
    Step4Confirm.vue        ← 摘要預覽
    ApplyHistory.vue        ← 申請記錄清單
```

---

### vm（VM 管理）

```
views/VmManage.vue
  components/vm/
    EnvFilterBar.vue
    PoolCardVm.vue          ← 每個 Pool 一張卡，含 VM 表格
    VmTable.vue
    AddVmModal.vue          ← 含規格套餐、映像檔、資源剩餘提示
```

---

### allocation（配額管理）

```
views/Allocation.vue
  components/allocation/
    AllocKpiStrip.vue
    SharedPoolCard.vue      ← 每個 Shared Pool 一張
    AllocTable.vue          ← 含合計列
    AddAllocModal.vue
    PendingReqList.vue
    PendingReqCard.vue      ← 可展開，含 mounts 詳情
    ExecuteModal.vue        ← 設定配額 + 執行開通
```

---

### settings-pool（Pool & Subnet 設定）

```
views/SettingsPool.vue
  components/settings/
    PoolTable.vue
    PoolFormModal.vue       ← 含 Subnet 多選，依 Cloud 過濾
    SubnetTable.vue
    SubnetFormModal.vue
```

---

## 2. 元件 ↔ JSON 對應

| 元件 | 主要資料來源 |
|------|-------------|
| CloudCard / SiteCard / PoolRow | `pools.json` + `vms.json`（計算 used） |
| VmExpandTable | `vms.json` |
| AllocExpandTable | `allocations.json` + `projects.json` + `systems.json` |
| ProjTabBar / CloudViewPanel / SystemViewPanel | `projects.json` + `systems.json` + `pools.json` |
| Step1Project | `projects.json` |
| Step3Mounts | `pools.json`（type / env / cloud 篩選） |
| PoolCardVm / VmTable / AddVmModal | `pools.json` + `vms.json` + `allocations.json` |
| SharedPoolCard / AllocTable | `pools.json` + `allocations.json` |
| PendingReqCard | apply 送出的暫存（`localStorage` 或 store） |
| PoolTable / PoolFormModal | `pools.json` + `subnets.json` |
| SubnetTable / SubnetFormModal | `subnets.json` |
| CapacityBar | props 傳入，無直接 JSON 依賴 |

---

## 3. 需要 Mapping 的資料

| 來源欄位 | 轉換目標 | 說明 |
|----------|----------|------|
| `pools.cpu_total` | `pool.cpu.t` | used（`pool.cpu.u`）由 `vms` 篩選此 pool 後加總 vcpu |
| `allocations.project_id` | 顯示名稱 | join `projects.json` |
| `allocations.system_id` | 顯示名稱 | join `systems.json` |
| `pools.site_id` | 站點中文名 | `tp-main`→台北主中心，`tc-dr`→台中異備，`e7-main`→東七，`tw-main`→台灣 |
| `vms.subnet_id` | Subnet 名稱 / CIDR | join `subnets.json` |
| `vms.tags.role` | 顯示標籤 | `app`→應用、`db`→資料庫、`gateway`→閘道 |
| `pools.type + site_role` | Type Badge | `dedicated+dr`→Ded-DR，`shared+primary`→Shared 等 |
| `allocation.quota_mem_gb` | 頁面顯示 `mem` | allocation.html runtime 直接用 GB，無需再換算 |

全部 mapping 集中在 Pinia store 的 getter，頁面不自行換算。

---

## 4. 建議檔案結構

```
src/
  router/
    index.js

  stores/
    pools.js        ← 含 getter: poolsWithUsed（計算 cpu/mem/disk used）
    subnets.js
    allocations.js  ← 含 getter: allocsWithNames（join project/system 名稱）
    vms.js
    projects.js
    systems.js
    apply.js        ← 申請嚮導暫存狀態（wizard state + history）

  composables/
    useCapacity.js  ← 三色警示邏輯（< 70 / 70-85 / ≥ 85）
    usePoolFilter.js ← 類型 + 環境 + 關鍵字篩選

  components/
    common/         ← 見第 1 節
    overview/
    proj/
    apply/
    vm/
    allocation/
    settings/

  views/
    ResourcePoolOverview.vue
    ProjDimension.vue
    Apply.vue
    VmManage.vue
    Allocation.vue
    SettingsPool.vue

  data/             ← 現有 JSON 檔，不動
```

---

## 5. 建議開發順序

### Phase 1 — 基礎骨架（先不管資料）

1. `router/index.js` — 6 條路由，先用空 View 佔位
2. `AppSidebar.vue` — 導航 + 收折動畫
3. `CapacityBar.vue` + `useCapacity.js` — 最常用的 UI 元件
4. 其他 Badge 類共用元件

### Phase 2 — 資料層

5. 所有 Pinia stores（載入 JSON，寫好 getter）
6. `usePoolFilter.js` — 篩選邏輯

### Phase 3 — 唯讀 / 展示頁面（無複雜互動）

7. `SettingsPool` — 兩個 Tab，表格 + Modal（最單純的 CRUD 入手）
8. `ResourcePoolOverview` — 鑽取邏輯複雜但無表單

### Phase 4 — 有互動的管理頁面

9. `Allocation` — Pool 配額 tab 優先，再做待執行申請 tab
10. `VmManage` — AddVmModal 欄位最多，最後做

### Phase 5 — 申請流程 + 專案維度

11. `Apply` — wizard 狀態機，Step 1→4 逐步做
12. `ProjDimension` — 最依賴其他資料，排最後

---

> **注意事項**
> - allocation.html 的 `ALLOCS` 用字串名稱（`system`/`project`）；store getter `allocsWithNames` 統一做 ID → 名稱的 join，頁面層不再處理
> - tc-dr 站點的 Pool（P03/P04/S02）`subnet_ids` 為空，`SubnetSelect` 元件需處理空清單的提示狀態
> - apply 嚮導的暫存（`poolMounts`）存在 `apply.js` store，送出後寫入 history；目前 demo 不需 localStorage，後期串 API 再調整
