<template>
  <div class="flex flex-col gap-5">

    <div
      v-for="s in applyStore.systems" :key="s.uid"
      class="border border-bord rounded-[10px] overflow-hidden"
    >
      <!-- System header -->
      <div class="px-4 py-3 bg-surf-2 border-b border-bord flex items-center gap-2">
        <span class="text-xs font-bold text-ink">{{ s.name || '(未命名系統)' }}</span>
        <span class="font-mono text-[10px] text-ink-4">{{ s.code }}</span>
        <div class="ml-auto flex gap-1">
          <span
            v-for="env in s.envs" :key="env"
            class="text-[9px] font-bold uppercase tracking-wide px-1.5 py-0.5 rounded-[3px] border"
            :class="envStyle(env).badge"
          >{{ env }}</span>
        </div>
      </div>

      <div class="p-4">
        <div v-if="!s.envs?.length" class="text-xs text-ink-4 py-2">此系統未選擇任何環境</div>

        <!-- Per-env blocks -->
        <div
          v-for="env in s.envs" :key="env"
          class="border border-bord rounded-[8px] overflow-hidden mb-3 last:mb-0"
        >
          <!-- Env header -->
          <div class="px-4 py-2.5 bg-surf-2 border-b border-bord flex items-center gap-2">
            <div class="w-2 h-2 rounded-full flex-shrink-0" :class="envStyle(env).dot" />
            <span class="text-[11px] font-bold uppercase tracking-wide" :class="envStyle(env).text">{{ env }}</span>
            <span class="text-[10px] text-ink-4 ml-1">環境 Pool 設定</span>
          </div>

          <div class="p-4 flex flex-col gap-4">
            <!-- Dedicated pool -->
            <div class="flex flex-col gap-2">
              <div class="flex items-center gap-2">
                <span class="text-[10px] font-bold uppercase tracking-wide px-1.5 py-0.5 rounded-[3px] bg-ded-l text-ded border border-ded-m">Dedicated</span>
                <span class="text-[10px] text-ink-4">選擇一個專屬 Pool（1:1 綁定）</span>
              </div>
              <select
                class="border border-bord rounded-[6px] px-2.5 py-2 text-xs bg-white transition-all focus:outline-none focus:border-or"
                :value="mount(s.uid, env).dedicated ?? ''"
                @change="applyStore.setDedicated(mountKey(s.uid, env), $event.target.value)"
              >
                <option value="">— 不使用 Dedicated Pool —</option>
                <option v-for="p in dedPools" :key="p.id" :value="p.id">
                  {{ p.id }} · {{ p.name }} ({{ cloudLabel(p.cloud) }} · {{ p.env }}) — 剩餘 CPU {{ cpuFree(p) }}C / Mem {{ memFree(p) }}GB
                </option>
              </select>
              <div v-if="mount(s.uid, env).dedicated" class="text-[10px] text-ded bg-ded-l border border-ded-m rounded-[4px] px-2.5 py-1.5">
                ✓ 已選擇 {{ mount(s.uid, env).dedicated }}，此 Pool 將專屬綁定此系統的 {{ env }} 環境
              </div>
            </div>

            <!-- Shared pools -->
            <div class="flex flex-col gap-2">
              <div class="flex items-center gap-2">
                <span class="text-[10px] font-bold uppercase tracking-wide px-1.5 py-0.5 rounded-[3px] bg-shr-l text-shr border border-shr-m">Shared</span>
                <span class="text-[10px] text-ink-4">從共用 Pool 申請配額（可多筆）</span>
              </div>

              <!-- Shared rows -->
              <div
                v-for="(sh, idx) in mount(s.uid, env).shared" :key="idx"
                class="border border-bord rounded-[6px] p-3 flex flex-col gap-3 bg-white"
              >
                <div class="flex items-center gap-2">
                  <select
                    class="flex-1 border border-bord rounded-[6px] px-2.5 py-1.5 text-xs bg-white focus:outline-none focus:border-shr transition-all"
                    :value="sh.pool_id"
                    @change="applyStore.updateShared(mountKey(s.uid, env), idx, 'pool_id', $event.target.value)"
                  >
                    <option value="">— 選擇 Shared Pool —</option>
                    <option v-for="p in shrPools" :key="p.id" :value="p.id">
                      {{ p.id }} · {{ p.name }} ({{ cloudLabel(p.cloud) }} · {{ p.env }})
                    </option>
                  </select>
                  <button
                    class="text-[10px] text-ink-4 hover:text-red transition-colors font-semibold flex-shrink-0"
                    @click="applyStore.removeShared(mountKey(s.uid, env), idx)"
                  >✕</button>
                </div>

                <!-- Quota inputs (show only when pool selected) -->
                <div v-if="sh.pool_id" class="grid grid-cols-3 gap-2">
                  <div v-for="field in quotaFields" :key="field.key" class="flex flex-col gap-1">
                    <label class="text-[10px] font-semibold text-ink-4">{{ field.label }}</label>
                    <input
                      type="number"
                      min="1"
                      :value="sh[field.key]"
                      :placeholder="'0'"
                      class="border border-bord rounded-[6px] px-2 py-1.5 text-xs font-mono bg-white focus:outline-none focus:border-shr transition-all"
                      @change="applyStore.updateShared(mountKey(s.uid, env), idx, field.key, $event.target.value)"
                    />
                    <span v-if="field.key === 'est_cpu'" class="text-[10px] text-ink-4">Pool 剩餘 {{ cpuFree(shrPoolById(sh.pool_id)) }}C</span>
                    <span v-if="field.key === 'est_mem'" class="text-[10px] text-ink-4">Pool 剩餘 {{ memFree(shrPoolById(sh.pool_id)) }}GB</span>
                  </div>
                </div>
              </div>

              <button
                class="flex items-center gap-1.5 text-xs font-semibold text-shr border border-dashed border-shr-m hover:border-shr rounded-[6px] px-4 py-2 w-full justify-center transition-all hover:bg-shr-l"
                @click="applyStore.addShared(mountKey(s.uid, env))"
              >
                <span class="text-sm leading-none">＋</span> 新增 Shared Pool 申請
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>

  </div>
</template>

<script setup>
import { computed } from 'vue'
import { useApplyStore } from '../../stores/apply'
import { usePoolsStore } from '../../stores/pools'

const applyStore = useApplyStore()
const poolsStore = usePoolsStore()

const ENV_STYLE = {
  Prod: { dot: 'bg-grn', text: 'text-grn', badge: 'bg-grn-l text-grn border-grn-m' },
  UAT:  { dot: 'bg-pur', text: 'text-pur', badge: 'bg-pur-l text-pur border-pur-m' },
}
const CLOUD_LABELS = { private: '私有雲', hicloud: 'hiCloud', aws: 'AWS' }

const quotaFields = [
  { key: 'est_cpu',  label: 'CPU 配額 (Core)' },
  { key: 'est_mem',  label: 'Memory 配額 (GB)' },
  { key: 'est_disk', label: 'Disk 配額 (GB)' },
]

const dedPools = computed(() =>
  poolsStore.poolsWithUsed.filter(p => p.type === 'dedicated' && p.status === 'active')
)
const shrPools = computed(() =>
  poolsStore.poolsWithUsed.filter(p => p.type === 'shared' && p.status === 'active')
)

function envStyle(env) { return ENV_STYLE[env] ?? ENV_STYLE.UAT }
function cloudLabel(c) { return CLOUD_LABELS[c] ?? c }
function mountKey(uid, env) { return `${uid}:${env}` }
function mount(uid, env) {
  return applyStore.poolMounts[mountKey(uid, env)] ?? { dedicated: null, shared: [] }
}
function cpuFree(p) { return p ? (p.cpu.t - p.cpu.u) : '—' }
function memFree(p) { return p ? (p.mem.t - p.mem.u) : '—' }
function shrPoolById(id) { return shrPools.value.find(p => p.id === id) ?? null }
</script>

<style scoped>
@reference "../../assets/main.css";
</style>
