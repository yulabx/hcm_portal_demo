<template>
  <Teleport to="body">
    <Transition name="modal">
      <div
        v-if="visible"
        class="fixed inset-0 z-50 flex items-center justify-center p-4"
        style="background:rgba(15,15,15,.45);backdrop-filter:blur(2px)"
        @click.self="cancel"
      >
        <div class="bg-white rounded-[10px] shadow-lg w-full max-w-[360px] p-6">
          <div class="text-base font-bold text-ink mb-2">{{ title }}</div>
          <div v-if="message" class="text-xs text-ink-3 mb-5 leading-relaxed">{{ message }}</div>
          <div class="flex gap-2 justify-end" :class="message ? '' : 'mt-4'">
            <button
              class="px-4 py-2 text-xs font-semibold text-ink-3 border border-bord rounded-[6px] bg-white hover:bg-surf-2 transition-all"
              @click="cancel"
            >
              取消
            </button>
            <button
              class="px-4 py-2 text-xs font-bold text-white bg-shr rounded-[6px] hover:opacity-80 transition-all"
              @click="ok"
            >
              {{ okLabel }}
            </button>
          </div>
        </div>
      </div>
    </Transition>
  </Teleport>
</template>

<script setup>
import { useConfirm } from '../../composables/useConfirm'

defineProps({
  okLabel: { type: String, default: '確認執行' },
})

const { visible, title, message, ok, cancel } = useConfirm()
</script>

<style scoped>
.modal-enter-active,
.modal-leave-active { transition: opacity .15s ease; }
.modal-enter-from,
.modal-leave-to     { opacity: 0; }
</style>
