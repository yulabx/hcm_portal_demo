<template>
  <div class="flex flex-col gap-4">
    <div
      v-for="(group, gi) in groups" :key="group.type"
      class="bg-white border rounded-[8px] shadow-sm overflow-hidden"
      :class="group.type === 'dedicated' ? 'border-ded-m' : 'border-shr-m'"
      :style="{ animationDelay: gi * 80 + 'ms' }"
    >
      <!-- Group header -->
      <div
        class="flex items-center gap-2 px-4 py-2.5 border-b"
        :class="group.type === 'dedicated'
          ? 'border-ded-m bg-gradient-to-r from-ded-l to-white'
          : 'border-shr-m bg-gradient-to-r from-shr-l to-white'"
      >
        <div
          class="w-2.5 h-2.5 rounded-full"
          :style="{ background: group.type === 'dedicated' ? '#2563eb' : '#0d9488' }"
        />
        <span class="text-xs font-bold text-ink-2">
          {{ group.type === 'dedicated' ? 'Dedicated 專屬' : 'Shared 共用' }}
        </span>
        <span class="text-[10px] text-ink-4 font-mono ml-1">
          {{ group.pools.length }} pools · {{ group.totalItems }} items
        </span>
      </div>

      <!-- Pool rows -->
      <div>
        <PoolRow
          v-for="pool in group.pools"
          :key="pool.id"
          :pool="pool"
          :vms="vmsStore.byPool(pool.id)"
          :allocs="allocsStore.byPool(pool.id)"
          :cloud-color="cloudColor"
        />
      </div>
    </div>

    <div v-if="!groups.length" class="py-16 text-center text-xs text-ink-4">
      此站點尚無 Pool
    </div>
  </div>
</template>

<script setup>
import { computed } from 'vue'
import { useVmsStore }         from '../../stores/vms'
import { useAllocationsStore } from '../../stores/allocations'
import PoolRow from './PoolRow.vue'

const props = defineProps({
  pools:      { type: Array,  required: true },
  cloudColor: { type: String, default: '#2563eb' },
})

const vmsStore   = useVmsStore()
const allocsStore = useAllocationsStore()

const groups = computed(() => {
  const ded = props.pools.filter(p => p.type === 'dedicated')
  const shr = props.pools.filter(p => p.type === 'shared')
  const result = []
  if (ded.length) result.push({
    type: 'dedicated',
    pools: ded,
    totalItems: ded.reduce((s, p) => s + vmsStore.byPool(p.id).length, 0),
  })
  if (shr.length) result.push({
    type: 'shared',
    pools: shr,
    totalItems: shr.reduce((s, p) => s + allocsStore.byPool(p.id).length, 0),
  })
  return result
})
</script>
