<template>
  <div class="border-b border-bord last:border-b-0" :class="{ 'open': expanded }">
    <!-- Pool header row -->
    <div
      class="grid items-center gap-4 px-4 py-3 cursor-pointer transition-colors hover:bg-surf-2"
      :class="expanded ? 'bg-or-l border-b-2 border-or' : ''"
      style="grid-template-columns: 88px 1fr auto"
      @click="expanded = !expanded"
    >
      <!-- Pool ID badge -->
      <span
        class="font-mono text-[11px] font-semibold px-2 py-1 rounded-[4px] text-center border"
        :class="pool.type === 'dedicated' ? 'bg-ded-l text-ded border-ded-m' : 'bg-shr-l text-shr border-shr-m'"
      >{{ pool.id }}</span>

      <!-- Pool info -->
      <div>
        <div class="text-xs font-semibold text-ink">{{ pool.name }}</div>
        <div class="flex items-center gap-1.5 mt-1 flex-wrap">
          <PoolTypeBadge :type="pool.type" />
          <EnvBadge :env="pool.env" />
          <span v-if="pool.siteName" class="text-[9px] font-semibold px-1.5 py-0.5 rounded-[3px] border bg-surf-2 border-bord text-ink-3">{{ pool.siteName }}</span>
        </div>
      </div>

      <!-- Count + chevron -->
      <div class="flex items-center gap-2">
        <span class="text-[10px] font-semibold px-2 py-0.5 rounded-[3px] bg-surf-2 border border-bord text-ink-3 font-mono">
          {{ itemCount }} {{ pool.type === 'dedicated' ? 'VMs' : 'Allocs' }}
        </span>
        <span
          class="text-xs text-ink-4 transition-transform duration-200"
          :class="expanded ? 'rotate-180 text-or' : ''"
        >▾</span>
      </div>
    </div>

    <!-- Resource bars -->
    <div class="grid gap-3 px-4 py-3 border-b border-bord bg-white" style="grid-template-columns: repeat(3, 1fr)">
      <ResourceBar label="CPU"    :used="pool.cpu?.u ?? 0"  :total="pool.cpu?.t  ?? 0" unit="C"  :color="cloudColor" />
      <ResourceBar label="Memory" :used="pool.mem?.u ?? 0"  :total="pool.mem?.t  ?? 0" unit="GB" color="#0d9488" />
      <ResourceBar label="Disk"   :used="pool.disk?.u ?? 0" :total="pool.disk?.t ?? 0" unit="TB" color="#16a34a" />
    </div>

    <!-- Expand panel -->
    <div v-show="expanded" class="bg-surf-2 border-l-[3px] border-or">
      <!-- Panel header -->
      <div class="flex items-center justify-between px-5 py-2.5 bg-or-l border-b border-bord">
        <span class="text-[11px] font-bold uppercase tracking-[.1em] text-or-d flex items-center gap-2">
          {{ pool.type === 'dedicated' ? '🖥 VM 清單' : '🔗 申請狀況' }}
          <span class="text-[9px] font-semibold px-1.5 py-0.5 rounded-[3px] bg-or-m/50 text-or-d">{{ itemCount }} 筆</span>
        </span>
        <button
          class="text-[11px] font-semibold text-ink-3 border border-bord bg-white px-2 py-1 rounded-[4px] hover:border-or hover:text-or transition-all"
          @click.stop="expanded = false"
        >✕ 收起</button>
      </div>

      <!-- Table -->
      <div class="overflow-x-auto">
        <VmExpandTable   v-if="pool.type === 'dedicated'" :vms="vms" />
        <AllocExpandTable v-else                           :allocs="allocs" />
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, computed } from 'vue'
import PoolTypeBadge    from '../common/PoolTypeBadge.vue'
import EnvBadge         from '../common/EnvBadge.vue'
import ResourceBar      from './ResourceBar.vue'
import VmExpandTable    from './VmExpandTable.vue'
import AllocExpandTable from './AllocExpandTable.vue'

const props = defineProps({
  pool:       { type: Object, required: true },
  vms:        { type: Array,  default: () => [] },
  allocs:     { type: Array,  default: () => [] },
  cloudColor: { type: String, default: '#2563eb' },
})

const expanded  = ref(false)
const itemCount = computed(() =>
  props.pool.type === 'dedicated' ? props.vms.length : props.allocs.length
)
</script>
