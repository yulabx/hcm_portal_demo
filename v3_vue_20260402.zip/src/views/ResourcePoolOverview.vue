<template>
  <div class="h-full flex flex-col">
    <!-- Page header -->
    <div class="px-8 py-5 bg-white border-b border-bord flex-shrink-0">
      <h1 class="text-sm font-bold text-ink">資源池總覽</h1>
      <p class="text-[11px] text-ink-4 mt-0.5 font-mono">Cloud → Site → Pool 維度鑽取</p>
    </div>

    <div class="flex-1 overflow-auto p-8">
      <!-- KPI Strip -->
      <KpiStrip :kpis="kpis" />

      <!-- ── Level 1: Cloud ── -->
      <div v-show="drillLevel === 'cloud'">
        <div class="flex items-center justify-between mb-3.5">
          <div class="flex items-center gap-2 text-xs font-bold tracking-[.06em] uppercase text-ink-2">
            <div class="w-[3px] h-[14px] bg-or rounded-full flex-shrink-0" />
            Cloud
            <span class="font-mono text-[10px] px-2 py-0.5 rounded-[3px] border border-bord bg-surf-2 text-ink-3">3 providers</span>
          </div>
          <div class="text-[11px] text-ink-4">CLOUD → SITE → POOL</div>
        </div>
        <div class="grid gap-3" style="grid-template-columns: repeat(3, 1fr)">
          <CloudCard
            v-for="cloud in clouds" :key="cloud"
            :cloud="cloud"
            :stats="cloudStats[cloud]"
            :selected="selectedCloud === cloud"
            :dim="selectedCloud !== null && selectedCloud !== cloud"
            @drill="drillCloud"
          />
        </div>
      </div>

      <!-- ── Level 2: Site ── -->
      <div v-show="drillLevel === 'site'">
        <div class="flex items-center gap-2.5 mb-4 flex-wrap">
          <button class="back-btn" @click="backToCloud">← Cloud</button>
          <div class="flex items-center gap-1.5 text-xs font-medium">
            <span class="text-ink-4 cursor-pointer hover:text-or transition-colors" @click="backToCloud">Cloud</span>
            <span class="text-bord-2">/</span>
            <span class="text-ink font-bold">{{ CLOUD_META[selectedCloud]?.label }}</span>
          </div>
          <span class="ml-auto font-mono text-[10px] px-2 py-0.5 rounded-[3px] border border-bord bg-surf-2 text-ink-3">
            {{ currentSites.length }} sites
          </span>
        </div>
        <div class="grid gap-3" style="grid-template-columns: repeat(auto-fill, minmax(260px, 1fr))">
          <SiteCard
            v-for="(site, i) in currentSites" :key="site.id"
            :site="site"
            :pools-map="poolsMap"
            :selected="selectedSite === site.id"
            :dim="selectedSite !== null && selectedSite !== site.id"
            :style="{ animationDelay: i * 60 + 'ms' }"
            @drill="drillSite"
          />
        </div>
      </div>

      <!-- ── Level 3: Pool ── -->
      <div v-show="drillLevel === 'pool'">
        <div class="flex items-center gap-2.5 mb-4 flex-wrap">
          <button class="back-btn" @click="backToSite">← Site</button>
          <div class="flex items-center gap-1.5 text-xs font-medium">
            <span class="text-ink-4 cursor-pointer hover:text-or transition-colors" @click="backToCloud">Cloud</span>
            <span class="text-bord-2">/</span>
            <span class="text-ink-4 cursor-pointer hover:text-or transition-colors" @click="backToSite">{{ CLOUD_META[selectedCloud]?.label }}</span>
            <span class="text-bord-2">/</span>
            <span class="text-ink font-bold">{{ currentSiteObj?.name }}</span>
          </div>
          <span class="ml-auto font-mono text-[10px] px-2 py-0.5 rounded-[3px] border border-bord bg-surf-2 text-ink-3">
            {{ currentPools.length }} pools
          </span>
        </div>
        <PoolGroupList
          :pools="currentPools"
          :cloud-color="CLOUD_META[selectedCloud]?.color ?? '#2563eb'"
        />
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, computed } from 'vue'
import { usePoolsStore }       from '../stores/pools'
import { useVmsStore }         from '../stores/vms'
import { useAllocationsStore } from '../stores/allocations'
import { useProjectsStore }    from '../stores/projects'
import KpiStrip      from '../components/overview/KpiStrip.vue'
import CloudCard     from '../components/overview/CloudCard.vue'
import SiteCard      from '../components/overview/SiteCard.vue'
import PoolGroupList from '../components/overview/PoolGroupList.vue'

const poolsStore    = usePoolsStore()
const vmsStore      = useVmsStore()
const allocsStore   = useAllocationsStore()
const projectsStore = useProjectsStore()

// ── Cloud metadata ────────────────────────────────────
const CLOUD_META = {
  private: { label: '私有雲', abbr: 'PRI', color: '#2563eb', iconBg: '#eff6ff', region: '台北 · 台中' },
  hicloud: { label: 'hiCloud', abbr: 'HIC', color: '#0e7490', iconBg: '#f0fdfa', region: '東七'       },
  aws:     { label: 'AWS',     abbr: 'AWS', color: '#b45309', iconBg: '#fffbeb', region: '台灣'       },
}
const clouds = ['private', 'hicloud', 'aws']

const SITE_META = {
  'tp-main': { name: '台北主中心',   region: '台北市', type: 'main' },
  'tc-dr':   { name: '台中異備中心', region: '台中市', type: 'dr'   },
  'e7-main': { name: '東七主中心',   region: '東七區', type: 'main' },
  'tw-main': { name: '台灣主中心',   region: '台灣',   type: 'main' },
}

// ── Drill state ───────────────────────────────────────
const drillLevel   = ref('cloud')
const selectedCloud = ref(null)
const selectedSite  = ref(null)

function drillCloud(cloud) {
  selectedCloud.value = cloud
  selectedSite.value  = null
  setTimeout(() => { drillLevel.value = 'site' }, 220)
}
function drillSite(siteId) {
  selectedSite.value = siteId
  setTimeout(() => { drillLevel.value = 'pool' }, 200)
}
function backToCloud() {
  drillLevel.value    = 'cloud'
  selectedCloud.value = null
  selectedSite.value  = null
}
function backToSite() {
  drillLevel.value   = 'site'
  selectedSite.value = null
}

// ── Computed: pool lookup map ─────────────────────────
const poolsMap = computed(() =>
  Object.fromEntries(
    poolsStore.poolsWithUsed.map(p => [p.id, {
      ...p,
      vmCount: vmsStore.byPool(p.id).length,
    }])
  )
)

// ── Computed: cloud stats ─────────────────────────────
const cloudStats = computed(() => {
  const result = {}
  for (const cloud of clouds) {
    const cp = poolsStore.poolsWithUsed.filter(p => p.cloud === cloud)
    const siteIds = [...new Set(cp.map(p => p.site_id))]
    result[cloud] = {
      dedCount:   cp.filter(p => p.type === 'dedicated').length,
      shrCount:   cp.filter(p => p.type === 'shared').length,
      siteCount:  siteIds.length,
      vmCount:    cp.reduce((s, p) => s + vmsStore.byPool(p.id).length, 0),
      allocCount: cp.reduce((s, p) => s + allocsStore.byPool(p.id).length, 0),
      cpu:  { t: cp.reduce((s, p) => s + (p.cpu?.t  ?? 0), 0), u: cp.reduce((s, p) => s + (p.cpu?.u  ?? 0), 0) },
      mem:  { t: cp.reduce((s, p) => s + (p.mem?.t  ?? 0), 0), u: cp.reduce((s, p) => s + (p.mem?.u  ?? 0), 0) },
      disk: { t: cp.reduce((s, p) => s + (p.disk?.t ?? 0), 0), u: cp.reduce((s, p) => s + (p.disk?.u ?? 0), 0) },
    }
  }
  return result
})

// ── Computed: sites by cloud ──────────────────────────
const sitesByCloud = computed(() => {
  const result = {}
  for (const pool of poolsStore.poolsWithUsed) {
    const ck = pool.cloud
    if (!result[ck]) result[ck] = {}
    if (!result[ck][pool.site_id]) {
      result[ck][pool.site_id] = {
        id: pool.site_id,
        ...(SITE_META[pool.site_id] ?? { name: pool.site_id, region: '', type: 'main' }),
        pools: [],
        cpu:  { u: 0, t: 0 },
        mem:  { u: 0, t: 0 },
        disk: { u: 0, t: 0 },
      }
    }
    const site = result[ck][pool.site_id]
    site.pools.push(pool.id)
    site.cpu.u  += pool.cpu?.u  ?? 0;  site.cpu.t  += pool.cpu?.t  ?? 0
    site.mem.u  += pool.mem?.u  ?? 0;  site.mem.t  += pool.mem?.t  ?? 0
    site.disk.u += pool.disk?.u ?? 0;  site.disk.t += pool.disk?.t ?? 0
  }
  return Object.fromEntries(
    Object.entries(result).map(([ck, sites]) => [ck, Object.values(sites)])
  )
})

const currentSites   = computed(() => sitesByCloud.value[selectedCloud.value] ?? [])
const currentSiteObj = computed(() => currentSites.value.find(s => s.id === selectedSite.value))
const currentPools   = computed(() =>
  poolsStore.poolsWithUsed.filter(p =>
    p.cloud === selectedCloud.value && p.site_id === selectedSite.value
  )
)

// ── KPI Strip ─────────────────────────────────────────
const kpis = computed(() => {
  const allVms = vmsStore.vms
  const running = allVms.filter(v => v.status === 'running').length
  const stopped = allVms.filter(v => v.status === 'stopped').length
  return [
    { value: projectsStore.projects.length,                              label: 'Projects',        sub: projectsStore.projects.map(p => p.name).join(' / ') || '—' },
    { value: poolsStore.pools.filter(p => p.type === 'dedicated').length, label: 'Dedicated Pools', sub: 'P-series'  },
    { value: poolsStore.pools.filter(p => p.type === 'shared').length,    label: 'Shared Pools',    sub: 'S-series'  },
    { value: clouds.length,                                               label: 'Cloud Providers', sub: '私有雲 · hiCloud · AWS' },
    { value: allVms.length,                                               label: 'VMs',             sub: `Running ${running} / Stopped ${stopped}` },
  ]
})
</script>

<style scoped>
@reference "../assets/main.css";
.back-btn {
  @apply flex items-center gap-1 text-[11px] font-bold text-ink-2 border border-bord bg-white px-[11px] py-[5px] rounded-[5px] transition-all hover:border-or hover:text-or cursor-pointer;
}
</style>
