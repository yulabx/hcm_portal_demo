<template>
  <Teleport to="body">
    <Transition name="modal">
      <div
        v-if="modelValue"
        class="fixed inset-0 z-50 flex items-center justify-center p-4"
        style="background:rgba(15,15,15,.45);backdrop-filter:blur(2px)"
        @click.self="$emit('update:modelValue', false)"
      >
        <div class="bg-white rounded-[10px] shadow-lg w-full max-w-[520px] max-h-[90vh] overflow-y-auto">
          <!-- Header -->
          <div class="flex items-center justify-between px-6 py-4 border-b border-bord">
            <div>
              <h2 class="text-sm font-bold text-ink">{{ isEdit ? `調整 Allocation — ${form.systemName}` : `新增 Allocation — ${pool?.id}` }}</h2>
              <p class="text-[11px] text-ink-4 mt-0.5">{{ pool?.name }}</p>
            </div>
            <button class="w-7 h-7 flex items-center justify-center rounded-full hover:bg-surf-2 text-ink-4 text-lg cursor-pointer" @click="$emit('update:modelValue', false)">✕</button>
          </div>

          <!-- Pool capacity summary -->
          <div class="px-6 pt-4">
            <div class="bg-surf-2 border border-bord rounded-[8px] p-4 flex flex-col gap-3 mb-4">
              <div class="text-[10px] font-bold uppercase tracking-[.1em] text-ink-4 mb-1">
                {{ pool?.id }} · {{ pool?.name }} — 可用容量
              </div>
              <div class="grid gap-4" style="grid-template-columns: repeat(3, 1fr)">
                <div v-for="(bar, i) in capacityBars" :key="i">
                  <div class="flex justify-between text-[10px] mb-1">
                    <span class="text-ink-4">{{ bar.label }}</span>
                    <span class="font-mono text-shr font-semibold">剩 {{ bar.free }}{{ bar.unit }}</span>
                  </div>
                  <div class="h-[5px] rounded-full bg-surf-2 overflow-hidden">
                    <div class="h-full rounded-full" :style="{ width: bar.pct + '%', background: bar.color }" />
                  </div>
                  <div class="text-[10px] text-ink-4 font-mono mt-0.5">總 {{ bar.total }}{{ bar.unit }}</div>
                </div>
              </div>
            </div>
          </div>

          <!-- Form body -->
          <div class="px-6 pb-2 flex flex-col gap-4">
            <!-- System / Project -->
            <div class="grid gap-3" style="grid-template-columns: 1fr 1fr">
              <div class="flex flex-col gap-1.5">
                <label class="label">系統名稱 <span class="text-red">*</span></label>
                <input
                  v-model="form.systemName"
                  :disabled="isEdit"
                  type="text" placeholder="例：ERP"
                  class="field" :class="{ 'opacity-60 bg-surf-2': isEdit }"
                />
              </div>
              <div class="flex flex-col gap-1.5">
                <label class="label">專案</label>
                <input
                  v-model="form.projectName"
                  :disabled="isEdit"
                  type="text" placeholder="例：電發專案"
                  class="field" :class="{ 'opacity-60 bg-surf-2': isEdit }"
                />
              </div>
            </div>

            <!-- Env -->
            <div class="flex flex-col gap-1.5">
              <label class="label">環境</label>
              <div class="flex gap-3">
                <label class="flex items-center gap-1.5 cursor-pointer">
                  <input v-model="form.env" type="radio" value="Prod" class="accent-[#16a34a]">
                  <span class="text-xs font-semibold text-grn">Prod</span>
                </label>
                <label class="flex items-center gap-1.5 cursor-pointer">
                  <input v-model="form.env" type="radio" value="UAT" class="accent-[#7c3aed]">
                  <span class="text-xs font-semibold text-pur">UAT</span>
                </label>
              </div>
            </div>

            <!-- Quota -->
            <div>
              <div class="flex items-center gap-2 mb-3">
                <div class="w-[3px] h-3.5 bg-shr rounded-full"></div>
                <span class="text-[11px] font-bold uppercase tracking-[.06em] text-ink-2">配額設定</span>
              </div>
              <div class="grid gap-3" style="grid-template-columns: repeat(3, 1fr)">
                <div class="flex flex-col gap-1.5">
                  <label class="label">CPU <span class="text-ink-4 font-normal">(Core)</span></label>
                  <input
                    v-model.number="form.cpu"
                    type="number" min="0" :max="freeCpu" placeholder="0"
                    class="field font-mono"
                    :class="{ 'over-limit': form.cpu > freeCpu }"
                  />
                  <span class="text-[10px] text-ink-4">可分配 {{ freeCpu }}C</span>
                </div>
                <div class="flex flex-col gap-1.5">
                  <label class="label">Memory <span class="text-ink-4 font-normal">(GB)</span></label>
                  <input
                    v-model.number="form.mem"
                    type="number" min="0" :max="freeMem" placeholder="0"
                    class="field font-mono"
                    :class="{ 'over-limit': form.mem > freeMem }"
                  />
                  <span class="text-[10px] text-ink-4">可分配 {{ freeMem }}GB</span>
                </div>
                <div class="flex flex-col gap-1.5">
                  <label class="label">Disk <span class="text-ink-4 font-normal">(TB)</span></label>
                  <input
                    v-model.number="form.disk"
                    type="number" min="0" step="0.1" :max="freeDisk" placeholder="0"
                    class="field font-mono"
                    :class="{ 'over-limit': form.disk > freeDisk }"
                  />
                  <span class="text-[10px] text-ink-4">可分配 {{ freeDisk.toFixed(1) }}TB</span>
                </div>
              </div>
            </div>
          </div>

          <!-- Error -->
          <div v-if="errorMsg" class="mx-6 mb-3 text-[11px] text-red bg-red-l border border-red-m rounded-[6px] px-3 py-2">
            {{ errorMsg }}
          </div>

          <!-- Footer -->
          <div class="flex items-center justify-between px-6 py-4 border-t border-bord bg-surf-2 rounded-b-[10px] mt-2">
            <button class="cancel-btn" @click="$emit('update:modelValue', false)">取消</button>
            <button class="submit-btn" @click="submit">▶ 執行開通</button>
          </div>
        </div>
      </div>
    </Transition>
  </Teleport>
</template>

<script setup>
import { ref, computed, watch } from 'vue'

const props = defineProps({
  modelValue: { type: Boolean, default: false },
  pool:       { type: Object,  default: null  },
  allAllocs:  { type: Array,   default: () => [] }, // all active allocs for this pool
  editAlloc:  { type: Object,  default: null  },    // non-null = edit mode
  // pre-fill from pending request
  prefill:    { type: Object,  default: null  },
})
const emit = defineEmits(['update:modelValue', 'save'])

const isEdit   = computed(() => !!props.editAlloc)
const errorMsg = ref('')

const form = ref({ systemName: '', projectName: '', env: 'Prod', cpu: '', mem: '', disk: '' })

watch(() => props.modelValue, (open) => {
  if (!open) return
  errorMsg.value = ''
  if (props.editAlloc) {
    form.value = {
      systemName:  props.editAlloc.systemName,
      projectName: props.editAlloc.projectName,
      env:         props.editAlloc.env,
      cpu:         props.editAlloc.quota_cpu,
      mem:         props.editAlloc.quota_mem_gb,
      disk:        props.editAlloc.quota_disk_tb,
    }
  } else if (props.prefill) {
    form.value = {
      systemName:  props.prefill.systemName  ?? '',
      projectName: props.prefill.projectName ?? '',
      env:         props.prefill.env         ?? 'Prod',
      cpu:         props.prefill.cpu         ?? '',
      mem:         props.prefill.mem         ?? '',
      disk:        props.prefill.disk        ?? '',
    }
  } else {
    form.value = { systemName: '', projectName: '', env: 'Prod', cpu: '', mem: '', disk: '' }
  }
})

// Capacity available = pool total - sum of OTHER active allocs (exclude self when editing)
const otherAllocs = computed(() => {
  if (!props.pool) return []
  const active = props.allAllocs.filter(a => a.pool_id === props.pool.id && a.status === 'active')
  return props.editAlloc ? active.filter(a => a.id !== props.editAlloc.id) : active
})
const freeCpu  = computed(() => (props.pool?.cpu.t  ?? 0) - otherAllocs.value.reduce((s, a) => s + (a.quota_cpu     ?? 0), 0))
const freeMem  = computed(() => (props.pool?.mem.t  ?? 0) - otherAllocs.value.reduce((s, a) => s + (a.quota_mem_gb  ?? 0), 0))
const freeDisk = computed(() => (props.pool?.disk.t ?? 0) - otherAllocs.value.reduce((s, a) => s + (a.quota_disk_tb ?? 0), 0))

function barColor(p) { return p >= 85 ? '#dc2626' : p >= 70 ? '#d97706' : '#0d9488' }

const capacityBars = computed(() => {
  if (!props.pool) return []
  const pairs = [
    { label: 'CPU',  total: props.pool.cpu.t,  free: freeCpu.value,  unit: 'C'  },
    { label: 'Mem',  total: props.pool.mem.t,  free: freeMem.value,  unit: 'GB' },
    { label: 'Disk', total: props.pool.disk.t, free: +freeDisk.value.toFixed(1), unit: 'TB' },
  ]
  return pairs.map(p => {
    const used = p.total - p.free
    const pct  = p.total ? Math.min(100, Math.round(used / p.total * 100)) : 0
    return { ...p, pct, color: barColor(pct) }
  })
})

function submit() {
  errorMsg.value = ''
  if (!form.value.systemName.trim()) { errorMsg.value = '請填寫系統名稱'; return }
  const cpu  = Number(form.value.cpu)  || 0
  const mem  = Number(form.value.mem)  || 0
  const disk = Number(form.value.disk) || 0
  if (cpu  > freeCpu.value)  { errorMsg.value = `CPU 超過可分配量（最多 ${freeCpu.value}C）`;         return }
  if (mem  > freeMem.value)  { errorMsg.value = `Memory 超過可分配量（最多 ${freeMem.value}GB）`;     return }
  if (disk > freeDisk.value) { errorMsg.value = `Disk 超過可分配量（最多 ${freeDisk.value.toFixed(1)}TB）`; return }
  emit('save', { systemName: form.value.systemName.trim(), projectName: form.value.projectName.trim(), env: form.value.env, quota_cpu: cpu, quota_mem_gb: mem, quota_disk_tb: disk })
  emit('update:modelValue', false)
}
</script>

<style scoped>
@reference "../../assets/main.css";
.label      { @apply text-[11px] font-semibold text-ink-2; }
.field      { @apply border border-bord rounded-[6px] px-3 py-2 text-xs bg-white transition-all outline-none focus:border-shr; }
.over-limit { @apply border-red! shadow-[0_0_0_3px_rgba(220,38,38,.1)]!; }
.cancel-btn { @apply px-4 py-2 text-xs font-semibold text-ink-3 border border-bord rounded-[6px] bg-white hover:bg-surf-2 transition-all cursor-pointer; }
.submit-btn { @apply px-5 py-2 text-xs font-bold text-white bg-shr rounded-[6px] hover:bg-shr/80 transition-all cursor-pointer; }
</style>
