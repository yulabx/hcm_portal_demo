<template>
  <span
    class="text-[9px] font-bold uppercase tracking-wide px-1.5 py-0.5 rounded-[3px] border"
    :class="env === 'Prod'
      ? 'bg-grn-l text-grn border-grn-m'
      : 'bg-pur-l text-pur border-pur-m'"
  >
    {{ env }}
  </span>
</template>

<script setup>
defineProps({
  env: { type: String, required: true },  // 'Prod' | 'UAT'
})
</script>
