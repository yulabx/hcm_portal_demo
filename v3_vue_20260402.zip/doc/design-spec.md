# 雲地整合平台（HCM Portal）設計規格

> 版本：v3.1　　最後更新：2026-04-02

---

## 目錄

1. [系統定位](#1-系統定位)
2. [頁面架構](#2-頁面架構)
3. [業務流程](#3-業務流程)
4. [資料模型](#4-資料模型)
5. [頁面功能說明](#5-頁面功能說明)
6. [設計規範](#6-設計規範)
7. [技術規格](#7-技術規格)

---

## 1. 系統定位

雲地整合平台（HCM, Hybrid Cloud Management）是給政府 / 企業 IT 部門使用的混合雲資源管理入口，橫跨三種雲端環境、多個站點，統一管理資源池容量、配額分配與 VM 生命週期。

### 1.1 支援雲端環境

| 雲端 | 說明 | 站點代碼 |
|------|------|----------|
| 私有雲 | 自建機房 | `tp-main`（台北主中心）、`tc-dr`（台中異備） |
| hiCloud | 中華電信政府雲 | `e7-main`（東七機房） |
| AWS | 公有雲台灣 Region | `tw-main`（台灣 Region） |

### 1.2 三個核心維度

| 維度 | 說明 | 對應物件 |
|------|------|----------|
| **資源供給**（Infrastructure） | 雲端 → 站點 → 資源池 | Pool |
| **使用需求**（Application） | 專案 → 系統 → 環境 | Project / System |
| **關聯**（Governance） | 供給與需求的橋接層 | Allocation |

> Resource Pool 管資源，Project / System 管需求，Allocation 管關係。

### 1.3 使用者角色

| 角色 | 功能範圍 |
|------|----------|
| **一般使用者** | 申請專案 / 系統、在已核准的 Pool 內建立與管理 VM |
| **管理員** | 維護 Pool 與 Subnet 設定、分配配額（Allocation）、審核並執行開通申請 |

---

## 2. 頁面架構

### 2.1 頁面關聯圖

```
┌──────────────────────────────┐  ┌──────────────────────────────┐
│  resource-pool-overview.html │  │   proj-overview.html         │
│  資源池總覽（Cloud 維度）      │  │   資源池總覽（專案維度）        │
│  Cloud → Site → Pool 鑽取    │  │   Project → System → Pool    │
└──────┬───────────────────────┘  └──────────────────────────────┘
       │
       ├──────────────────────────────────────┐
       │                                      │
       ↓                                      ↓
┌─────────────────┐  ┌───────────┐  ┌────────────────────┐
│   apply.html    │  │  vm.html  │  │ settings-pool.html │
│  申請專案/系統   │  │ 管理 VM   │  │ Pool & Subnet 管理  │
│  （使用者）      │  │ （使用者） │  │  （管理員）          │
└─────────────────┘  └───────────┘  └────────┬───────────┘
                                             │
                                             ↓
                                    ┌─────────────────────┐
                                    │   allocation.html   │
                                    │  配額管理 & 審核     │
                                    │  （管理員）          │
                                    └─────────────────────┘
```

### 2.2 側邊欄導航結構（所有頁面一致）

```
─ 資源池總覽        → resource-pool-overview.html
─ 專案維度          → proj-overview.html
═════ 作業 ════
─ 申請 VM           → vm.html
─ 申請專案/系統      → apply.html
═════ 設定 ════
─ 使用者管理（待實作）
─ 系統設定
  ├ 專案管理（待實作）
  ├ 系統管理（待實作）
  ├ Pool 管理         → settings-pool.html
  └ Allocation 管理   → allocation.html
```

---

## 3. 業務流程

### 3.1 使用者申請流程

```
使用者 apply.html
  Step 1：選擇（或建立）專案
  Step 2：建立系統（1 或多個，各選 Prod / UAT 環境）
  Step 3：掛載 Pool
    ├── Dedicated Pool：選一個 → 1:1 專屬綁定此系統 + 環境
    └── Shared Pool：可多筆 → 填入估計配額（est_cpu / est_mem / est_disk）
  Step 4：預覽確認 → 送出申請單（REQ-YYYYMMDD-NNN）
          ↓
管理員 allocation.html（待執行申請 tab）
  ├── Dedicated Pool → 直接執行開通，無需另設配額
  └── Shared Pool → 設定正式 CPU / Mem / Disk 配額 → 執行開通
          ↓
使用者 vm.html → 在已取得的 Pool 內建立 VM（即時生效，無須審核）
```

### 3.2 VM 建立流程

```
vm.html 選擇 Pool → 點「新增 VM」
  ├── Dedicated Pool：直接填規格，驗證 Pool 剩餘容量
  └── Shared Pool：先選系統 Allocation（alloc_id），驗證配額剩餘量
填寫：VM 名稱 / 主機名稱 / 規格套餐 / 映像檔 / 磁碟大小 / 磁碟類型
       / Subnet / 系統角色 / IP / 初始狀態 / 備註
建立後：Pool 及 Allocation 的 used 量即時更新，表格插入新行
```

### 3.3 Subnet 管理流程

```
管理員 settings-pool.html → Subnet 管理 tab
  → 新增 Subnet（ID / 名稱 / CIDR / 類型 / Cloud / site_id）
          ↓
  Pool 管理 tab → 編輯 Pool → 勾選「可用 Subnet」
  （Subnet 清單依選擇的 Cloud 自動過濾）
          ↓
使用者 vm.html 建立 VM → Subnet 下拉只顯示此 Pool 的 subnet_ids 清單
```

---

## 4. 資料模型

### 4.1 資料層架構

系統採兩層資料格式：

| 層級 | 說明 | 位置 |
|------|------|------|
| **Storage（靜態 JSON）** | 原始主檔，欄位以語意命名 | `data/*.json` |
| **Runtime（頁面 in-memory）** | 由 DataService 轉換，計算 used / free 後供頁面使用 | JS 變數 |

關鍵差異：`data/pools.json` 只存 `cpu_total`，頁面內透過 VM 加總計算後轉成 `cpu: { u, t }` 的 runtime 物件。

---

### 4.2 Project

**Storage（`data/projects.json`）**

```
Project {
  id    : string   // PROJ-001 ...
  name  : string
  code  : string   // 英文代碼，e.g. POWER
  owner : string
  dept  : string
}
```

**現有資料（5 筆）**：

| ID | 名稱 | Code | 負責人 | 部門 |
|----|------|------|--------|------|
| PROJ-001 | 電發專案 | POWER | 王大明 | 資訊處 |
| PROJ-002 | 一科 | DEPT1 | 李小華 | 一科室 |
| PROJ-003 | 二科 | DEPT2 | 陳美玲 | 二科室 |
| PROJ-004 | 三科 | DEPT3 | 張志強 | 三科室 |
| PROJ-005 | 四科 | DEPT4 | 林佳蓉 | 四科室 |

---

### 4.3 System

**Storage（`data/systems.json`）**

```
System {
  id         : string             // SYS-001 ...
  project_id : string
  name       : string
  code       : string             // e.g. SYS-POWER
  envs       : ('Prod'|'UAT')[]
}
```

**現有資料（6 筆）**：

| ID | 專案 | 名稱 | 環境 |
|----|------|------|------|
| SYS-001 | PROJ-001 | 電發系統 | Prod, UAT |
| SYS-002 | PROJ-001 | 允獎APP | Prod, UAT |
| SYS-003 | PROJ-002 | 系統A | Prod |
| SYS-004 | PROJ-003 | 系統B | Prod |
| SYS-005 | PROJ-004 | 系統C | Prod |
| SYS-006 | PROJ-005 | 系統D | UAT |

---

### 4.4 Pool

**Storage（`data/pools.json`）**

```
Pool {
  id            : string            // P01–P10（Dedicated）、S01–S03（Shared）
  name          : string
  type          : 'dedicated' | 'shared'
  cloud         : 'private' | 'hicloud' | 'aws'
  site_id       : string            // tp-main | tc-dr | e7-main | tw-main
  site_role     : 'primary' | 'dr'
  env           : 'Prod' | 'UAT'
  project_id    : string | null     // Dedicated 有值；Shared 為 null
  system_id     : string | null     // Dedicated 有值；Shared 為 null
  cpu_total     : number            // Core
  mem_total_gb  : number            // GB
  disk_total_tb : number            // TB
  subnet_ids    : string[]          // SN01–SN10
  status        : 'active' | 'inactive'
}
```

**Runtime（頁面 in-memory，由 DataService 轉換）**

```
PoolRT {
  ...（同上基本欄位）
  cpu  : { u: number, t: number }   // used（由 VM 加總）/ total
  mem  : { u: number, t: number }   // GB
  disk : { u: number, t: number }   // GB（VM 層級），TB（Pool 總容量）
  vms  : VmRow[]                    // Dedicated Pool：VM 清單
  allocs : AllocRow[]               // Shared Pool：Allocation 清單
}
```

**站點對照表**：

| site_id | 說明 | Cloud | site_role |
|---------|------|-------|-----------|
| `tp-main` | 台北主中心 | private | primary |
| `tc-dr` | 台中異備 | private | dr |
| `e7-main` | 東七機房 | hicloud | primary |
| `tw-main` | 台灣 Region | aws | primary |

**備註**：
- Dedicated Pool：`project_id` / `system_id` 直接綁定，1:1 對應一個系統 + 環境
- Shared Pool：`project_id` = null，透過 Allocation 多對多關聯各系統
- Storage 的 `disk_total_tb` 為 TB（Pool 層級）；Runtime VM 的 `disk_gb` 為 GB（VM 層級）

**現有 Pool 清單（`data/pools.json`，13 筆）**：

| ID | 名稱 | 類型 | Cloud | site_id | Env | CPU(C) | Mem(GB) | Disk(TB) |
|----|------|------|-------|---------|-----|--------|---------|----------|
| P01 | 電發私有雲主中心-Prod | dedicated | private | tp-main | Prod | 120 | 256 | 10 |
| P02 | 電發私有雲主中心-UAT | dedicated | private | tp-main | UAT | 40 | 128 | 5 |
| P03 | 電發私有雲異備-Prod | dedicated | private | tc-dr | Prod | 80 | 256 | 10 |
| P04 | 電發私有雲異備-UAT | dedicated | private | tc-dr | UAT | 40 | 128 | 5 |
| P05 | 電發 hiCloud-Prod | dedicated | hicloud | e7-main | Prod | 80 | 192 | 8 |
| P06 | 電發 hiCloud-UAT | dedicated | hicloud | e7-main | UAT | 32 | 64 | 3 |
| P07 | 兌獎APP hiCloud-Prod | dedicated | hicloud | e7-main | Prod | 32 | 64 | 2 |
| P08 | 兌獎APP hiCloud-UAT | dedicated | hicloud | e7-main | UAT | 16 | 32 | 1 |
| P09 | 電發 AWS-Prod | dedicated | aws | tw-main | Prod | 64 | 128 | 5 |
| P10 | 電發 AWS-UAT | dedicated | aws | tw-main | UAT | 24 | 48 | 2 |
| S01 | 共用私有雲主中心-Prod | shared | private | tp-main | Prod | 200 | 384 | 15 |
| S02 | 共用私有雲異備-Prod | shared | private | tc-dr | Prod | 120 | 256 | 10 |
| S03 | 共用 hiCloud-Prod | shared | hicloud | e7-main | Prod | 160 | 320 | 12 |

---

### 4.5 Subnet

**Storage（`data/subnets.json`）**

```
Subnet {
  id      : string   // SN01–SN10
  name    : string
  cidr    : string
  type    : 'internal' | 'dmz' | 'management' | 'public'
  cloud   : 'private' | 'hicloud' | 'aws'
  site_id : string
  status  : 'active' | 'inactive'
}
```

**類型語意**：

| 類型 | 說明 | 顯示顏色 |
|------|------|----------|
| internal | 內部應用網段，VM 間互通 | 藍色 |
| dmz | 對外服務區，可存取公網 | 紅色 |
| management | 管理網段，SSH / 監控用 | 琥珀色 |
| public | 公開子網（AWS 用） | 綠色 |

**完整清單（10 筆）**：

| ID | 名稱 | CIDR | 類型 | Cloud | site_id |
|----|------|------|------|-------|---------|
| SN01 | 內部應用網段 | 10.10.1.0/24 | internal | private | tp-main |
| SN02 | DMZ 網段 | 10.10.2.0/24 | dmz | private | tp-main |
| SN03 | 管理網段 | 10.10.100.0/24 | management | private | tp-main |
| SN04 | UAT 內部網段 | 10.10.10.0/24 | internal | private | tp-main |
| SN05 | hiCloud 生產網段 | 172.16.1.0/24 | internal | hicloud | e7-main |
| SN06 | hiCloud UAT 網段 | 172.16.10.0/24 | internal | hicloud | e7-main |
| SN07 | AWS Public-A | 10.0.1.0/24 | public | aws | tw-main |
| SN08 | AWS Private-A | 10.0.2.0/24 | internal | aws | tw-main |
| SN09 | AWS Public-B | 10.0.3.0/24 | public | aws | tw-main |
| SN10 | AWS Private-B | 10.0.4.0/24 | internal | aws | tw-main |

---

### 4.6 Allocation

**Storage（`data/allocations.json`）**

```
Allocation {
  id            : string   // A001 ...
  pool_id       : string
  project_id    : string
  system_id     : string
  env           : 'Prod' | 'UAT'
  site_role     : 'primary' | 'dr'
  quota_cpu     : number   // Core
  quota_mem_gb  : number   // GB
  quota_disk_tb : number   // TB
  status        : 'active' | 'inactive'
}
```

**allocation.html 的 runtime 版本**（`ALLOCS[]`，使用顯示名稱而非 ID）

```
AllocRT {
  id       : string
  pool_id  : string
  project  : string   // 專案名稱（顯示用）
  system   : string   // 系統名稱（顯示用）
  env      : 'Prod' | 'UAT'
  cpu      : number   // 配額 Core
  mem      : number   // 配額 GB
  disk     : number   // 配額 TB
  status   : 'active' | 'inactive'
}
```

**vm.html 的 runtime 版本**（`AllocEntry[]`，含即時用量追蹤）

```
AllocEntry {
  ...Allocation
  used_cpu   : number   // 已建立 VM 的 vCPU 消耗（由 vms.json 計算）
  used_mem   : number   // GB
  used_disk  : number   // GB
  vms        : VM[]
}
```

**現有 Allocation（5 筆）**：

| ID | Pool | 專案 | 系統 | Env | 角色 | CPU(C) | Mem(GB) | Disk(TB) |
|----|------|------|------|-----|------|--------|---------|----------|
| A001 | S01 | PROJ-002 | SYS-003 | Prod | primary | 40 | 96 | 2 |
| A002 | S01 | PROJ-003 | SYS-004 | Prod | primary | 30 | 64 | 1.5 |
| A003 | S02 | PROJ-002 | SYS-003 | Prod | dr | 40 | 96 | 2 |
| A004 | S03 | PROJ-004 | SYS-005 | Prod | primary | 32 | 64 | 2 |
| A005 | S03 | PROJ-005 | SYS-006 | UAT | primary | 16 | 32 | 1 |

---

### 4.7 VM

**Storage（`data/vms.json`）**

```
VM {
  id        : string          // VM-001 ...
  name      : string          // e.g., vm-power-prod-01
  pool_id   : string
  alloc_id  : string | null   // Shared Pool → Allocation ID；Dedicated → null
  status    : 'running' | 'stopped'
  vcpu      : number
  ram_gb    : number
  disk_gb   : number
  ip        : string
  subnet_id : string | null   // SN01–SN10；tc-dr 站點目前為 null
  tags      : {
    project_id : string
    system_id  : string
    env        : 'Prod' | 'UAT'
    role       : 'app' | 'db' | 'gateway' | 'cache' | 'web' | ...
  }
}
```

**vm.html 的表單欄位**（runtime，建立時填入，不存入 JSON）

```
VmForm {
  alloc_id    : string | null
  name        : string
  hostname    : string        // 選填
  flavor      : string        // 規格套餐 ID
  vcpu_custom : number        // 僅自訂套餐時填入
  ram_custom  : number
  image       : string        // OS 映像檔
  disk        : number        // GB
  disk_type   : string        // ssd / hdd / gp3 / gp2 / io1 ...
  role        : string        // app / db / gateway ...
  subnet      : string        // Subnet ID
  ip          : string
  status      : 'running' | 'stopped'
  note        : string        // 選填
}
```

**備註**：
- `alloc_id` = null 代表 Dedicated Pool 的 VM，容量驗證直接對 Pool 進行
- `subnet_id` = null 代表 DR 站點（tc-dr）尚未設定 Subnet

**現有 VM 筆數：28 筆**（含 Dedicated 19 筆、Shared 9 筆）

---

### 4.8 申請單（Apply）

```
Request {
  id       : string        // REQ-YYYYMMDD-NNN
  project  : string        // 專案名稱（顯示用）
  systems  : string[]      // 系統名稱清單
  status   : 'pending' | 'done'
  created  : string        // YYYY-MM-DD
  note     : string
}
```

**PENDING_REQS（待執行申請，allocation.html 使用）**：

```
PendingReq {
  id         : string
  project    : string
  applicant  : string
  created    : string
  systems    : [{
    name     : string
    code     : string
    env      : 'Prod' | 'UAT'
    mounts   : [{
      pool_id  : string
      est_cpu  : number    // 使用者申請時填入的估計值
      est_mem  : number
      note     : string
    }]
  }]
}
```

**Step 2/3 的暫存狀態（apply.html，不進 HISTORY）**：

```
systems = [{ uid, name, code, envs: ('Prod'|'UAT')[] }]

poolMounts = {
  'sysUid:Prod': {
    dedicated : string | null,
    shared    : [{ pool_id, est_cpu, est_mem, est_disk }]
  }
}
```

---

## 5. 頁面功能說明

### 5.1 resource-pool-overview.html — 資源池總覽（Cloud 維度）

**用途**：三層鑽取的基礎設施視角，從 Cloud → Site → Pool 逐級展開。

#### KPI 條帶（固定摘要）

| 項目 | 值 |
|------|----|
| Projects | 5 |
| Dedicated Pools | 10 |
| Shared Pools | 3 |
| Cloud Providers | 3 |
| VMs | 28 |

#### 三層鑽取結構

| 層級 | UI 形式 | 展示內容 |
|------|---------|----------|
| Level 1：Cloud | 卡片網格 | Cloud 名稱、Pool 分布（Ded × N / Shr × N）、Sites / VMs / Allocs 計數、CPU / Mem / Disk 進度條 |
| Level 2：Site | 卡片網格 | Site 名稱、類型徽章（主中心 / 異備 DR）、Pool 計數、資源進度條 |
| Level 3：Pool | 分組列表 | Pool ID、名稱、類型與環境 Tag、System Tag、資源進度條；可展開顯示 VM 表格（Dedicated）或 Allocation 表格（Shared） |

**Level 3 Dedicated Pool 展開 VM 欄位**：VM 名稱、狀態、規格（vCPU / RAM / Disk）、環境、IP

**Level 3 Shared Pool 展開 Allocation 欄位**：專案、系統、環境、CPU 配額、Memory 配額

---

### 5.2 proj-overview.html — 資源池總覽（專案維度）

**用途**：以專案為主軸，查看各專案的資源分布，提供 Cloud View 與 System View 兩種視角。

#### 主要 UI 區塊

| 區塊 | 說明 |
|------|------|
| 專案 Tab 導航 | 水平可滾動 Tab，每個專案一個 Tab，含項目計數 |
| 篩選欄 | 搜尋 + 環境（Prod / UAT）+ 類型（Dedicated / Shared）|
| Cloud View | 依 Cloud → Site → Pool 層級展示此專案的資源分布（mini-pool 卡片，可展開）|
| System View | 依系統卡片切換，每個系統顯示其跨 Cloud / Site 的 Pool 清單 |

#### Cloud View 資料結構

```
cloudView = {
  [cloud]: {
    label : string,
    color : string,
    sites : [{
      name, type,
      pools : [{ id, name, type, env, role, sys }]
    }]
  }
}
```

#### System View 資料結構

```
sysView = {
  [systemName]: {
    icon  : string,
    pools : [{ id, cloud, site, env, role, type }]
  }
}
```

---

### 5.3 apply.html — 申請專案/系統

**用途**：四步驟嚮導，使用者提交資源申請。

| 步驟 | 功能 |
|------|------|
| Step 1 選擇專案 | 搜尋現有（from DataService）/ 勾選建立新專案（填名稱、代碼、負責人、部門） |
| Step 2 建立系統 | 一或多個系統，各填名稱、代碼、環境（Prod / UAT 複選） |
| Step 3 掛載 Pool | 每個系統 + 環境組合：Dedicated Pool 單選 + Shared Pool 多筆（各填 est_cpu / est_mem / est_disk）|
| Step 4 確認送出 | 摘要預覽 → 送出申請單（REQ-YYYYMMDD-NNN）|
| 申請記錄 tab | 篩選：全部 / 待執行 / 已完成；清單顯示 REQ ID、狀態、專案名、系統清單、日期 |

**驗證規則**：
- Step 2：每個系統至少選一個環境
- Step 3：每個系統 + 環境組合至少掛載一個 Pool（Dedicated 或 Shared 擇一即可）

---

### 5.4 settings-pool.html — Pool & Subnet 管理

**用途**：管理員維護 Pool 基本設定與 Subnet 清單。

#### Pool 管理 tab

| 功能 | 說明 |
|------|------|
| 表格瀏覽 | 全部 13 個 Pool，含類型、Cloud、環境、CPU / Mem / Disk、狀態 |
| 篩選 | 類型（Dedicated / Shared）× 環境（Prod / UAT）× 關鍵字 |
| 新增 Pool | ID / 名稱 / 類型 / 環境 / Cloud / Site / 容量（cpu_total / mem_total_gb / disk_total_tb）/ 可用 Subnet |
| 編輯 Pool | 同上，ID 不可改 |
| 刪除 Pool | 確認後移除 |
| Subnet 綁定 | 依選擇的 Cloud 過濾 Subnet 清單；勾選後存入 `subnet_ids[]` |

#### Subnet 管理 tab

| 功能 | 說明 |
|------|------|
| KPI | Total / 私有雲 / hiCloud / AWS 計數 |
| 表格瀏覽 | 全部 10 筆 Subnet，含 CIDR / 類型 / Cloud / site_id |
| 篩選 | Cloud × 關鍵字 |
| 新增 / 編輯 Subnet | ID / 名稱 / CIDR / 類型（Internal / DMZ / Management / Public）/ Cloud / Site |
| 刪除 Subnet | 同時清除所有 Pool 的 `subnet_ids` 中對應項目 |

---

### 5.5 allocation.html — Allocation 管理

**用途**：管理員分配 Shared Pool 配額、審核待執行申請。

#### KPI 條帶

| 項目 | 說明 |
|------|------|
| Shared Pools | S01 / S02 / S03，共 3 筆 |
| Allocations | 目前已分配筆數 |
| 待執行申請 | pending 狀態的申請單數 |
| 容量警示 | 使用率 ≥ 85% 的 Pool 數 |

#### Pool 配額 tab

| 功能 | 說明 |
|------|------|
| Pool 卡片 | 每個 Shared Pool 一張，含容量進度條（CPU / Mem / Disk） |
| Allocation 表格 | 欄位：系統、專案、環境、CPU (C)、Memory (GB)、Disk (TB)、操作 |
| 新增 Allocation | 選擇系統 → 填配額，即時驗證不超過剩餘容量 |
| 調整 / 移除 | 編輯或刪除已有的 Allocation |
| 容量警示 | 使用率 ≥ 85% → 紅色；70–85% → 橘色 |

#### 待執行申請 tab

| 功能 | 說明 |
|------|------|
| 申請卡片清單 | 顯示 REQ ID、專案、申請人（`applicant`）、申請日、系統清單（可展開）|
| 展開詳情 | 系統名稱、環境、Pool 掛載需求（含 est_cpu / est_mem）|
| 執行開通 | Shared Pool → Modal 設定正式配額後執行；Dedicated Pool → 直接執行 |
| 完成標記 | 所有系統配額設定完畢後，申請單狀態改為 done |

---

### 5.6 vm.html — 管理 VM

**用途**：使用者在自己擁有的 Pool 或 Allocation 配額內，自助新增 / 管理 VM。

| 功能 | 說明 |
|------|------|
| Pool 卡片列表 | 使用者可用的 Pool，含容量進度條（CPU / Mem / Disk，三色警示） |
| 環境篩選 | 全部 / Prod / UAT |
| VM 表格 | VM 名稱 / 狀態 / 規格 / 環境 / IP；每列含操作按鈕 |
| 啟動 / 停止 VM | 即時切換 running ↔ stopped |
| 新增 VM Modal | 見下方欄位說明 |
| 刪除 VM | 二次確認後移除，Pool / Allocation used 量回收 |

#### 新增 VM Modal 欄位

| 欄位 | 說明 | 顯示條件 |
|------|------|----------|
| 系統配額（alloc_id）| 選擇使用哪個 Allocation | 僅 Shared Pool |
| VM 名稱 | 必填，英數字 + 連字符 | 全部 |
| 主機名稱 | 選填 | 全部 |
| 規格套餐 | 依 Cloud 顯示不同選項 | 全部 |
| 自訂 vCPU / RAM | 手動輸入 | 私有雲「自訂」套餐 |
| 映像檔 | 依 Cloud 顯示不同 OS 選項 | 全部 |
| 磁碟大小（GB）| 數字輸入 | 全部 |
| 磁碟類型 | 私有雲：SSD / HDD；AWS：gp3 / gp2 / io1 | 全部 |
| 系統角色 | app / db / gateway / cache / web 等 | 全部 |
| Subnet | 此 Pool 的 subnet_ids 對應清單 | 全部 |
| IP 位址 | IPv4 格式 | 全部 |
| 初始狀態 | Running / Stopped（預設 Running）| 全部 |
| 備註 | 選填 | 全部 |
| 資源剩餘提示 | 即時顯示建立後剩餘容量；超過容量禁用確認鈕 | 全部 |

#### 規格套餐（FLAVORS）

**私有雲**：

| ID | vCPU | RAM |
|----|------|-----|
| s | 2 | 4 GB |
| m | 4 | 8 GB |
| l | 8 | 16 GB |
| xl | 8 | 32 GB |
| 2xl | 16 | 32 GB |
| 3xl | 16 | 64 GB |
| mem-m | 4 | 16 GB（記憶體優化）|
| mem-l | 8 | 64 GB（記憶體優化）|
| custom | — | 手動輸入 |

**hiCloud**：c1.small(1/2)、c1.medium(2/4)、c1.large(4/8)、c1.xlarge(8/16)、m1.large(2/4)、m1.xlarge(4/8)、m1.2xlarge(8/32)

**AWS**：t3.medium(2/4)、t3.large(2/8)、m5.large(2/8)、m5.xlarge(4/16)、m5.2xlarge(8/32)、r5.large(2/16)、r5.xlarge(4/32)、c5.large(2/4)、c5.xlarge(4/8)、c5.2xlarge(8/16)

#### 映像檔（IMAGES）

| Cloud | 選項 |
|-------|------|
| 私有雲 | Ubuntu 22.04 / 20.04、RHEL 9、Rocky Linux 9、CentOS Stream 9、Windows Server 2022 / 2019 |
| hiCloud | Ubuntu 22.04、RHEL 9、Rocky Linux 9、Windows Server 2022 |
| AWS | Ubuntu 22.04 AMI、RHEL 9 AMI、Amazon Linux 2023、Windows Server 2022 AMI |

---

## 6. 設計規範

### 6.1 色彩系統

| Token | 預設值 | 用途 |
|-------|--------|------|
| `or` | #ea580c | 主色、強調、CTA 按鈕 |
| `ded` | #2563eb | Dedicated Pool、藍色系元素 |
| `shr` | #0d9488 | Shared Pool、青色系元素 |
| `grn` | #16a34a | Prod 環境、Active 狀態、成功 |
| `pur` | #7c3aed | UAT 環境 |
| `red` | #dc2626 | 錯誤、停用、容量超限 |
| `amb` | #d97706 | 容量警告（70–85%）|
| `ink` | #0f0f0f | 主要文字 |
| `surf` | #ffffff / #f7f8fa | 背景層 |
| `bord` | #e8e8e8 / #d4d4d4 | 邊框 |

每個語意色有三個變體：`.l`（背景淺色）、`.m`（邊框中色）、`.DEFAULT`（文字深色）。

### 6.2 字體

| 用途 | 字體 |
|------|------|
| 介面文字 | Plus Jakarta Sans + Noto Sans TC |
| 程式碼 / ID / IP | Fira Code |

### 6.3 間距與圓角

| 元素 | 圓角 |
|------|------|
| 小徽章、Tag | 3–4px |
| 按鈕、Input | 6px |
| 卡片、Table 容器 | 8px |
| Modal | 10–12px |
| 全圓（Avatar、進度條）| 99px |

### 6.4 容量進度條顏色規則

| 使用率 | 顏色 |
|--------|------|
| < 70% | 綠色（`#16a34a`）|
| 70–85% | 橘色（`#d97706`）|
| ≥ 85% | 紅色（`#dc2626`）|

### 6.5 動畫

| 動畫 | 說明 |
|------|------|
| `fadeUp` | 元素出現，opacity 0→1 + translateY(6px)→0，22ms |
| `modalIn` | Modal 彈出，opacity + translateY(10px) + scale(.98)，20ms |
| Sidebar 收折 | width 220px→52px，transition 250ms cubic-bezier(.23,1,.32,1) |

---

## 7. 技術規格

### 7.1 技術棧

| 項目 | 選擇 |
|------|------|
| HTML | HTML5 |
| CSS | Tailwind CSS v3（CDN） |
| JavaScript | Vanilla JS（ES6+），無框架 |
| 字體 | Google Fonts CDN |
| 資料層 | `data/*.json`（靜態 JSON 檔）+ DataService 轉換層 |

### 7.2 資料檔結構

```
data/
  projects.json     # 5 筆專案（id, name, code, owner, dept）
  systems.json      # 6 筆系統（id, project_id, name, code, envs[]）
  pools.json        # 13 筆 Pool（P01-P10 Ded + S01-S03 Shared）
  subnets.json      # 10 筆 Subnet（SN01-SN10，統一 ID 格式）
  allocations.json  # 5 筆 Allocation（含 quota_* 欄位）
  vms.json          # 28 筆 VM（含 pool_id / alloc_id / tags）
```

### 7.3 重要設計決策

**1. Storage vs Runtime 資料格式分層**

JSON 檔只存靜態容量（`cpu_total`）；DataService 計算 VM 加總後轉為頁面用的 `cpu: {u, t}` 格式。`used` 量不持久化，每次載入重新計算。

**2. Dedicated Pool 雙重關聯方式**

Dedicated Pool 在 `pools.json` 直接持有 `project_id` / `system_id`，提供快速查詢；`allocations.json` 的 Allocation 記錄適用 Shared Pool 多對多關係。

**3. allocation.html 使用顯示名稱**

`ALLOCS[]` 中的 `system`、`project` 欄位為顯示用的字串名稱，非 ID。串接後端時應改為 `system_id` / `project_id` 並在 UI 層查詢對應名稱。

**4. Subnet ID 統一**

全平台採用 `SN01–SN10` 格式，`data/subnets.json` 為唯一來源。

**5. 環境（Env）僅 Prod / UAT**

DR 以 `site_role: 'dr'` 在 Pool 層面體現，不作為獨立環境維度。

**6. VM tags 鬆耦合設計**

VM 的業務歸屬（專案 / 系統 / 環境 / 角色）以 `tags` 物件承載，方便擴充而不改變 VM 核心欄位。

### 7.4 已知限制 / 待改善

| 項目 | 說明 |
|------|------|
| 跨頁資料同步 | 各頁面讀取靜態 JSON，操作結果不回寫，頁面間無法即時反映 |
| used 量計算 | Pool 用量由 vms.json 加總而來，實際環境應由後端 API 提供即時值 |
| tc-dr Subnet 空白 | P03 / P04 / S02 的 `subnet_ids` 為空陣列，DR Pool 的 VM 無法選擇 Subnet |
| allocation.html 使用名稱而非 ID | `ALLOCS.system / project` 為字串名稱，串後端時需統一改為 ID |
| 使用者管理 | 側邊欄有入口，功能未實作 |
| 專案管理 / 系統管理 | 側邊欄有入口，功能未實作 |
| 表單驗證 | IP / CIDR 格式未做正規表達式驗證 |
| 響應式 | 主要針對 1280px+ 桌面設計，行動版未最佳化 |
