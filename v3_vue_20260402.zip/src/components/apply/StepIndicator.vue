<template>
  <div class="flex items-center">
    <template v-for="(step, i) in steps" :key="step.n">
      <!-- Step circle + label -->
      <div class="flex flex-col items-center gap-1.5 flex-shrink-0">
        <div
          class="w-8 h-8 rounded-full flex items-center justify-center text-xs font-bold border-2 transition-all"
          :class="circleClass(step.n)"
        >{{ step.n }}</div>
        <div class="text-[10px] font-semibold whitespace-nowrap" :class="labelClass(step.n)">{{ step.label }}</div>
      </div>
      <!-- Connector line -->
      <div
        v-if="i < steps.length - 1"
        class="flex-1 h-[2px] mx-2 mb-4 transition-all"
        :class="currentStep > step.n ? 'bg-or' : 'bg-bord'"
      />
    </template>
  </div>
</template>

<script setup>
const props = defineProps({
  currentStep: { type: Number, required: true },
})

const steps = [
  { n: 1, label: '選擇專案' },
  { n: 2, label: '定義系統' },
  { n: 3, label: 'Pool 掛載' },
  { n: 4, label: '確認送出' },
]

function circleClass(n) {
  if (n < props.currentStep) return 'bg-or border-or text-white'
  if (n === props.currentStep) return 'bg-white border-or text-or'
  return 'bg-white border-bord text-ink-4'
}
function labelClass(n) {
  if (n === props.currentStep) return 'text-or'
  if (n < props.currentStep) return 'text-ink-3'
  return 'text-ink-4'
}
</script>

<style scoped>
@reference "../../assets/main.css";
</style>
