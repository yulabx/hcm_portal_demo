<template>
  <div class="h-full flex flex-col">
    <!-- Page header -->
    <div class="px-8 py-4 bg-white border-b border-bord flex-shrink-0 flex items-center justify-between">
      <div>
        <h1 class="text-sm font-bold text-ink">VM 管理</h1>
        <p class="text-[11px] text-ink-4 mt-0.5 font-mono">我的 Pool 與 VM 管理</p>
      </div>
      <!-- Env filter -->
      <div class="flex border border-bord rounded-[6px] overflow-hidden text-xs font-semibold">
        <button
          v-for="opt in envOpts" :key="opt.value"
          class="px-3 py-1.5 transition-colors"
          :class="envFilter === opt.value ? 'bg-or text-white' : 'bg-white text-ink-3 hover:bg-surf-2'"
          @click="envFilter = opt.value"
        >{{ opt.label }}</button>
      </div>
    </div>

    <div class="flex-1 overflow-auto p-6">
      <div class="mb-4">
        <div class="text-[13px] font-bold text-ink-2">在已取得的 Pool 內建立、管理虛擬機器</div>
      </div>

      <div class="flex flex-col gap-5">
        <PoolCardVm
          v-for="pool in filteredPools" :key="pool.id"
          :pool="pool"
          :vms="vmsStore.byPool(pool.id)"
          :allocs="allocsStore.byPool(pool.id)"
          :subnet-map="subnetsStore.subnetMap"
          @add-vm="openAddVm"
          @toggle-status="toggleStatus"
          @delete="askDelete"
        />
        <div v-if="!filteredPools.length" class="text-center text-ink-4 py-16 text-sm">
          目前篩選條件下無可用 Pool
        </div>
      </div>
    </div>

    <!-- Add VM modal -->
    <AddVmModal
      v-model="modalOpen"
      :pool="modalPool"
      :alloc-id="modalAllocId"
      :allocs="modalPool ? allocsStore.byPool(modalPool.id) : []"
      :vms-by-alloc="(allocId) => vmsStore.byPool(modalPool?.id).filter(v => v.alloc_id === allocId)"
      :subnets="modalPool ? subnetsStore.byIds(modalPool.subnet_ids ?? []) : []"
      @save="handleSave"
    />
  </div>
</template>

<script setup>
import { ref, computed } from 'vue'
import { usePoolsStore }       from '../stores/pools'
import { useVmsStore }         from '../stores/vms'
import { useAllocationsStore } from '../stores/allocations'
import { useSubnetsStore }     from '../stores/subnets'
import { useConfirm }          from '../composables/useConfirm'
import { useToast }            from '../composables/useToast'
import PoolCardVm  from '../components/vm/PoolCardVm.vue'
import AddVmModal  from '../components/vm/AddVmModal.vue'

const poolsStore   = usePoolsStore()
const vmsStore     = useVmsStore()
const allocsStore  = useAllocationsStore()
const subnetsStore = useSubnetsStore()
const { confirm }        = useConfirm()
const { show: showToast } = useToast()

// ── Env filter ────────────────────────────────────────
const envFilter = ref('all')
const envOpts   = [{ value: 'all', label: '全部' }, { value: 'Prod', label: 'Prod' }, { value: 'UAT', label: 'UAT' }]

const filteredPools = computed(() =>
  poolsStore.poolsWithUsed.filter(p =>
    p.status === 'active' &&
    (envFilter.value === 'all' || p.env === envFilter.value)
  )
)

// ── Modal state ───────────────────────────────────────
const modalOpen    = ref(false)
const modalPool    = ref(null)
const modalAllocId = ref(null)

function openAddVm({ pool, allocId }) {
  modalPool.value    = pool
  modalAllocId.value = allocId
  modalOpen.value    = true
}

async function handleSave(vmData) {
  try {
    await vmsStore.addVm(vmData)
    showToast(`✓ VM "${vmData.name}" 已建立`)
  } catch (e) {
    showToast('建立失敗：' + e.message, true)
  }
}

// ── Toggle status ─────────────────────────────────────
function toggleStatus(vm) {
  const target = vmsStore.vms.find(v => v.id === vm.id)
  if (!target) return
  target.status = target.status === 'running' ? 'stopped' : 'running'
  showToast(`${target.status === 'running' ? '▶ 已啟動' : '⏹ 已停止'}: ${target.name}`)
}

// ── Delete ────────────────────────────────────────────
async function askDelete(vm) {
  const ok = await confirm(
    '確認刪除 VM？',
    `即將刪除「${vm.name}」，此操作無法復原。`
  )
  if (!ok) return
  try {
    await vmsStore.deleteVm(vm.id)
    showToast(`🗑 VM "${vm.name}" 已刪除`)
  } catch (e) {
    showToast('刪除失敗：' + e.message, true)
  }
}
</script>

<style scoped>
@reference "../assets/main.css";
</style>
