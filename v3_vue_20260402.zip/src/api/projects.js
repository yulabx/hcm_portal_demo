import { request } from './request'

export const projectsApi = {
  list:   ()         => request('/api/projects'),
  create: (data)     => request('/api/projects',        { method: 'POST', body: data }),
  update: (id, data) => request(`/api/projects/${id}`,  { method: 'PUT',  body: data }),
}
