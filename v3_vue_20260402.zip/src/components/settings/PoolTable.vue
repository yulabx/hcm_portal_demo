<template>
  <div class="bg-white border border-bord rounded-[8px] shadow-sm overflow-hidden">
    <div class="overflow-x-auto">
      <table class="w-full text-sm border-collapse">
        <thead>
          <tr class="border-b border-bord bg-surf-2">
            <th class="th">Pool ID</th>
            <th class="th">名稱</th>
            <th class="th">類型</th>
            <th class="th">Cloud</th>
            <th class="th">環境</th>
            <th class="th min-w-[140px]">CPU</th>
            <th class="th min-w-[140px]">Memory</th>
            <th class="th min-w-[140px]">Disk</th>
            <th class="th">狀態</th>
            <th class="th">操作</th>
          </tr>
        </thead>
        <tbody>
          <tr v-if="!pools.length">
            <td colspan="10">
              <div class="flex flex-col items-center justify-center py-16 text-ink-4">
                <div class="text-4xl mb-3 opacity-25">🗄</div>
                <div class="text-sm font-semibold text-ink-3">找不到符合條件的 Pool</div>
              </div>
            </td>
          </tr>
          <tr
            v-for="(pool, i) in pools"
            :key="pool.id"
            class="border-b border-bord hover:bg-surf-2 transition-colors"
            :style="{ animationDelay: i * 20 + 'ms' }"
          >
            <td class="td font-mono text-xs font-semibold text-ink-3">{{ pool.id }}</td>
            <td class="td">
              <div class="text-xs font-semibold text-ink">{{ pool.name }}</div>
              <div class="text-[10px] text-ink-4 font-mono mt-0.5">{{ pool.siteName ?? pool.site_id }}</div>
            </td>
            <td class="td"><PoolTypeBadge :type="pool.type" /></td>
            <td class="td"><CloudBadge :cloud="pool.cloud" /></td>
            <td class="td"><EnvBadge :env="pool.env" /></td>
            <td class="td min-w-[140px]">
              <CapacityBar label="CPU" :used="pool.cpu?.u ?? 0" :total="pool.cpu?.t ?? pool.cpu_total" unit=" Core" />
            </td>
            <td class="td min-w-[140px]">
              <CapacityBar label="Mem" :used="pool.mem?.u ?? 0" :total="pool.mem?.t ?? pool.mem_total_gb" unit=" GB" />
            </td>
            <td class="td min-w-[140px]">
              <CapacityBar label="Disk" :used="pool.disk?.u ?? 0" :total="pool.disk?.t ?? pool.disk_total_tb" unit=" TB" />
            </td>
            <td class="td"><StatusBadge :status="pool.status" /></td>
            <td class="td">
              <div class="flex items-center gap-1.5">
                <button class="btn-action" @click="$emit('edit', pool)">編輯</button>
                <button
                  class="btn-action"
                  :class="pool.status === 'active'
                    ? 'border-red-m bg-red-l text-red hover:bg-red hover:text-white'
                    : 'border-grn-m bg-grn-l text-grn hover:bg-grn hover:text-white'"
                  @click="$emit('toggle-status', pool)"
                >
                  {{ pool.status === 'active' ? '停用' : '啟用' }}
                </button>
              </div>
            </td>
          </tr>
        </tbody>
      </table>
    </div>
  </div>
</template>

<script setup>
import CapacityBar    from '../common/CapacityBar.vue'
import StatusBadge    from '../common/StatusBadge.vue'
import EnvBadge       from '../common/EnvBadge.vue'
import PoolTypeBadge  from '../common/PoolTypeBadge.vue'
import CloudBadge     from '../common/CloudBadge.vue'

defineProps({ pools: { type: Array, default: () => [] } })
defineEmits(['edit', 'toggle-status'])
</script>

<style scoped>
@reference "../../assets/main.css";
.th { @apply px-4 py-3 text-left text-[10px] font-bold uppercase tracking-[.1em] text-ink-4 whitespace-nowrap; }
.td { @apply px-4 py-3; }
.btn-action { @apply px-2.5 py-1 text-[10px] font-semibold border border-bord rounded-[4px] bg-white text-ink-3 hover:border-bord-2 hover:bg-surf-2 transition-all; }
</style>
