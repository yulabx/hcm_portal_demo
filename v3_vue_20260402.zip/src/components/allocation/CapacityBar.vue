<template>
  <div class="flex flex-col gap-1">
    <div class="flex justify-between items-center text-[11px]">
      <span class="text-ink-4 font-semibold">{{ label }}</span>
      <span class="font-mono text-ink-3">{{ used }}<span class="text-ink-4">/{{ total }}{{ unit }}</span></span>
    </div>
    <div class="h-[6px] rounded-full bg-surf-2 overflow-hidden">
      <div class="h-full rounded-full transition-all duration-500" :style="{ width: pct + '%', background: color }" />
    </div>
    <div class="text-[10px] text-ink-4 font-mono">剩餘 {{ free }}{{ unit }} · {{ pct }}% 已用</div>
  </div>
</template>

<script setup>
import { computed } from 'vue'

const props = defineProps({
  label: { type: String, required: true },
  used:  { type: Number, default: 0 },
  total: { type: Number, default: 0 },
  unit:  { type: String, default: '' },
})

const pct   = computed(() => props.total ? Math.min(100, Math.round(props.used / props.total * 100)) : 0)
const free  = computed(() => +(props.total - props.used).toFixed(1))
const color = computed(() => pct.value >= 85 ? '#dc2626' : pct.value >= 70 ? '#d97706' : '#0d9488')
</script>
