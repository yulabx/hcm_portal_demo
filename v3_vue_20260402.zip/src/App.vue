<template>
  <!-- Loading overlay（初始化所有 store 完成前顯示） -->
  <div v-if="appLoading" class="flex h-screen items-center justify-center bg-surf-2 font-sans">
    <div class="flex flex-col items-center gap-3">
      <div class="w-8 h-8 rounded-lg bg-or flex items-center justify-center font-bold text-white text-sm">H</div>
      <div class="text-xs text-ink-3 font-semibold">載入中…</div>
    </div>
  </div>

  <!-- Error（任一 store 初始化失敗時顯示） -->
  <div v-else-if="appError" class="flex h-screen items-center justify-center bg-surf-2 font-sans">
    <div class="text-center">
      <div class="text-sm font-bold text-ink mb-1">載入失敗</div>
      <div class="text-xs text-red mb-4">{{ appError }}</div>
      <button class="px-4 py-2 text-xs font-semibold text-white bg-or rounded-[6px]" @click="initAll">重試</button>
    </div>
  </div>

  <!-- Main layout -->
  <div v-else class="flex h-screen font-sans">
    <AppSidebar />
    <main class="flex-1 overflow-auto bg-surf-2">
      <RouterView />
    </main>
  </div>

  <ToastNotify />
  <ConfirmDialog />
</template>

<script setup>
import { ref, onMounted } from 'vue'
import AppSidebar    from './components/common/AppSidebar.vue'
import ToastNotify   from './components/common/ToastNotify.vue'
import ConfirmDialog from './components/common/ConfirmDialog.vue'
import { usePoolsStore }       from './stores/pools'
import { useVmsStore }         from './stores/vms'
import { useAllocationsStore } from './stores/allocations'
import { useProjectsStore }    from './stores/projects'
import { useSystemsStore }     from './stores/systems'
import { useSubnetsStore }     from './stores/subnets'

const appLoading = ref(true)
const appError   = ref(null)

const poolsStore       = usePoolsStore()
const vmsStore         = useVmsStore()
const allocationsStore = useAllocationsStore()
const projectsStore    = useProjectsStore()
const systemsStore     = useSystemsStore()
const subnetsStore     = useSubnetsStore()

async function initAll() {
  appLoading.value = true
  appError.value   = null
  try {
    // vms 需先於 pools（poolsWithUsed 依賴 vms）
    // projects + systems 需先於 allocations（allocsWithNames 依賴兩者）
    await Promise.all([
      vmsStore.init(),
      projectsStore.init(),
      systemsStore.init(),
      subnetsStore.init(),
    ])
    await Promise.all([
      poolsStore.init(),
      allocationsStore.init(),
    ])
  } catch (e) {
    appError.value = e.message
  } finally {
    appLoading.value = false
  }
}

onMounted(initAll)
</script>
