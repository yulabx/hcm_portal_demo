<template>
  <div class="h-full flex flex-col">
    <!-- Page header -->
    <div class="px-8 py-5 bg-white border-b border-bord flex items-center justify-between flex-shrink-0">
      <div>
        <h1 class="text-sm font-bold text-ink">系統設定</h1>
        <p class="text-[11px] text-ink-4 mt-0.5 font-mono">{{ activeTab === 'pool' ? 'Pool 管理' : 'Subnet 管理' }}</p>
      </div>
      <button
        class="flex items-center gap-1.5 px-3.5 py-1.5 bg-or text-white text-xs font-semibold rounded-[6px] hover:bg-or-d transition-colors"
        @click="openAdd"
      >
        <span class="text-base leading-none">＋</span>
        <span>{{ activeTab === 'pool' ? '新增 Pool' : '新增 Subnet' }}</span>
      </button>
    </div>

    <!-- Content -->
    <div class="flex-1 overflow-auto p-8">
      <!-- Tabs -->
      <div class="flex gap-1 bg-white border border-bord rounded-[8px] p-1 shadow-sm mb-5 w-fit">
        <button
          v-for="tab in tabs" :key="tab.value"
          class="px-4 py-1.5 text-xs font-semibold rounded-[5px] transition-all"
          :class="activeTab === tab.value
            ? 'bg-or text-white'
            : 'bg-transparent text-ink-3 hover:bg-surf-2'"
          @click="activeTab = tab.value"
        >{{ tab.label }}</button>
      </div>

      <!-- Filter + Search row -->
      <div class="flex items-center gap-2 mb-4 flex-wrap">
        <!-- Pool filters -->
        <template v-if="activeTab === 'pool'">
          <div class="flex gap-1">
            <button v-for="c in typeChips" :key="c.value" @click="filterType = c.value"
              class="px-2.5 py-1 text-[10px] font-semibold rounded-[4px] border transition-all"
              :class="filterType === c.value ? 'bg-ink text-white border-ink' : 'bg-white text-ink-3 border-bord hover:border-ink-3'">
              {{ c.label }}
            </button>
          </div>
          <div class="flex gap-1">
            <button v-for="c in envChips" :key="c.value" @click="filterEnv = c.value"
              class="px-2.5 py-1 text-[10px] font-semibold rounded-[4px] border transition-all"
              :class="filterEnv === c.value ? 'bg-ink text-white border-ink' : 'bg-white text-ink-3 border-bord hover:border-ink-3'">
              {{ c.label }}
            </button>
          </div>
        </template>
        <!-- Subnet cloud filter -->
        <template v-else>
          <div class="flex gap-1">
            <button v-for="c in cloudChips" :key="c.value" @click="filterCloud = c.value"
              class="px-2.5 py-1 text-[10px] font-semibold rounded-[4px] border transition-all"
              :class="filterCloud === c.value ? 'bg-ink text-white border-ink' : 'bg-white text-ink-3 border-bord hover:border-ink-3'">
              {{ c.label }}
            </button>
          </div>
        </template>

        <!-- Search -->
        <div class="ml-auto flex items-center gap-1 bg-white border border-bord rounded-[6px] px-3 py-1.5 shadow-sm">
          <span class="text-ink-4 text-xs">🔍</span>
          <input
            v-model="search" type="text"
            :placeholder="activeTab === 'pool' ? '搜尋 Pool ID 或名稱…' : '搜尋 Subnet ID 或名稱…'"
            class="text-xs outline-none bg-transparent w-44 text-ink placeholder:text-ink-4"
          />
        </div>
      </div>

      <!-- KPI strip (Pool tab) -->
      <div v-if="activeTab === 'pool'" class="grid grid-cols-4 border border-bord rounded-[8px] overflow-hidden bg-white shadow-sm mb-5">
        <div v-for="kpi in poolKpis" :key="kpi.label" class="px-5 py-4 border-r border-bord last:border-r-0">
          <div class="text-[26px] font-extrabold tracking-tight leading-none mb-1">{{ kpi.value }}</div>
          <div class="text-[11px] font-semibold text-ink-2">{{ kpi.label }}</div>
        </div>
      </div>

      <!-- Tables -->
      <PoolTable
        v-if="activeTab === 'pool'"
        :pools="filteredPools"
        @edit="openEdit"
        @toggle-status="handleToggleStatus"
      />
      <SubnetTable
        v-else
        :subnets="filteredSubnets"
        @edit="openEdit"
        @delete="handleDelete"
      />
    </div>

    <!-- Modals -->
    <PoolFormModal
      v-if="showPoolModal"
      :item="editingItem"
      @save="handlePoolSave"
      @close="showPoolModal = false"
    />
    <SubnetFormModal
      v-if="showSubnetModal"
      :item="editingItem"
      @save="handleSubnetSave"
      @close="showSubnetModal = false"
    />
  </div>
</template>

<script setup>
import { ref, computed } from 'vue'
import { usePoolsStore }   from '../stores/pools'
import { useSubnetsStore } from '../stores/subnets'
import { useToast }        from '../composables/useToast'
import { useConfirm }      from '../composables/useConfirm'
import PoolTable        from '../components/settings/PoolTable.vue'
import SubnetTable      from '../components/settings/SubnetTable.vue'
import PoolFormModal    from '../components/settings/PoolFormModal.vue'
import SubnetFormModal  from '../components/settings/SubnetFormModal.vue'

const poolsStore   = usePoolsStore()
const subnetsStore = useSubnetsStore()
const { show: toast }     = useToast()
const { confirm }         = useConfirm()

// ── Tab ──────────────────────────────────────────────
const activeTab = ref('pool')
const tabs = [
  { value: 'pool',   label: 'Pool 管理'   },
  { value: 'subnet', label: 'Subnet 管理' },
]

// ── Filters ──────────────────────────────────────────
const search      = ref('')
const filterType  = ref('')
const filterEnv   = ref('')
const filterCloud = ref('')

const typeChips  = [
  { value: '',           label: '全部'      },
  { value: 'dedicated',  label: 'Dedicated' },
  { value: 'shared',     label: 'Shared'    },
]
const envChips   = [
  { value: '',     label: '全部' },
  { value: 'Prod', label: 'Prod' },
  { value: 'UAT',  label: 'UAT'  },
]
const cloudChips = [
  { value: '',        label: '全部'   },
  { value: 'private', label: '私有雲' },
  { value: 'hicloud', label: 'hiCloud'},
  { value: 'aws',     label: 'AWS'    },
]

// ── Computed filtered lists ───────────────────────────
const filteredPools = computed(() => {
  const kw = search.value.toLowerCase()
  return poolsStore.poolsWithUsed.filter(p => {
    if (filterType.value && p.type !== filterType.value) return false
    if (filterEnv.value  && p.env  !== filterEnv.value)  return false
    if (kw && !p.id.toLowerCase().includes(kw) && !p.name.toLowerCase().includes(kw)) return false
    return true
  })
})

const filteredSubnets = computed(() => {
  const kw = search.value.toLowerCase()
  return subnetsStore.subnets.filter(s => {
    if (filterCloud.value && s.cloud !== filterCloud.value) return false
    if (kw && !s.id.toLowerCase().includes(kw) && !s.name.toLowerCase().includes(kw)) return false
    return true
  })
})

// ── KPIs ─────────────────────────────────────────────
const poolKpis = computed(() => {
  const all = poolsStore.pools
  return [
    { label: 'Pool 總數',    value: all.length },
    { label: 'Dedicated',    value: all.filter(p => p.type === 'dedicated').length },
    { label: 'Shared',       value: all.filter(p => p.type === 'shared').length    },
    { label: '啟用中',       value: all.filter(p => p.status === 'active').length  },
  ]
})

// ── Modal state ───────────────────────────────────────
const showPoolModal   = ref(false)
const showSubnetModal = ref(false)
const editingItem     = ref(null)

function openAdd() {
  editingItem.value = null
  if (activeTab.value === 'pool') showPoolModal.value = true
  else showSubnetModal.value = true
}

function openEdit(item) {
  editingItem.value = item
  if (activeTab.value === 'pool') showPoolModal.value = true
  else showSubnetModal.value = true
}

// ── Handlers ──────────────────────────────────────────
async function handlePoolSave(data) {
  try {
    if (editingItem.value) {
      await poolsStore.updatePool(data)
      toast(`✓ Pool "${data.name}" 已更新`)
    } else {
      await poolsStore.addPool(data)
      toast(`✓ Pool "${data.name}" 已建立`)
    }
    showPoolModal.value = false
  } catch (e) {
    toast(`操作失敗：${e.message}`, true)
  }
}

async function handleToggleStatus(pool) {
  try {
    await poolsStore.toggleStatus(pool.id)
    const next = pool.status === 'active' ? '停用' : '啟用'
    toast(`✓ Pool "${pool.name}" 已${next}`)
  } catch (e) {
    toast(`操作失敗：${e.message}`, true)
  }
}

async function handleSubnetSave(data) {
  try {
    if (editingItem.value) {
      await subnetsStore.updateSubnet(data)
      toast(`✓ Subnet "${data.name}" 已更新`)
    } else {
      await subnetsStore.addSubnet(data)
      toast(`✓ Subnet "${data.name}" 已建立`)
    }
    showSubnetModal.value = false
  } catch (e) {
    toast(`操作失敗：${e.message}`, true)
  }
}

async function handleDelete(sn) {
  const ok = await confirm(`刪除 Subnet "${sn.name}"`, `此 Subnet 將從所有 Pool 中移除，此操作無法復原。`)
  if (!ok) return
  try {
    await subnetsStore.deleteSubnet(sn.id)
    toast(`✓ Subnet "${sn.name}" 已刪除`)
  } catch (e) {
    toast(`操作失敗：${e.message}`, true)
  }
}
</script>
