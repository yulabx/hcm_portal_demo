<template>
  <Teleport to="body">
    <Transition name="modal">
      <div
        v-if="modelValue"
        class="fixed inset-0 z-50 flex items-center justify-center p-4"
        style="background:rgba(0,0,0,.35)"
        @click.self="$emit('update:modelValue', false)"
      >
        <div class="bg-white rounded-xl shadow-2xl w-full max-w-[520px] overflow-hidden">
          <!-- Header -->
          <div class="flex items-center justify-between px-6 py-4 border-b border-bord">
            <div>
              <div class="font-bold text-[15px]">新增 VM</div>
              <div class="text-[11px] text-ink-4 mt-0.5">
                {{ pool?.name }} <span class="text-ink-4">({{ pool?.id }})</span> ·
                {{ pool?.type === 'dedicated' ? 'Dedicated' : 'Shared' }}
                <span class="ml-1 text-[9px] font-bold uppercase px-1.5 py-0.5 rounded-[3px] border"
                      :class="pool?.env === 'Prod' ? 'bg-ded-l text-ded border-ded-m' : 'bg-pur-l text-pur border-pur-m'">
                  {{ pool?.env }}
                </span>
              </div>
            </div>
            <button class="w-7 h-7 flex items-center justify-center text-ink-4 hover:text-ink hover:bg-surf-2 rounded-[6px] text-lg cursor-pointer" @click="$emit('update:modelValue', false)">×</button>
          </div>

          <!-- Body -->
          <div class="px-6 py-5 flex flex-col gap-4 max-h-[72vh] overflow-y-auto">

            <!-- Shared: alloc selector -->
            <div v-if="pool?.type === 'shared'">
              <label class="lbl">系統配額 <span class="text-red">*</span></label>
              <select v-model="form.allocId" class="field" @change="onAllocChange">
                <option value="">— 選擇系統配額 —</option>
                <option v-for="a in allocs" :key="a.id" :value="a.id">
                  {{ a.systemName }} · {{ a.projectName }}
                  （CPU 剩 {{ allocFree(a,'cpu') }}核 · Mem 剩 {{ allocFree(a,'mem') }}GB）
                </option>
              </select>
              <div v-if="form.allocId" class="mt-1.5 text-[11px] text-ink-4 bg-surf-2 rounded-[6px] px-3 py-2 flex gap-4 flex-wrap">
                <span>CPU 剩餘: <span class="font-mono font-semibold text-ink-2">{{ allocFreeById(form.allocId,'cpu') }} 核</span></span>
                <span>Mem 剩餘: <span class="font-mono font-semibold text-ink-2">{{ allocFreeById(form.allocId,'mem') }} GB</span></span>
                <span>Disk 剩餘: <span class="font-mono font-semibold text-ink-2">{{ allocFreeById(form.allocId,'disk').toFixed(1) }} TB</span></span>
              </div>
            </div>

            <!-- VM name + hostname -->
            <div class="grid grid-cols-2 gap-3">
              <div>
                <label class="lbl">VM 名稱 <span class="text-red">*</span></label>
                <input v-model="form.name" type="text" placeholder="vm-prod-web-01" class="field" />
                <div class="text-[10px] text-ink-4 mt-1">英數字、連字符</div>
              </div>
              <div>
                <label class="lbl">主機名稱 <span class="text-ink-4 font-normal normal-case">(選填)</span></label>
                <input v-model="form.hostname" type="text" placeholder="預設同 VM 名稱" class="field" />
              </div>
            </div>

            <!-- Flavor -->
            <div>
              <label class="lbl">規格套餐 <span class="text-red">*</span></label>
              <select v-model="form.flavorId" class="field font-mono" @change="onFlavorChange">
                <option value="">— 選擇規格 —</option>
                <option v-for="f in flavors" :key="f.id" :value="f.id">{{ f.desc }}</option>
              </select>
              <!-- Custom flavor inputs -->
              <div v-if="form.flavorId === 'custom'" class="grid grid-cols-2 gap-3 mt-2">
                <div>
                  <label class="text-[10px] text-ink-4 mb-1 block">自訂 vCPU</label>
                  <input v-model.number="form.customVcpu" type="number" min="1" max="128" placeholder="核數" class="field" @input="updateResHint" />
                </div>
                <div>
                  <label class="text-[10px] text-ink-4 mb-1 block">自訂 RAM (GB)</label>
                  <input v-model.number="form.customRam" type="number" min="1" max="512" placeholder="GB" class="field" @input="updateResHint" />
                </div>
              </div>
              <!-- Flavor preview -->
              <div v-else-if="form.flavorId" class="mt-1.5 text-[11px] text-ink-4 bg-surf-2 rounded-[6px] px-3 py-1.5 font-mono">
                {{ flavorPreview }}
              </div>
            </div>

            <!-- Image -->
            <div>
              <label class="lbl">映像檔 <span class="text-red">*</span></label>
              <select v-model="form.image" class="field">
                <option value="">— 選擇映像檔 —</option>
                <option v-for="img in images" :key="img.id" :value="img.id">{{ img.label }}</option>
              </select>
            </div>

            <!-- Disk size + type -->
            <div class="grid grid-cols-2 gap-3">
              <div>
                <label class="lbl">磁碟大小 (GB) <span class="text-red">*</span></label>
                <input v-model.number="form.diskGb" type="number" min="50" max="20000" placeholder="例：500" class="field" @input="updateResHint" />
              </div>
              <div>
                <label class="lbl">磁碟類型 <span class="text-red">*</span></label>
                <select v-model="form.diskType" class="field">
                  <option value="">— 選擇 —</option>
                  <option v-for="d in diskTypes" :key="d.id" :value="d.id">{{ d.label }}</option>
                </select>
              </div>
            </div>

            <!-- Role + Subnet -->
            <div class="grid grid-cols-2 gap-3">
              <div>
                <label class="lbl">系統角色 <span class="text-red">*</span></label>
                <select v-model="form.role" class="field">
                  <option value="">— 選擇 —</option>
                  <option v-for="r in VM_ROLES" :key="r" :value="r">{{ r }}</option>
                </select>
              </div>
              <div>
                <label class="lbl">Subnet <span class="text-red">*</span></label>
                <select v-model="form.subnetId" class="field">
                  <option value="">— 選擇子網路 —</option>
                  <option v-for="s in subnets" :key="s.id" :value="s.id">{{ s.name }} — {{ s.cidr }}</option>
                </select>
              </div>
            </div>

            <!-- IP -->
            <div>
              <label class="lbl">IP 位址 <span class="text-red">*</span></label>
              <input v-model="form.ip" type="text" placeholder="例：10.0.1.50" class="field font-mono" />
            </div>

            <!-- Initial status -->
            <div>
              <label class="lbl">初始狀態</label>
              <div class="flex gap-4">
                <label class="flex items-center gap-2 cursor-pointer">
                  <input v-model="form.status" type="radio" value="running" class="accent-[#ea580c]" />
                  <span class="text-sm"><span class="dot dot-run" />Running</span>
                </label>
                <label class="flex items-center gap-2 cursor-pointer">
                  <input v-model="form.status" type="radio" value="stopped" class="accent-[#ea580c]" />
                  <span class="text-sm"><span class="dot dot-stop" />Stopped</span>
                </label>
              </div>
            </div>

            <!-- Note -->
            <div>
              <label class="lbl">備註 <span class="text-ink-4 font-normal normal-case">(選填)</span></label>
              <textarea v-model="form.note" rows="2" placeholder="用途說明、特殊需求…" class="field resize-none" />
            </div>

            <!-- Resource hint -->
            <div
              v-if="resHint.show"
              class="rounded-[8px] border px-4 py-3 text-[12px]"
              :class="resHint.cls"
            >
              <div class="font-semibold mb-2 text-ink-3">建立後剩餘資源</div>
              <div class="flex gap-5 flex-wrap">
                <div>CPU：<span class="font-mono font-bold" :class="resHint.cpu < 0 ? 'text-red' : ''">{{ resHint.cpu < 0 ? '不足' : resHint.cpu + ' 核' }}</span></div>
                <div>記憶體：<span class="font-mono font-bold" :class="resHint.mem < 0 ? 'text-red' : ''">{{ resHint.mem < 0 ? '不足' : resHint.mem + ' GB' }}</span></div>
                <div>磁碟：<span class="font-mono font-bold" :class="resHint.disk < 0 ? 'text-red' : ''">{{ resHint.disk < 0 ? '不足' : resHint.diskDisp }}</span></div>
              </div>
              <div v-if="resHint.over" class="mt-1.5 text-[11px] text-red font-semibold">⚠ 資源不足，無法建立此 VM</div>
            </div>

          </div>

          <!-- Footer -->
          <div class="flex justify-end gap-2 px-6 py-4 border-t border-bord bg-surf-2">
            <button class="cancel-btn" @click="$emit('update:modelValue', false)">取消</button>
            <button class="submit-btn" :disabled="resHint.over" @click="submit">建立 VM</button>
          </div>
        </div>
      </div>
    </Transition>
  </Teleport>
</template>

<script setup>
import { ref, computed, watch } from 'vue'

// ── Static reference data ─────────────────────────────
const FLAVORS = {
  private: [
    { id:'s',      vcpu:2,  ram:4,   desc:'S  — 2 vCPU / 4 GB' },
    { id:'m',      vcpu:4,  ram:8,   desc:'M  — 4 vCPU / 8 GB' },
    { id:'l',      vcpu:8,  ram:16,  desc:'L  — 8 vCPU / 16 GB' },
    { id:'xl',     vcpu:8,  ram:32,  desc:'XL — 8 vCPU / 32 GB' },
    { id:'2xl',    vcpu:16, ram:32,  desc:'2XL — 16 vCPU / 32 GB' },
    { id:'3xl',    vcpu:16, ram:64,  desc:'3XL — 16 vCPU / 64 GB' },
    { id:'mem-m',  vcpu:4,  ram:16,  desc:'Mem-M — 4 vCPU / 16 GB (記憶體優化)' },
    { id:'mem-l',  vcpu:8,  ram:64,  desc:'Mem-L — 8 vCPU / 64 GB (記憶體優化)' },
    { id:'custom', vcpu:null, ram:null, desc:'自訂規格' },
  ],
  hicloud: [
    { id:'c1.small',    vcpu:2,  ram:4,  desc:'c1.small  — 2 vCPU / 4 GB' },
    { id:'c1.medium',   vcpu:4,  ram:8,  desc:'c1.medium — 4 vCPU / 8 GB' },
    { id:'c1.large',    vcpu:8,  ram:16, desc:'c1.large  — 8 vCPU / 16 GB' },
    { id:'m1.large',    vcpu:4,  ram:16, desc:'m1.large  — 4 vCPU / 16 GB (記憶體優化)' },
    { id:'m1.xlarge',   vcpu:8,  ram:32, desc:'m1.xlarge — 8 vCPU / 32 GB (記憶體優化)' },
    { id:'m1.2xlarge',  vcpu:16, ram:64, desc:'m1.2xlarge — 16 vCPU / 64 GB (記憶體優化)' },
  ],
  aws: [
    { id:'t3.medium',   vcpu:2,  ram:4,  desc:'t3.medium   — 2 vCPU / 4 GB (一般用途)' },
    { id:'t3.large',    vcpu:2,  ram:8,  desc:'t3.large    — 2 vCPU / 8 GB (一般用途)' },
    { id:'m5.large',    vcpu:2,  ram:8,  desc:'m5.large    — 2 vCPU / 8 GB (一般用途)' },
    { id:'m5.xlarge',   vcpu:4,  ram:16, desc:'m5.xlarge   — 4 vCPU / 16 GB (一般用途)' },
    { id:'m5.2xlarge',  vcpu:8,  ram:32, desc:'m5.2xlarge  — 8 vCPU / 32 GB (一般用途)' },
    { id:'r5.large',    vcpu:2,  ram:16, desc:'r5.large    — 2 vCPU / 16 GB (記憶體優化)' },
    { id:'r5.xlarge',   vcpu:4,  ram:32, desc:'r5.xlarge   — 4 vCPU / 32 GB (記憶體優化)' },
    { id:'c5.large',    vcpu:2,  ram:4,  desc:'c5.large    — 2 vCPU / 4 GB (運算優化)' },
    { id:'c5.xlarge',   vcpu:4,  ram:8,  desc:'c5.xlarge   — 4 vCPU / 8 GB (運算優化)' },
    { id:'c5.2xlarge',  vcpu:8,  ram:16, desc:'c5.2xlarge  — 8 vCPU / 16 GB (運算優化)' },
  ],
}
const IMAGES = {
  private: [
    { id:'ubuntu-22', label:'Ubuntu 22.04 LTS' }, { id:'ubuntu-20', label:'Ubuntu 20.04 LTS' },
    { id:'rhel-9', label:'RHEL 9' }, { id:'rocky-9', label:'Rocky Linux 9' },
    { id:'centos-stream-9', label:'CentOS Stream 9' },
    { id:'win2022', label:'Windows Server 2022' }, { id:'win2019', label:'Windows Server 2019' },
  ],
  hicloud: [
    { id:'ubuntu-22', label:'Ubuntu 22.04 LTS' }, { id:'ubuntu-20', label:'Ubuntu 20.04 LTS' },
    { id:'rocky-9', label:'Rocky Linux 9' },
    { id:'win2022', label:'Windows Server 2022' }, { id:'win2019', label:'Windows Server 2019' },
  ],
  aws: [
    { id:'ami-ubuntu22', label:'Ubuntu 22.04 LTS  (ami-0c7217cdde317cfec)' },
    { id:'ami-ubuntu20', label:'Ubuntu 20.04 LTS  (ami-0261755bbcb8c4a84)' },
    { id:'ami-rhel9',    label:'RHEL 9             (ami-026ebd4cfe2c043b2)' },
    { id:'ami-win2022',  label:'Windows Server 2022 (ami-0f9c44e98edf38a2b)' },
    { id:'ami-win2019',  label:'Windows Server 2019 (ami-0f63c07c0127e5eba)' },
  ],
}
const DISK_TYPES = {
  private: [{ id:'ssd', label:'SSD — 高效能' }, { id:'hdd', label:'HDD — 標準' }],
  hicloud: [{ id:'ssd', label:'高效能雲端磁碟 (SSD)' }, { id:'hdd', label:'標準雲端磁碟 (HDD)' }],
  aws: [
    { id:'gp3', label:'gp3 — 一般用途 SSD（推薦）' }, { id:'gp2', label:'gp2 — 一般用途 SSD' },
    { id:'io1', label:'io1 — 高效能 SSD（IOPS 密集）' }, { id:'st1', label:'st1 — 輸送量優化 HDD' },
    { id:'sc1', label:'sc1 — HDD（低頻存取）' },
  ],
}
const VM_ROLES = ['Web / API','Database','Cache','Message Queue','Gateway / LB','Batch / Worker','Monitoring','其他']

// ── Props / emits ─────────────────────────────────────
const props = defineProps({
  modelValue: { type: Boolean, default: false },
  pool:       { type: Object,  default: null  },
  allocId:    { type: String,  default: null  },  // pre-selected alloc (shared)
  allocs:     { type: Array,   default: () => [] }, // allocs with systemName/projectName
  vmsByAlloc: { type: Function, default: () => [] }, // (allocId) => vm[]
  subnets:    { type: Array,   default: () => [] }, // subnets for this pool
})
const emit = defineEmits(['update:modelValue', 'save'])

// ── Form state ────────────────────────────────────────
const defaultForm = () => ({
  allocId: '', name: '', hostname: '', flavorId: '', customVcpu: null, customRam: null,
  image: '', diskGb: null, diskType: '', role: '', subnetId: '', ip: '',
  status: 'running', note: '',
})
const form = ref(defaultForm())

watch(() => props.modelValue, (open) => {
  if (!open) return
  const f = defaultForm()
  f.allocId = props.allocId ?? ''
  form.value = f
  updateResHint()
})

// ── Cloud-specific selects ────────────────────────────
const cloudKey  = computed(() => props.pool?.cloud ?? 'private')
const flavors   = computed(() => FLAVORS[cloudKey.value]   ?? FLAVORS.private)
const images    = computed(() => IMAGES[cloudKey.value]    ?? IMAGES.private)
const diskTypes = computed(() => DISK_TYPES[cloudKey.value] ?? DISK_TYPES.private)

const flavorObj     = computed(() => flavors.value.find(f => f.id === form.value.flavorId))
const flavorPreview = computed(() => flavorObj.value ? `${flavorObj.value.vcpu} vCPU  ·  ${flavorObj.value.ram} GB RAM` : '')

function onFlavorChange() { updateResHint() }
function onAllocChange()  { updateResHint() }

function getSpec() {
  if (!form.value.flavorId) return { vcpu: 0, ram: 0 }
  if (form.value.flavorId === 'custom') return { vcpu: form.value.customVcpu || 0, ram: form.value.customRam || 0 }
  return { vcpu: flavorObj.value?.vcpu ?? 0, ram: flavorObj.value?.ram ?? 0 }
}

// ── Alloc free capacity ───────────────────────────────
function allocFree(alloc, resource) {
  const vms = props.vmsByAlloc(alloc.id)
  if (resource === 'cpu')  return alloc.quota_cpu     - vms.reduce((s, v) => s + (v.vcpu   ?? 0), 0)
  if (resource === 'mem')  return alloc.quota_mem_gb  - vms.reduce((s, v) => s + (v.ram_gb ?? 0), 0)
  if (resource === 'disk') return alloc.quota_disk_tb - vms.reduce((s, v) => s + (v.disk_gb ?? 0), 0) / 1024
  return 0
}
function allocFreeById(allocId, resource) {
  const alloc = props.allocs.find(a => a.id === allocId)
  return alloc ? allocFree(alloc, resource) : 0
}

// ── Resource hint ─────────────────────────────────────
const resHint = ref({ show: false, over: false, cls: '', cpu: 0, mem: 0, disk: 0, diskDisp: '' })

function updateResHint() {
  const p = props.pool
  if (!p) return
  const { vcpu, ram } = getSpec()
  const diskGb = form.value.diskGb || 0
  if (!vcpu && !ram && !diskGb) { resHint.value.show = false; return }

  let freeCpu, freeMem, freeDiskGb
  if (p.type === 'dedicated') {
    freeCpu    = p.cpu.t - p.cpu.u
    freeMem    = p.mem.t - p.mem.u
    freeDiskGb = p.disk.t * 1024 - p.disk.u  // t=TB, u=GB
  } else {
    const allocId = form.value.allocId
    if (!allocId) { resHint.value.show = false; return }
    const alloc = props.allocs.find(a => a.id === allocId)
    if (!alloc) { resHint.value.show = false; return }
    const vms = props.vmsByAlloc(allocId)
    freeCpu    = alloc.quota_cpu     - vms.reduce((s, v) => s + (v.vcpu   ?? 0), 0)
    freeMem    = alloc.quota_mem_gb  - vms.reduce((s, v) => s + (v.ram_gb ?? 0), 0)
    freeDiskGb = alloc.quota_disk_tb * 1024 - vms.reduce((s, v) => s + (v.disk_gb ?? 0), 0)
  }

  const afterCpu    = freeCpu    - vcpu
  const afterMem    = freeMem    - ram
  const afterDiskGb = freeDiskGb - diskGb
  const over        = afterCpu < 0 || afterMem < 0 || afterDiskGb < 0

  let cls = 'border-grn bg-grn-l'
  if (over) cls = 'border-red bg-red-l'
  else if (freeCpu > 0 && afterCpu / freeCpu < 0.1) cls = 'border-amb bg-amb-l'

  const diskTB = +(afterDiskGb / 1024).toFixed(1)

  resHint.value = {
    show: true, over, cls,
    cpu: afterCpu, mem: afterMem, disk: afterDiskGb,
    diskDisp: afterDiskGb >= 1024 ? diskTB + ' TB' : Math.round(afterDiskGb) + ' GB',
  }
}

// ── Submit ────────────────────────────────────────────
function submit() {
  const f   = form.value
  const { vcpu, ram } = getSpec()

  if (!f.name.trim())  { alert('請填寫 VM 名稱'); return }
  if (!f.flavorId)     { alert('請選擇規格套餐'); return }
  if (!vcpu || !ram)   { alert('請完整填寫自訂規格'); return }
  if (!f.image)        { alert('請選擇映像檔'); return }
  if (!f.diskGb)       { alert('請填寫磁碟大小'); return }
  if (!f.diskType)     { alert('請選擇磁碟類型'); return }
  if (!f.role)         { alert('請選擇系統角色'); return }
  if (!f.subnetId)     { alert('請選擇 Subnet'); return }
  if (!f.ip.trim())    { alert('請填寫 IP 位址'); return }
  if (!/^\d{1,3}(\.\d{1,3}){3}$/.test(f.ip)) { alert('IP 位址格式不正確'); return }
  if (props.pool?.type === 'shared' && !f.allocId) { alert('請選擇系統配額'); return }
  if (resHint.value.over) return

  emit('save', {
    id:        'VM-' + Date.now(),
    name:      f.name.trim(),
    hostname:  f.hostname.trim() || f.name.trim(),
    pool_id:   props.pool.id,
    alloc_id:  f.allocId || null,
    status:    f.status,
    flavor:    f.flavorId,
    vcpu,
    ram_gb:    ram,
    disk_gb:   f.diskGb,
    disk_type: f.diskType,
    image:     f.image,
    ip:        f.ip.trim(),
    subnet_id: f.subnetId,
    note:      f.note.trim(),
    tags:      { env: props.pool.env, role: f.role },
  })
  emit('update:modelValue', false)
}
</script>

<style scoped>
@reference "../../assets/main.css";
.lbl        { @apply block text-[11px] font-semibold text-ink-3 uppercase tracking-wide mb-1.5; }
.field      { @apply w-full border border-bord rounded-[6px] px-3 py-2 text-sm bg-white outline-none focus:border-or focus:shadow-[0_0_0_3px_rgba(234,88,12,.1)] transition-all; }
.cancel-btn { @apply px-4 py-2 text-xs font-semibold border border-bord rounded-[6px] hover:bg-white transition-colors cursor-pointer bg-surf-2; }
.submit-btn { @apply px-4 py-2 text-xs font-semibold bg-or text-white rounded-[6px] hover:bg-or-d transition-colors disabled:opacity-40 disabled:cursor-not-allowed cursor-pointer; }
.dot        { @apply inline-block w-1.5 h-1.5 rounded-full mr-1; vertical-align: middle; }
.dot-run    { background: #16a34a; }
.dot-stop   { @apply bg-bord-2; }
</style>
