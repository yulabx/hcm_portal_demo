<template>
  <div class="flex flex-col gap-4">

    <!-- Context badge -->
    <div class="flex items-center gap-2 px-3 py-2 bg-surf-2 border border-bord rounded-[6px]">
      <span class="text-[10px] font-bold uppercase tracking-wide text-ink-4">專案</span>
      <span class="text-xs font-semibold text-ink">{{ applyStore.selectedProject?.name }} · <span class="font-mono text-ink-4">{{ applyStore.selectedProject?.id }}</span></span>
    </div>

    <!-- System rows -->
    <div class="flex flex-col gap-3">
      <div
        v-for="(s, i) in applyStore.systems" :key="s.uid"
        class="border border-bord rounded-[8px] p-4 flex flex-col gap-3 bg-surf-2"
      >
        <div class="flex items-center justify-between">
          <span class="text-[10px] font-bold uppercase tracking-wide text-ink-4">系統 {{ i + 1 }}</span>
          <button
            v-if="applyStore.systems.length > 1"
            class="text-[10px] text-ink-4 hover:text-red transition-colors font-semibold"
            @click="applyStore.removeSystem(s.uid)"
          >✕ 移除</button>
        </div>

        <div class="grid grid-cols-2 gap-3">
          <div class="flex flex-col gap-1.5">
            <label class="text-[11px] font-semibold text-ink-2">系統名稱 <span class="text-red">*</span></label>
            <input
              :value="s.name"
              type="text"
              placeholder="例：ERP"
              class="form-input"
              @input="s.name = $event.target.value"
            />
          </div>
          <div class="flex flex-col gap-1.5">
            <label class="text-[11px] font-semibold text-ink-2">系統代碼 <span class="text-red">*</span></label>
            <input
              :value="s.code"
              type="text"
              placeholder="例：SYS-ERP"
              class="form-input font-mono uppercase"
              @input="s.code = $event.target.value.toUpperCase()"
            />
          </div>
        </div>

        <div class="flex flex-col gap-1.5">
          <label class="text-[11px] font-semibold text-ink-2">環境 <span class="text-red">*</span> <span class="text-[10px] text-ink-4 font-normal">（可複選）</span></label>
          <div class="flex gap-4">
            <label v-for="opt in envOpts" :key="opt.val" class="flex items-center gap-1.5 cursor-pointer select-none">
              <input
                type="checkbox"
                :checked="s.envs?.includes(opt.val)"
                class="w-3.5 h-3.5"
                :class="opt.accent"
                @change="applyStore.toggleEnv(s.uid, opt.val, $event.target.checked)"
              />
              <span class="text-xs font-semibold" :class="opt.textClass">{{ opt.val }}</span>
            </label>
          </div>
        </div>
      </div>
    </div>

    <!-- Add system button -->
    <button
      class="flex items-center gap-1.5 text-xs font-semibold text-or border border-dashed border-or hover:border-or hover:bg-or-l rounded-[6px] px-4 py-2.5 w-full justify-center transition-all"
      @click="applyStore.addSystem()"
    >
      <span class="text-sm leading-none">＋</span> 新增系統
    </button>

  </div>
</template>

<script setup>
import { onMounted } from 'vue'
import { useApplyStore } from '../../stores/apply'

const applyStore = useApplyStore()

const envOpts = [
  { val: 'Prod', accent: 'accent-grn', textClass: 'text-grn' },
  { val: 'UAT',  accent: 'accent-pur', textClass: 'text-pur' },
]

onMounted(() => {
  if (!applyStore.systems.length) applyStore.addSystem()
})
</script>

<style scoped>
@reference "../../assets/main.css";
.form-input { @apply border border-bord rounded-[6px] px-3 py-2 text-xs bg-white focus:outline-none focus:border-or transition-all; }
</style>
