import { defineStore } from 'pinia'
import { ref, computed } from 'vue'
import subnetsData from '@data/subnets.json'
import { subnetsApi } from '../api/subnets'

const USE_MOCK = import.meta.env.VITE_USE_MOCK !== 'false'

export const useSubnetsStore = defineStore('subnets', () => {
  const subnets = ref([])
  const loading = ref(false)
  const error   = ref(null)

  async function init() {
    if (subnets.value.length) return
    loading.value = true
    error.value   = null
    try {
      subnets.value = USE_MOCK ? subnetsData : await subnetsApi.list()
    } catch (e) {
      error.value = e.message
    } finally {
      loading.value = false
    }
  }

  const subnetMap = computed(() =>
    Object.fromEntries(subnets.value.map(s => [s.id, s]))
  )

  // tc-dr 站點的 Pool subnet_ids 可能為空，元件需處理此狀態
  function byIds(ids = []) {
    if (!ids.length) return []
    return ids.map(id => subnetMap.value[id]).filter(Boolean)
  }

  function byCloud(cloud) {
    return subnets.value.filter(s => s.cloud === cloud)
  }

  async function addSubnet(data) {
    const created = USE_MOCK ? data : await subnetsApi.create(data)
    subnets.value.push(created)
  }

  async function updateSubnet(data) {
    if (!USE_MOCK) await subnetsApi.update(data.id, data)
    const i = subnets.value.findIndex(s => s.id === data.id)
    if (i !== -1) subnets.value[i] = { ...subnets.value[i], ...data }
  }

  async function deleteSubnet(id) {
    if (!USE_MOCK) await subnetsApi.delete(id)
    subnets.value = subnets.value.filter(s => s.id !== id)
  }

  return { subnets, loading, error, subnetMap, byIds, byCloud, init, addSubnet, updateSubnet, deleteSubnet }
})
