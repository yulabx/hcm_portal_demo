<template>
  <Teleport to="body">
    <div
      class="fixed inset-0 z-50 flex items-center justify-center p-4"
      style="background:rgba(15,15,15,.45);backdrop-filter:blur(2px)"
      @click.self="$emit('close')"
    >
      <div class="bg-white rounded-[10px] shadow-lg w-full max-w-[480px] max-h-[90vh] overflow-y-auto">
        <!-- Header -->
        <div class="flex items-center justify-between px-6 py-4 border-b border-bord">
          <div>
            <h2 class="text-sm font-bold text-ink">{{ isEdit ? '編輯 Subnet' : '新增 Subnet' }}</h2>
            <p class="text-[11px] text-ink-4 mt-0.5">定義網段基本資訊</p>
          </div>
          <button class="w-7 h-7 flex items-center justify-center rounded-full hover:bg-surf-2 text-ink-4 hover:text-ink transition-colors text-lg" @click="$emit('close')">✕</button>
        </div>

        <!-- Form -->
        <div class="px-6 py-5 flex flex-col gap-4">
          <!-- ID + Name -->
          <div class="grid grid-cols-2 gap-4">
            <div class="flex flex-col gap-1.5">
              <label class="field-label">Subnet ID <span class="text-red">*</span></label>
              <input v-model="form.id" :disabled="isEdit" maxlength="8" placeholder="例：SN11"
                class="field-input font-mono uppercase" :class="{ 'opacity-50 cursor-not-allowed': isEdit }" />
            </div>
            <div class="flex flex-col gap-1.5">
              <label class="field-label">名稱 <span class="text-red">*</span></label>
              <input v-model="form.name" placeholder="例：內部應用網段" class="field-input" />
            </div>
          </div>

          <!-- CIDR -->
          <div class="flex flex-col gap-1.5">
            <label class="field-label">CIDR <span class="text-red">*</span></label>
            <input v-model="form.cidr" placeholder="例：10.10.1.0/24" class="field-input font-mono" />
          </div>

          <!-- Type + Cloud -->
          <div class="grid grid-cols-2 gap-4">
            <div class="flex flex-col gap-1.5">
              <label class="field-label">類型 <span class="text-red">*</span></label>
              <select v-model="form.type" class="field-input bg-white">
                <option value="internal">Internal（內部）</option>
                <option value="dmz">DMZ</option>
                <option value="management">Management（管理）</option>
                <option value="public">Public（公開）</option>
              </select>
            </div>
            <div class="flex flex-col gap-1.5">
              <label class="field-label">Cloud <span class="text-red">*</span></label>
              <select v-model="form.cloud" class="field-input bg-white">
                <option value="private">私有雲</option>
                <option value="hicloud">hiCloud</option>
                <option value="aws">AWS</option>
              </select>
            </div>
          </div>

          <!-- Site -->
          <div class="flex flex-col gap-1.5">
            <label class="field-label">Site <span class="text-red">*</span></label>
            <input v-model="form.site" placeholder="例：台北主中心" class="field-input" />
          </div>

          <!-- Error -->
          <div v-if="error" class="text-[11px] text-red bg-red-l border border-red-m rounded-[6px] px-3 py-2">{{ error }}</div>
        </div>

        <!-- Footer -->
        <div class="flex items-center justify-between px-6 py-4 border-t border-bord bg-surf-2 rounded-b-[10px]">
          <button class="px-4 py-2 text-xs font-semibold text-ink-3 border border-bord rounded-[6px] bg-white hover:bg-surf-2 transition-all" @click="$emit('close')">取消</button>
          <button class="px-5 py-2 text-xs font-semibold text-white bg-or rounded-[6px] hover:bg-or-d transition-all" @click="save">
            {{ isEdit ? '儲存' : '建立 Subnet' }}
          </button>
        </div>
      </div>
    </div>
  </Teleport>
</template>

<script setup>
import { reactive, computed, ref } from 'vue'

const props = defineProps({ item: { type: Object, default: null } })
const emit  = defineEmits(['save', 'close'])

const isEdit = computed(() => !!props.item)

const form = reactive({
  id:     '',
  name:   '',
  cidr:   '',
  type:   'internal',
  cloud:  'private',
  site:   '',
  status: 'active',
})

if (props.item) Object.assign(form, {
  id:     props.item.id,
  name:   props.item.name,
  cidr:   props.item.cidr,
  type:   props.item.type,
  cloud:  props.item.cloud,
  site:   props.item.site,
  status: props.item.status ?? 'active',
})

const error = ref('')

function save() {
  error.value = ''
  if (!form.id.trim())   { error.value = '請填寫 Subnet ID'; return }
  if (!form.name.trim()) { error.value = '請填寫名稱';       return }
  if (!form.cidr.trim()) { error.value = '請填寫 CIDR';      return }
  if (!form.site.trim()) { error.value = '請填寫 Site';      return }
  emit('save', { ...form })
}
</script>

<style scoped>
@reference "../../assets/main.css";
.field-label { @apply text-[11px] font-semibold text-ink-2; }
.field-input  { @apply border border-bord rounded-[6px] px-3 py-2 text-xs outline-none focus:border-or focus:ring-1 transition-all w-full; }
</style>
