<template>
  <div class="h-full flex flex-col">

    <!-- Page header -->
    <div class="px-8 py-4 bg-white border-b border-bord flex-shrink-0 flex items-center justify-between">
      <div>
        <h1 class="text-sm font-bold text-ink">申請資源</h1>
        <p class="text-[11px] text-ink-4 mt-0.5 font-mono">系統上線資源申請嚮導</p>
      </div>
      <div class="flex border border-bord rounded-[6px] overflow-hidden text-xs font-semibold">
        <button
          v-for="tab in tabs" :key="tab.val"
          class="px-3 py-1.5 transition-colors"
          :class="activeTab === tab.val ? 'bg-or text-white' : 'bg-white text-ink-3 hover:bg-surf-2'"
          @click="activeTab = tab.val"
        >{{ tab.label }}</button>
      </div>
    </div>

    <!-- Wizard view -->
    <div v-if="activeTab === 'wizard'" class="flex-1 overflow-auto p-6">
      <div class="max-w-3xl mx-auto flex flex-col gap-6">

        <StepIndicator :current-step="applyStore.currentStep" />

        <!-- Step title -->
        <div>
          <div class="text-[13px] font-bold text-ink-2">{{ stepTitle }}</div>
          <div class="text-[11px] text-ink-4 mt-0.5">{{ stepHint }}</div>
        </div>

        <!-- Step panels -->
        <Step1Project v-if="applyStore.currentStep === 1" />
        <Step2Systems v-if="applyStore.currentStep === 2" />
        <Step3Mounts  v-if="applyStore.currentStep === 3" />
        <Step4Confirm v-if="applyStore.currentStep === 4" />

        <!-- Validation error -->
        <div v-if="validationError" class="text-[11px] text-red px-3 py-2 bg-red-l border border-red-m rounded-[6px]">
          {{ validationError }}
        </div>

        <!-- Navigation -->
        <div class="flex items-center justify-between pt-2 border-t border-bord">
          <button
            v-if="applyStore.currentStep > 1"
            class="nav-btn text-ink-3 border-bord hover:bg-surf-2"
            @click="prev"
          >← 上一步</button>
          <div v-else />

          <button
            v-if="applyStore.currentStep < 4"
            class="nav-btn bg-or text-white border-or hover:opacity-90"
            @click="next"
          >下一步 →</button>
          <button
            v-else
            class="nav-btn bg-or text-white border-or hover:opacity-90"
            @click="handleSubmit"
          >確認送出 ✓</button>
        </div>

      </div>
    </div>

    <!-- History view -->
    <div v-else class="flex-1 overflow-auto p-6">
      <div class="max-w-3xl mx-auto">
        <div class="mb-4">
          <div class="text-[13px] font-bold text-ink-2">申請記錄</div>
        </div>
        <ApplyHistory />
      </div>
    </div>

    <!-- Success modal -->
    <div
      v-if="successModal"
      class="fixed inset-0 bg-black/40 flex items-center justify-center z-50"
      @click.self="closeSuccess(false)"
    >
      <div class="bg-white rounded-[16px] shadow-xl p-8 max-w-sm w-full mx-4 text-center flex flex-col items-center gap-4">
        <div class="w-16 h-16 rounded-full bg-grn-l flex items-center justify-center text-3xl">✅</div>
        <div>
          <div class="text-sm font-bold text-ink">申請已送出！</div>
          <div class="text-[11px] text-ink-4 mt-1">申請編號</div>
          <div class="font-mono text-xs font-bold text-or mt-0.5">{{ successId }}</div>
        </div>
        <p class="text-[11px] text-ink-3">您的申請已進入待執行佇列，管理員審核後將執行 Pool 配置。</p>
        <div class="flex gap-3 w-full">
          <button
            class="flex-1 border border-bord rounded-[8px] py-2.5 text-xs font-semibold text-ink-2 hover:bg-surf-2 transition-colors"
            @click="closeSuccess(false)"
          >完成</button>
          <button
            class="flex-1 bg-or text-white rounded-[8px] py-2.5 text-xs font-semibold hover:opacity-90 transition-colors"
            @click="closeSuccess(true)"
          >查看申請記錄</button>
        </div>
      </div>
    </div>

  </div>
</template>

<script setup>
import { ref, computed } from 'vue'
import { useApplyStore }  from '../stores/apply'
import StepIndicator from '../components/apply/StepIndicator.vue'
import Step1Project  from '../components/apply/Step1Project.vue'
import Step2Systems  from '../components/apply/Step2Systems.vue'
import Step3Mounts   from '../components/apply/Step3Mounts.vue'
import Step4Confirm  from '../components/apply/Step4Confirm.vue'
import ApplyHistory  from '../components/apply/ApplyHistory.vue'

const applyStore = useApplyStore()

const activeTab      = ref('wizard')
const validationError = ref('')
const successModal   = ref(false)
const successId      = ref('')

const tabs = [
  { val: 'wizard',  label: '申請嚮導' },
  { val: 'history', label: '申請記錄' },
]

const STEP_META = [
  { title: '選擇申請專案',         hint: '搜尋並選擇現有專案，或新建一個專案' },
  { title: '定義系統與環境',       hint: '設定此次申請涵蓋的系統清單及所需環境' },
  { title: '設定 Pool 掛載',       hint: '為每個系統的每個環境選擇 Pool（可略過）' },
  { title: '確認申請內容並送出',   hint: '請仔細確認以下資訊，送出後將進入待執行佇列' },
]

const stepTitle = computed(() => STEP_META[applyStore.currentStep - 1].title)
const stepHint  = computed(() => STEP_META[applyStore.currentStep - 1].hint)

function validate() {
  validationError.value = ''
  const step = applyStore.currentStep
  if (step === 1) {
    if (!applyStore.selectedProject) { validationError.value = '請先選擇或新建一個專案'; return false }
  }
  if (step === 2) {
    if (!applyStore.systems.length) { validationError.value = '請至少新增一個系統'; return false }
    for (const s of applyStore.systems) {
      if (!s.name.trim()) { validationError.value = '請填寫所有系統名稱'; return false }
      if (!s.code.trim()) { validationError.value = '請填寫所有系統代碼'; return false }
      if (!s.envs?.length) { validationError.value = `系統「${s.name}」請至少勾選一個環境`; return false }
    }
  }
  return true
}

function next() {
  if (!validate()) return
  applyStore.currentStep++
}

function prev() {
  validationError.value = ''
  applyStore.currentStep--
}

function handleSubmit() {
  const id = applyStore.submit()
  successId.value = id
  successModal.value = true
}

function closeSuccess(goHistory) {
  successModal.value = false
  if (goHistory) activeTab.value = 'history'
}
</script>

<style scoped>
@reference "../assets/main.css";
.nav-btn { @apply px-5 py-2 rounded-[8px] text-xs font-semibold border transition-colors cursor-pointer; }
</style>
