<!-- 精簡版 CapacityBar：用於 CloudCard / SiteCard 內部 -->
<template>
  <div class="flex flex-col gap-[3px]">
    <div class="flex justify-between">
      <span class="text-[9px] font-bold uppercase text-ink-4">{{ label }}</span>
      <span class="font-mono text-[10px] text-ink-3">{{ used }} / {{ total }} {{ unit }}</span>
    </div>
    <div class="h-[4px] rounded-full overflow-hidden" style="background:#f7f8fa">
      <div class="h-full rounded-full transition-[width] duration-500"
        :style="{ width: pct + '%', background: color }" />
    </div>
  </div>
</template>

<script setup>
import { computed } from 'vue'
const props = defineProps({
  label: String,
  used:  { type: Number, default: 0 },
  total: { type: Number, default: 0 },
  unit:  { type: String, default: '' },
  color: { type: String, default: '#0d9488' },
})
const pct = computed(() => props.total ? Math.round(props.used / props.total * 100) : 0)
</script>
