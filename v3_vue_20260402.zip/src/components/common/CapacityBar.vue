<template>
  <div class="flex flex-col gap-1">
    <div class="flex justify-between items-center text-[11px]">
      <span class="text-ink-4 font-semibold">{{ label }}</span>
      <span class="font-mono text-ink-3">
        {{ used }}<span class="text-ink-4">/{{ total }}{{ unit }}</span>
      </span>
    </div>
    <div class="h-1 rounded-full overflow-hidden" style="background:#f7f8fa">
      <div
        class="h-full rounded-full transition-[width] duration-300"
        :class="colors.bar"
        :style="{ width: usedPct + '%' }"
      />
    </div>
    <div class="text-[10px] text-ink-4 font-mono">
      剩餘 {{ free }}{{ unit }} · {{ usedPct }}% 已用
    </div>
  </div>
</template>

<script setup>
import { computed } from 'vue'
import { useCapacity } from '../../composables/useCapacity'

const props = defineProps({
  label: { type: String, default: '' },
  used:  { type: Number, default: 0 },
  total: { type: Number, default: 0 },
  unit:  { type: String, default: '' },
})

const { pct, colorClass } = useCapacity()
const usedPct = computed(() => pct(props.used, props.total))
const colors  = computed(() => colorClass(props.used, props.total))
const free    = computed(() => props.total - props.used)
</script>
