<template>
  <div class="pool-card bg-white border border-bord rounded-[10px] overflow-hidden shadow-sm">

    <!-- Pool header -->
    <div class="flex items-center gap-2.5 px-4 py-[14px] border-b border-bord" style="border-color:#f0f0f0">
      <div
        class="w-8 h-8 rounded-[6px] flex items-center justify-center text-sm flex-shrink-0"
        :class="pool.type === 'dedicated' ? 'bg-ded-l text-ded' : 'bg-shr-l text-shr'"
      >{{ pool.type === 'dedicated' ? '🖥' : '🔗' }}</div>
      <div class="flex-1 min-w-0">
        <div class="font-semibold text-[13px] truncate">{{ pool.name }}</div>
        <div class="text-[11px] text-ink-4 mt-0.5">{{ cloudLabel }} · {{ siteLabel }}</div>
      </div>
      <div class="flex items-center gap-2 flex-shrink-0">
        <span class="badge-s" :class="pool.type === 'dedicated' ? 'bg-ded-l text-ded border-ded-m' : 'bg-shr-l text-shr border-shr-m'">
          {{ pool.type }}
        </span>
        <span class="badge-s" :class="pool.env === 'Prod' ? 'bg-ded-l text-ded border-ded-m' : 'bg-pur-l text-pur border-pur-m'">
          {{ pool.env }}
        </span>
        <span class="text-[11px] text-ink-4 font-mono ml-1">{{ pool.id }}</span>
      </div>
    </div>

    <!-- Capacity row -->
    <div class="px-4 py-3 grid gap-4 bg-surf-2 border-b border-bord" style="grid-template-columns: repeat(3,1fr); border-color:#f0f0f0">
      <ResBar label="CPU"    :used="pool.cpu.u"        :total="pool.cpu.t"        unit="核" />
      <ResBar label="記憶體" :used="pool.mem.u"        :total="pool.mem.t"        unit="GB" />
      <ResBar label="磁碟"   :used="diskUsedTB"        :total="pool.disk.t"       unit="TB" :decimals="1" />
    </div>

    <!-- Dedicated: VM table + add button -->
    <template v-if="pool.type === 'dedicated'">
      <VmTable
        :vms="vms"
        :subnet-map="subnetMap"
        @toggle-status="$emit('toggle-status', $event)"
        @delete="$emit('delete', $event)"
      />
      <div class="px-4 py-3 border-t border-bord" style="border-color:#f0f0f0">
        <button class="add-vm-btn text-or" @click="$emit('add-vm', { pool, allocId: null })">
          <span class="text-base leading-none">+</span> 新增 VM
        </button>
      </div>
    </template>

    <!-- Shared: per-alloc sections -->
    <template v-else>
      <div
        v-for="alloc in allocs" :key="alloc.id"
        class="border-t border-bord"
        style="border-color:#f0f0f0"
      >
        <!-- Alloc header -->
        <div class="px-4 py-2.5 bg-shr-l flex items-center gap-3 flex-wrap">
          <div class="flex items-center gap-1.5">
            <span class="text-[10px] font-bold text-shr uppercase tracking-wide">配額</span>
            <span class="text-xs font-semibold text-ink-2">{{ alloc.systemName }} · {{ alloc.projectName }} · {{ alloc.env }}</span>
          </div>
          <div class="flex items-center gap-3 text-[11px] text-ink-4 ml-auto flex-wrap">
            <span :class="quotaClass(allocUsed(alloc.id,'cpu'), alloc.quota_cpu)">
              CPU: {{ allocUsed(alloc.id,'cpu') }}/{{ alloc.quota_cpu }}核({{ quotaPct(allocUsed(alloc.id,'cpu'), alloc.quota_cpu) }}%)
            </span>
            <span :class="quotaClass(allocUsed(alloc.id,'mem'), alloc.quota_mem_gb)">
              Mem: {{ allocUsed(alloc.id,'mem') }}/{{ alloc.quota_mem_gb }}GB({{ quotaPct(allocUsed(alloc.id,'mem'), alloc.quota_mem_gb) }}%)
            </span>
          </div>
        </div>
        <!-- VM Table under alloc -->
        <VmTable
          :vms="vmsByAlloc(alloc.id)"
          :subnet-map="subnetMap"
          @toggle-status="$emit('toggle-status', $event)"
          @delete="$emit('delete', $event)"
        />
        <div class="px-4 py-3 border-t border-bord" style="border-color:#f0f0f0">
          <button class="add-vm-btn text-shr" @click="$emit('add-vm', { pool, allocId: alloc.id })">
            <span class="text-base leading-none">+</span> 在此配額下新增 VM
          </button>
        </div>
      </div>
      <div v-if="!allocs.length" class="px-4 py-6 text-center text-xs text-ink-4 border-t border-bord" style="border-color:#f0f0f0">
        此 Pool 尚無 Allocation，請先至配額管理新增
      </div>
    </template>

  </div>
</template>

<script setup>
import { computed } from 'vue'
import VmTable from './VmTable.vue'
import ResBar  from './ResBar.vue'

const CLOUD_LABELS = { private: '私有雲', hicloud: 'hiCloud', aws: 'AWS' }
const SITE_LABELS  = { 'tp-main': '台北主中心', 'tc-dr': '台中異備中心', 'e7-main': '東七主中心', 'tw-main': '台灣主中心' }

const props = defineProps({
  pool:      { type: Object, required: true },
  vms:       { type: Array,  default: () => [] },   // all vms for this pool
  allocs:    { type: Array,  default: () => [] },   // allocs (for shared)
  subnetMap: { type: Object, default: () => ({}) },
})
defineEmits(['add-vm', 'toggle-status', 'delete'])

const cloudLabel = computed(() => CLOUD_LABELS[props.pool.cloud] ?? props.pool.cloud)
const siteLabel  = computed(() => SITE_LABELS[props.pool.site_id] ?? props.pool.site_id)
const diskUsedTB = computed(() => +(props.pool.disk.u / 1024).toFixed(1))

function vmsByAlloc(allocId) {
  return props.vms.filter(v => v.alloc_id === allocId)
}
function allocUsed(allocId, resource) {
  const vms = vmsByAlloc(allocId)
  if (resource === 'cpu')  return vms.reduce((s, v) => s + (v.vcpu   ?? 0), 0)
  if (resource === 'mem')  return vms.reduce((s, v) => s + (v.ram_gb ?? 0), 0)
  if (resource === 'disk') return vms.reduce((s, v) => s + (v.disk_gb ?? 0), 0)
  return 0
}
function quotaPct(used, total) { return total ? Math.round(used / total * 100) : 0 }
function quotaClass(used, total) {
  const p = quotaPct(used, total)
  return p >= 85 ? 'text-red font-semibold' : p >= 70 ? 'text-amb' : ''
}
</script>

<style scoped>
@reference "../../assets/main.css";
.badge-s  { @apply text-[9px] font-bold uppercase tracking-wide px-1.5 py-0.5 rounded-[3px] border; }
.add-vm-btn { @apply flex items-center gap-1.5 text-xs font-semibold hover:opacity-80 transition-colors cursor-pointer bg-transparent border-0 p-0; }
</style>
