<template>
  <div class="flex flex-col gap-5">

    <!-- Selected display -->
    <div v-if="applyStore.selectedProject" class="flex items-center gap-3 px-4 py-3 bg-or-l border border-or rounded-[8px]">
      <div class="w-8 h-8 rounded-full bg-gradient-to-br from-ded to-shr flex items-center justify-center text-white text-xs font-bold flex-shrink-0">
        {{ applyStore.selectedProject.name.charAt(0) }}
      </div>
      <div class="flex-1 min-w-0">
        <div class="text-xs font-bold text-ink">{{ applyStore.selectedProject.name }}</div>
        <div class="text-[10px] text-ink-4 font-mono">{{ applyStore.selectedProject.id }}{{ applyStore.selectedProject.isNew ? ' · 新建' : ' · 既有' }}</div>
      </div>
      <button class="text-[10px] text-ink-4 hover:text-red font-semibold transition-colors" @click="clearSelection">✕ 取消選擇</button>
    </div>

    <!-- Search + list -->
    <div v-if="!applyStore.selectedProject || showNewForm" class="flex flex-col gap-3">
      <div class="flex items-center gap-2.5">
        <input
          v-model="searchQ"
          type="text"
          placeholder="搜尋專案名稱或代碼…"
          class="flex-1 border border-bord rounded-[6px] px-3 py-2 text-xs bg-white focus:outline-none focus:border-or transition-all"
        />
      </div>

      <!-- Project list (hidden when new form open) -->
      <div v-if="!showNewForm" class="flex flex-col gap-2 max-h-64 overflow-y-auto">
        <button
          v-for="p in filteredProjects" :key="p.id"
          class="flex items-center gap-3 px-3 py-2.5 rounded-[6px] border text-left transition-all"
          :class="applyStore.selectedProject?.id === p.id ? 'border-or bg-or-l' : 'border-bord bg-white hover:border-bord-2 hover:bg-surf-2'"
          @click="selectProject(p)"
        >
          <div class="w-7 h-7 rounded-full bg-gradient-to-br from-ded to-shr flex items-center justify-center text-white text-[10px] font-bold flex-shrink-0">
            {{ p.name.charAt(0) }}
          </div>
          <div class="flex-1 min-w-0">
            <div class="text-xs font-semibold text-ink truncate">{{ p.name }}</div>
            <div class="text-[10px] text-ink-4 font-mono">{{ p.id }} · {{ p.dept }}</div>
          </div>
          <span v-if="applyStore.selectedProject?.id === p.id" class="text-or text-sm flex-shrink-0">✓</span>
        </button>
        <div v-if="!filteredProjects.length" class="text-xs text-ink-4 px-3 py-2">找不到符合的專案</div>
      </div>
    </div>

    <!-- New project toggle -->
    <div class="border border-dashed border-bord-2 rounded-[8px] overflow-hidden">
      <button
        class="w-full flex items-center gap-2.5 px-4 py-3 text-left hover:bg-surf-2 transition-colors"
        @click="showNewForm = !showNewForm"
      >
        <span class="text-base leading-none text-or font-bold">{{ showNewForm ? '−' : '+' }}</span>
        <span class="text-xs font-semibold text-ink-2">新建專案</span>
        <span class="text-[10px] text-ink-4 ml-1">若找不到現有專案，可在此新建</span>
      </button>

      <div v-if="showNewForm" class="px-4 pb-4 flex flex-col gap-3 border-t border-bord">
        <div class="grid grid-cols-2 gap-3 mt-3">
          <div class="flex flex-col gap-1.5">
            <label class="text-[11px] font-semibold text-ink-2">專案名稱 <span class="text-red">*</span></label>
            <input v-model="newName" type="text" placeholder="例：ERP 升級專案" class="form-input" />
          </div>
          <div class="flex flex-col gap-1.5">
            <label class="text-[11px] font-semibold text-ink-2">專案代碼 <span class="text-red">*</span></label>
            <input v-model="newId" type="text" placeholder="例：PROJ-ERP" class="form-input font-mono uppercase" @input="newId = newId.toUpperCase()" />
          </div>
          <div class="flex flex-col gap-1.5">
            <label class="text-[11px] font-semibold text-ink-2">負責人</label>
            <input v-model="newOwner" type="text" placeholder="例：王小明" class="form-input" />
          </div>
          <div class="flex flex-col gap-1.5">
            <label class="text-[11px] font-semibold text-ink-2">部門</label>
            <input v-model="newDept" type="text" placeholder="例：資訊部" class="form-input" />
          </div>
        </div>
        <div v-if="newFormError" class="text-[11px] text-red">{{ newFormError }}</div>
        <button class="self-end btn-primary text-xs px-4 py-2 rounded-[6px]" @click="submitNewProject">建立並選擇</button>
      </div>
    </div>

  </div>
</template>

<script setup>
import { ref, computed } from 'vue'
import { useApplyStore }    from '../../stores/apply'
import { useProjectsStore } from '../../stores/projects'

const applyStore    = useApplyStore()
const projectsStore = useProjectsStore()

const searchQ    = ref('')
const showNewForm = ref(false)
const newName    = ref('')
const newId      = ref('')
const newOwner   = ref('')
const newDept    = ref('')
const newFormError = ref('')

const filteredProjects = computed(() => {
  const q = searchQ.value.trim().toLowerCase()
  return q
    ? projectsStore.projects.filter(p => p.name.toLowerCase().includes(q) || p.id.toLowerCase().includes(q))
    : projectsStore.projects
})

function selectProject(p) {
  applyStore.selectedProject = { ...p, isNew: false }
  showNewForm.value = false
}

function clearSelection() {
  applyStore.selectedProject = null
}

function submitNewProject() {
  newFormError.value = ''
  if (!newName.value.trim()) { newFormError.value = '請輸入專案名稱'; return }
  if (!newId.value.trim())   { newFormError.value = '請輸入專案代碼'; return }
  applyStore.selectedProject = {
    id: newId.value.trim().toUpperCase(),
    name: newName.value.trim(),
    owner: newOwner.value.trim(),
    dept: newDept.value.trim(),
    isNew: true,
  }
  showNewForm.value = false
  newName.value = newId.value = newOwner.value = newDept.value = ''
}
</script>

<style scoped>
@reference "../../assets/main.css";
.form-input  { @apply border border-bord rounded-[6px] px-3 py-2 text-xs bg-white focus:outline-none focus:border-or transition-all; }
.btn-primary { @apply bg-or text-white font-semibold hover:opacity-90 transition-colors cursor-pointer border-0; }
</style>
