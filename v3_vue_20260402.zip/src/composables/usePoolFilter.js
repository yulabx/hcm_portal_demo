import { ref, computed } from 'vue'

export function usePoolFilter(pools) {
  const filterEnv   = ref('')  // 'prod' | 'uat' | ''
  const filterType  = ref('')  // 'dedicated' | 'shared' | ''
  const filterCloud = ref('')  // 'private' | 'hicloud' | 'aws' | ''
  const keyword     = ref('')

  const filtered = computed(() => {
    return pools.value.filter(p => {
      if (filterEnv.value   && p.env   !== filterEnv.value)   return false
      if (filterType.value  && p.type  !== filterType.value)  return false
      if (filterCloud.value && p.cloud !== filterCloud.value) return false
      if (keyword.value     && !p.name.includes(keyword.value)) return false
      return true
    })
  })

  return { filterEnv, filterType, filterCloud, keyword, filtered }
}
