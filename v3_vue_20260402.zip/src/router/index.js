import { createRouter, createWebHashHistory } from 'vue-router'

const routes = [
  { path: '/', redirect: '/overview' },
  {
    path: '/overview',
    component: () => import('../views/ResourcePoolOverview.vue'),
    meta: { title: '資源池總覽' },
  },
  {
    path: '/projects',
    component: () => import('../views/ProjDimension.vue'),
    meta: { title: '專案總覽' },
  },
  {
    path: '/apply',
    component: () => import('../views/Apply.vue'),
    meta: { title: '申請資源' },
  },
  {
    path: '/vms',
    component: () => import('../views/VmManage.vue'),
    meta: { title: 'VM 管理' },
  },
  {
    path: '/allocation',
    component: () => import('../views/Allocation.vue'),
    meta: { title: '配額管理' },
  },
  {
    path: '/settings',
    component: () => import('../views/SettingsPool.vue'),
    meta: { title: '設定' },
  },
]

export default createRouter({
  history: createWebHashHistory(import.meta.env.BASE_URL),
  routes,
})
