import { request } from './request'

export const systemsApi = {
  list:   ()         => request('/api/systems'),
  create: (data)     => request('/api/systems',        { method: 'POST', body: data }),
  update: (id, data) => request(`/api/systems/${id}`,  { method: 'PUT',  body: data }),
}
