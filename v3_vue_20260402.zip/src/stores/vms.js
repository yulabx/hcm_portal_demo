import { defineStore } from 'pinia'
import { ref, computed } from 'vue'
import vmsData from '@data/vms.json'
import { vmsApi } from '../api/vms'

const USE_MOCK = import.meta.env.VITE_USE_MOCK !== 'false'

export const useVmsStore = defineStore('vms', () => {
  const vms     = ref([])
  const loading = ref(false)
  const error   = ref(null)

  const roleLabels = {
    app:     '應用',
    db:      '資料庫',
    gateway: '閘道',
  }

  async function init() {
    if (vms.value.length) return
    loading.value = true
    error.value   = null
    try {
      vms.value = USE_MOCK ? vmsData : await vmsApi.list()
    } catch (e) {
      error.value = e.message
    } finally {
      loading.value = false
    }
  }

  const vmsWithLabels = computed(() =>
    vms.value.map(vm => ({
      ...vm,
      mem_gb:    vm.ram_gb,
      roleLabel: roleLabels[vm.tags?.role] ?? vm.tags?.role ?? '',
    }))
  )

  function byPool(poolId) {
    return vmsWithLabels.value.filter(vm => vm.pool_id === poolId)
  }

  async function addVm(data) {
    const created = USE_MOCK ? data : await vmsApi.create(data)
    vms.value.push(created)
  }

  async function deleteVm(id) {
    if (!USE_MOCK) await vmsApi.delete(id)
    vms.value = vms.value.filter(v => v.id !== id)
  }

  return { vms, loading, error, vmsWithLabels, byPool, init, addVm, deleteVm }
})
