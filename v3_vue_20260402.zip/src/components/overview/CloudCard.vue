<template>
  <div
    class="bg-white border border-bord rounded-[8px] cursor-pointer shadow-sm overflow-hidden relative transition-all duration-200 hover:-translate-y-0.5 hover:border-bord-2 hover:shadow-md"
    :class="{
      'opacity-30 !shadow-sm !translate-y-0 pointer-events-none': dim,
      '!border-bord-2 shadow-lg -translate-y-0.5': selected,
    }"
    :style="{ '--cc-bar': meta.color }"
    @click="$emit('drill', cloud)"
  >
    <!-- Left accent bar -->
    <div class="absolute top-0 left-0 bottom-0 w-[3px] rounded-l-[8px]" :style="{ background: meta.color }" />

    <!-- Header -->
    <div class="flex items-start justify-between gap-3 px-[18px] py-4 pl-[22px]">
      <div
        class="w-[38px] h-[38px] rounded-[7px] border flex items-center justify-center font-mono text-[11px] font-bold flex-shrink-0"
        :style="{ background: meta.iconBg, color: meta.color, borderColor: meta.color + '44' }"
      >{{ meta.abbr }}</div>
      <div class="flex-1 pl-2.5">
        <div class="text-[18px] font-extrabold text-ink leading-tight">{{ meta.label }}</div>
        <div class="text-[11px] text-ink-4 font-mono">{{ meta.region }}</div>
      </div>
      <div
        class="text-base text-ink-4 mt-1 transition-all duration-150"
        :style="selected ? { color: meta.color, transform: 'translateX(3px)' } : {}"
      >→</div>
    </div>

    <!-- Pool type badges -->
    <div class="flex gap-1 px-[18px] pb-2.5 pl-[22px] flex-wrap">
      <span v-if="stats.dedCount" class="badge-small bg-ded-l text-ded border border-ded-m">Ded × {{ stats.dedCount }}</span>
      <span v-if="stats.shrCount" class="badge-small bg-shr-l text-shr border border-shr-m">Shr × {{ stats.shrCount }}</span>
    </div>

    <!-- Stats grid -->
    <div class="grid border-t border-bord py-2.5 text-center" style="grid-template-columns: repeat(4, 1fr)">
      <div v-for="s in statsGrid" :key="s.label" class="border-r border-bord last:border-r-0">
        <div class="text-[20px] font-extrabold text-ink leading-tight">{{ s.value }}</div>
        <div class="text-[9px] text-ink-4 uppercase tracking-wide">{{ s.label }}</div>
      </div>
    </div>

    <!-- Resource bars -->
    <div class="flex flex-col gap-[7px] px-[18px] pb-4 pt-3 pl-[22px] border-t border-bord">
      <ResourceBar label="CPU"    :used="stats.cpu.u"  :total="stats.cpu.t"  unit="C"  :color="meta.color" />
      <ResourceBar label="Memory" :used="stats.mem.u"  :total="stats.mem.t"  unit="GB" :color="meta.color" />
      <ResourceBar label="Disk"   :used="stats.disk.u" :total="stats.disk.t" unit="TB" :color="meta.color" />
    </div>
  </div>
</template>

<script setup>
import { computed } from 'vue'
import ResourceBar from './ResourceBar.vue'

const props = defineProps({
  cloud:    { type: String, required: true },
  stats:    { type: Object, required: true },
  selected: { type: Boolean, default: false },
  dim:      { type: Boolean, default: false },
})
defineEmits(['drill'])

const CLOUD_META = {
  private: { label: '私有雲', abbr: 'PRI', color: '#2563eb', iconBg: '#eff6ff', region: '台北 · 台中' },
  hicloud: { label: 'hiCloud', abbr: 'HIC', color: '#0e7490', iconBg: '#f0fdfa', region: '東七'       },
  aws:     { label: 'AWS',     abbr: 'AWS', color: '#b45309', iconBg: '#fffbeb', region: '台灣'       },
}
const meta = computed(() => CLOUD_META[props.cloud] ?? CLOUD_META.private)

const statsGrid = computed(() => [
  { value: props.stats.dedCount + props.stats.shrCount, label: 'Pools' },
  { value: props.stats.siteCount,                       label: 'Sites' },
  { value: props.stats.vmCount,                         label: 'VMs'   },
  { value: props.stats.allocCount,                      label: 'Allocs'},
])
</script>

<style scoped>
@reference "../../assets/main.css";
.badge-small { @apply text-[9px] font-bold px-1.5 py-0.5 rounded-[3px] border; }
</style>
