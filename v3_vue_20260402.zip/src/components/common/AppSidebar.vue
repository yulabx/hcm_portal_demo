<template>
  <nav
    id="sidebar"
    class="flex-shrink-0 bg-white border-r border-bord flex flex-col overflow-hidden z-10 transition-all duration-300"
    :style="{ width: collapsed ? '56px' : '220px' }"
  >
    <!-- Logo header -->
    <div class="p-4 border-b border-bord flex items-center gap-3 flex-shrink-0" :class="collapsed ? 'justify-center' : ''">
      <div class="w-8 h-8 rounded-[8px] bg-or flex items-center justify-center text-white text-[11px] font-bold flex-shrink-0">HCM</div>
      <div v-show="!collapsed" class="overflow-hidden">
        <div class="text-sm font-bold text-ink whitespace-nowrap">雲地整合平台</div>
        <div class="text-[10px] text-ink-4 font-mono tracking-wide whitespace-nowrap">INFRA PORTAL</div>
      </div>
    </div>

    <!-- Menu groups -->
    <div class="p-2 flex flex-col gap-0.5 flex-1 overflow-y-auto">
      <template v-for="(group, gi) in menu" :key="gi">
        <!-- Group divider -->
        <div v-if="gi > 0" class="mx-3.5 my-2 h-px bg-bord" />

        <!-- Section label -->
        <div
          v-if="group.section && !collapsed"
          class="px-3.5 pb-1.5 pt-2 text-[9px] font-bold tracking-[.16em] uppercase text-ink-4 whitespace-nowrap overflow-hidden"
        >
          {{ group.section }}
        </div>

        <div class="flex flex-col gap-0.5" :class="group.section ? '' : 'pt-2'">
          <template v-for="item in group.items" :key="item.id">
            <!-- Expandable parent -->
            <template v-if="item.children">
              <div
                class="sb-item flex items-center gap-2.5 px-3.5 py-2 rounded-[6px] cursor-pointer transition-colors"
                :class="isParentActive(item)
                  ? 'bg-or-l'
                  : 'hover:bg-surf-2'"
                @click="toggleParent(item.id)"
              >
                <span class="text-base w-5 text-center flex-shrink-0">{{ item.icon }}</span>
                <span
                  v-show="!collapsed"
                  class="text-xs font-semibold whitespace-nowrap overflow-hidden flex-1"
                  :class="isParentActive(item) ? 'text-or-d' : 'text-ink-2'"
                >
                  {{ item.label }}
                </span>
                <span
                  v-show="!collapsed"
                  class="text-[10px] text-ink-4 transition-transform duration-200"
                  :class="openParents.has(item.id) ? 'rotate-90' : ''"
                >▶</span>
              </div>

              <!-- Sub-items -->
              <div
                v-show="openParents.has(item.id) && !collapsed"
                class="flex flex-col gap-0.5 mt-0.5"
              >
                <RouterLink
                  v-for="child in item.children"
                  :key="child.id"
                  :to="child.to ?? '#'"
                  class="sb-item flex items-center gap-2 pl-[42px] pr-3.5 py-1.5 rounded-[6px] transition-colors"
                  :class="isActive(child)
                    ? 'bg-or-m/30 text-or-d font-semibold'
                    : 'hover:bg-surf-2 text-ink-3'"
                  active-class=""
                  @click.prevent="child.to ? navigate(child.to) : null"
                >
                  <span class="text-xs whitespace-nowrap overflow-hidden">{{ child.label }}</span>
                </RouterLink>
              </div>
            </template>

            <!-- Regular item -->
            <RouterLink
              v-else
              :to="item.to"
              class="sb-item flex items-center gap-2.5 px-3.5 py-2 rounded-[6px] transition-colors"
              :class="collapsed ? 'justify-center' : ''"
              active-class="!bg-or-l [&_.sb-label]:!text-or-d"
              exact-active-class="!bg-or-l [&_.sb-label]:!text-or-d"
            >
              <span class="text-base w-5 text-center flex-shrink-0">{{ item.icon }}</span>
              <span
                v-show="!collapsed"
                class="sb-label text-xs font-semibold text-ink-2 whitespace-nowrap overflow-hidden"
              >
                {{ item.label }}
              </span>
            </RouterLink>
          </template>
        </div>
      </template>
    </div>

    <!-- Collapse toggle -->
    <div class="border-t border-bord p-2 mt-auto">
      <button
        class="w-full flex items-center gap-2.5 px-3.5 py-2 rounded-[6px] hover:bg-surf-2 transition-colors"
        :class="collapsed ? 'justify-center' : ''"
        @click="toggleCollapse"
      >
        <span class="text-sm text-ink-4 w-5 text-center flex-shrink-0 transition-transform duration-300" :class="collapsed ? 'rotate-180' : ''">◀</span>
        <span v-show="!collapsed" class="text-xs font-semibold text-ink-3 whitespace-nowrap overflow-hidden">收折選單</span>
      </button>
    </div>
  </nav>
</template>

<script setup>
import { ref, reactive } from 'vue'
import { useRouter, useRoute } from 'vue-router'

const router = useRouter()
const route  = useRoute()

// 收折狀態（localStorage 持久化）
const collapsed = ref(localStorage.getItem('hcm_sb_collapsed') === '1')

function toggleCollapse() {
  collapsed.value = !collapsed.value
  localStorage.setItem('hcm_sb_collapsed', collapsed.value ? '1' : '0')
}

// 展開狀態
const openParents = reactive(new Set())

function toggleParent(id) {
  if (openParents.has(id)) openParents.delete(id)
  else openParents.add(id)
}

function isParentActive(item) {
  return item.children?.some(c => c.to && route.path.startsWith(c.to))
}

function isActive(child) {
  return child.to && route.path === child.to
}

function navigate(to) {
  router.push(to)
}

// 選單設定（對應 menu.js，href 改為 Vue Router to）
const menu = [
  {
    items: [
      { id: 'pool-overview', icon: '🗄',  label: '資源池總覽',    to: '/overview'  },
      { id: 'proj-overview', icon: '📁',  label: '專案總覽',      to: '/projects'  },
    ],
  },
  {
    section: '作業',
    items: [
      { id: 'vm',    icon: '🖥',  label: '申請 VM',        to: '/vms'   },
      { id: 'apply', icon: '📋',  label: '申請專案/系統',  to: '/apply' },
    ],
  },
  {
    section: '設定',
    items: [
      { id: 'user-mgmt', icon: '👥', label: '使用者管理', to: '#' },
      {
        id: 'settings', icon: '⚙️', label: '系統設定', to: '/settings',
        children: [
          { id: 'settings-project', label: '專案管理',       to: null         },
          { id: 'settings-system',  label: '系統管理',       to: null         },
          { id: 'settings-pool',    label: 'Pool 管理',     to: '/settings'  },
          { id: 'settings-alloc',   label: 'Allocation 管理', to: '/allocation' },
        ],
      },
    ],
  },
]

// 預設展開有 active child 的 parent
menu.forEach(group => {
  group.items.forEach(item => {
    if (item.children && isParentActive(item)) {
      openParents.add(item.id)
    }
  })
})
</script>
