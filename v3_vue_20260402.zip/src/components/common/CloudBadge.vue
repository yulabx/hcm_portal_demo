<template>
  <span
    class="inline-flex items-center px-1.5 py-0.5 rounded text-[9px] font-bold uppercase tracking-wide"
    :style="{ backgroundColor: meta.bg, color: meta.text }"
  >
    {{ meta.label }}
  </span>
</template>

<script setup>
import { computed } from 'vue'

const props = defineProps({
  cloud: { type: String, required: true },  // 'private' | 'hicloud' | 'aws'
})

const META = {
  private: { label: '私有雲', bg: '#eff6ff', text: '#2563eb' },
  hicloud: { label: 'hiCloud', bg: '#f0fdfa', text: '#0e7490' },
  aws:     { label: 'AWS',     bg: '#fffbeb', text: '#b45309' },
}

const meta = computed(() =>
  META[props.cloud] ?? { label: props.cloud, bg: '#f7f8fa', text: '#737373' }
)
</script>
