<template>
  <span
    class="inline-flex items-center gap-1 px-[7px] py-[2px] rounded-full text-[10px] font-bold"
    :class="cfg.badge"
  >
    <span class="w-1.5 h-1.5 rounded-full" :class="cfg.dot" />
    {{ cfg.label }}
  </span>
</template>

<script setup>
import { computed } from 'vue'

const props = defineProps({
  status: { type: String, required: true },
})

const cfg = computed(() => {
  switch (props.status) {
    case 'running':  return { badge: 'bg-grn-l text-grn',       dot: 'bg-grn',   label: 'Running'  }
    case 'active':   return { badge: 'bg-grn-l text-grn',       dot: 'bg-grn',   label: 'Active'   }
    case 'stopped':  return { badge: 'bg-surf-2 text-ink-3',    dot: 'bg-ink-4', label: 'Stopped'  }
    case 'inactive': return { badge: 'bg-surf-2 text-ink-3',    dot: 'bg-ink-4', label: 'Inactive' }
    default:         return { badge: 'bg-surf-2 text-ink-3',    dot: 'bg-ink-4', label: props.status }
  }
})
</script>
