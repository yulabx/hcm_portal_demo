<template>
  <Teleport to="body">
    <div
      class="fixed inset-0 z-50 flex items-center justify-center p-4"
      style="background:rgba(15,15,15,.45);backdrop-filter:blur(2px)"
      @click.self="$emit('close')"
    >
      <div class="bg-white rounded-[10px] shadow-lg w-full max-w-[560px] max-h-[90vh] overflow-y-auto">
        <!-- Header -->
        <div class="flex items-center justify-between px-6 py-4 border-b border-bord">
          <div>
            <h2 class="text-sm font-bold text-ink">{{ isEdit ? '編輯 Pool' : '新增 Pool' }}</h2>
            <p class="text-[11px] text-ink-4 mt-0.5">填寫 Pool 基本資訊與資源容量</p>
          </div>
          <button class="w-7 h-7 flex items-center justify-center rounded-full hover:bg-surf-2 text-ink-4 hover:text-ink transition-colors text-lg" @click="$emit('close')">✕</button>
        </div>

        <!-- Form -->
        <div class="px-6 py-5 flex flex-col gap-4">
          <!-- ID + Name -->
          <div class="grid grid-cols-2 gap-4">
            <div class="flex flex-col gap-1.5">
              <label class="field-label">Pool ID <span class="text-red">*</span></label>
              <input v-model="form.id" :disabled="isEdit" maxlength="6" placeholder="例：S04"
                class="field-input font-mono uppercase" :class="{ 'opacity-50 cursor-not-allowed': isEdit }" />
              <span class="text-[10px] text-ink-4">4–6 碼，大寫英數</span>
            </div>
            <div class="flex flex-col gap-1.5">
              <label class="field-label">Pool 名稱 <span class="text-red">*</span></label>
              <input v-model="form.name" placeholder="例：共享運算池 A" class="field-input" />
            </div>
          </div>

          <!-- Type + Env -->
          <div class="grid grid-cols-2 gap-4">
            <div class="flex flex-col gap-1.5">
              <label class="field-label">類型 <span class="text-red">*</span></label>
              <div class="flex gap-2">
                <label
                  v-for="opt in typeOpts" :key="opt.value"
                  class="flex-1 flex items-center gap-2 border rounded-[6px] px-3 py-2 cursor-pointer transition-all"
                  :class="form.type === opt.value
                    ? `border-${opt.color} bg-${opt.color}-l`
                    : `border-bord hover:border-${opt.color}`"
                >
                  <input type="radio" :value="opt.value" v-model="form.type" :class="`accent-${opt.color}`" />
                  <span class="text-xs font-semibold" :class="form.type === opt.value ? `text-${opt.color}` : 'text-ink-2'">{{ opt.label }}</span>
                </label>
              </div>
            </div>
            <div class="flex flex-col gap-1.5">
              <label class="field-label">環境 <span class="text-red">*</span></label>
              <div class="flex gap-2">
                <label
                  v-for="opt in envOpts" :key="opt.value"
                  class="flex-1 flex items-center gap-2 border rounded-[6px] px-3 py-2 cursor-pointer transition-all"
                  :class="form.env === opt.value
                    ? `border-${opt.color} bg-${opt.color}-l`
                    : `border-bord hover:border-${opt.color}`"
                >
                  <input type="radio" :value="opt.value" v-model="form.env" :class="`accent-${opt.color}`" />
                  <span class="text-xs font-semibold" :class="form.env === opt.value ? `text-${opt.color}` : 'text-ink-2'">{{ opt.label }}</span>
                </label>
              </div>
            </div>
          </div>

          <!-- Cloud + Site -->
          <div class="grid grid-cols-2 gap-4">
            <div class="flex flex-col gap-1.5">
              <label class="field-label">Cloud <span class="text-red">*</span></label>
              <select v-model="form.cloud" class="field-input bg-white">
                <option value="private">私有雲</option>
                <option value="hicloud">hiCloud</option>
                <option value="aws">AWS</option>
              </select>
            </div>
            <div class="flex flex-col gap-1.5">
              <label class="field-label">Site <span class="text-red">*</span></label>
              <input v-model="form.site_id" placeholder="例：台北主中心" class="field-input" />
            </div>
          </div>

          <!-- 資源容量 divider -->
          <div class="flex items-center gap-2">
            <div class="w-[3px] h-[14px] bg-or rounded-full" />
            <span class="text-[11px] font-bold uppercase tracking-[.06em] text-ink-2">資源容量（總量）</span>
          </div>

          <!-- CPU + Mem + Disk -->
          <div class="grid grid-cols-3 gap-4">
            <div class="flex flex-col gap-1.5">
              <label class="field-label">CPU <span class="text-ink-4 font-normal">(Core)</span></label>
              <input v-model.number="form.cpu_total" type="number" min="0" placeholder="0" class="field-input font-mono" />
            </div>
            <div class="flex flex-col gap-1.5">
              <label class="field-label">Memory <span class="text-ink-4 font-normal">(GB)</span></label>
              <input v-model.number="form.mem_total_gb" type="number" min="0" placeholder="0" class="field-input font-mono" />
            </div>
            <div class="flex flex-col gap-1.5">
              <label class="field-label">Disk <span class="text-ink-4 font-normal">(TB)</span></label>
              <input v-model.number="form.disk_total_tb" type="number" min="0" step="0.1" placeholder="0" class="field-input font-mono" />
            </div>
          </div>
          <p class="text-[10px] text-ink-4 -mt-2">Shared Pool 的總容量上限；Allocation 分配量不可超過此值</p>

          <!-- 可用 Subnet divider -->
          <div class="flex items-center gap-2">
            <div class="w-[3px] h-[14px] bg-or rounded-full" />
            <span class="text-[11px] font-bold uppercase tracking-[.06em] text-ink-2">可用 Subnet</span>
            <span class="text-[10px] text-ink-4 font-normal ml-1">（依此 Pool 的 Cloud 自動過濾）</span>
          </div>

          <!-- Subnet checkboxes -->
          <div class="flex flex-col gap-1 max-h-[160px] overflow-y-auto border border-bord rounded-[6px] p-2.5 bg-surf-2">
            <div v-if="!cloudSubnets.length" class="py-4 text-center text-xs text-ink-4">
              目前無可用 Subnet
            </div>
            <label
              v-for="sn in cloudSubnets"
              :key="sn.id"
              class="flex items-center gap-2.5 px-2 py-1.5 rounded-[4px] hover:bg-white cursor-pointer select-none"
            >
              <input type="checkbox" :value="sn.id" v-model="form.subnet_ids" class="accent-or w-3.5 h-3.5 flex-shrink-0" />
              <span class="font-mono text-[10px] font-semibold text-ink-4 w-10 flex-shrink-0">{{ sn.id }}</span>
              <span class="text-xs font-semibold text-ink flex-1">{{ sn.name }}</span>
              <span class="font-mono text-[10px] text-ink-4">{{ sn.cidr }}</span>
              <span class="text-[9px] font-bold uppercase px-1 py-0.5 rounded-[3px] border bg-surf-2 border-bord text-ink-3">{{ sn.type }}</span>
            </label>
          </div>
          <p class="text-[10px] text-ink-4 -mt-2">建立 VM 時，使用者只能從勾選的 Subnet 中選擇</p>

          <!-- Error -->
          <div v-if="error" class="text-[11px] text-red bg-red-l border border-red-m rounded-[6px] px-3 py-2">{{ error }}</div>
        </div>

        <!-- Footer -->
        <div class="flex items-center justify-between px-6 py-4 border-t border-bord bg-surf-2 rounded-b-[10px]">
          <button class="px-4 py-2 text-xs font-semibold text-ink-3 border border-bord rounded-[6px] bg-white hover:bg-surf-2 transition-all" @click="$emit('close')">取消</button>
          <button class="px-5 py-2 text-xs font-semibold text-white bg-or rounded-[6px] hover:bg-or-d transition-all" @click="save">儲存</button>
        </div>
      </div>
    </div>
  </Teleport>
</template>

<script setup>
import { reactive, computed, watch, ref } from 'vue'
import { useSubnetsStore } from '../../stores/subnets'

const props = defineProps({ item: { type: Object, default: null } })
const emit  = defineEmits(['save', 'close'])

const subnetsStore = useSubnetsStore()
const isEdit = computed(() => !!props.item)

const form = reactive({
  id:           '',
  name:         '',
  type:         'dedicated',
  env:          'Prod',
  cloud:        'private',
  site_id:      '',
  cpu_total:    0,
  mem_total_gb: 0,
  disk_total_tb:0,
  subnet_ids:   [],
  status:       'active',
})

// 編輯時預填
if (props.item) Object.assign(form, {
  id:            props.item.id,
  name:          props.item.name,
  type:          props.item.type,
  env:           props.item.env,
  cloud:         props.item.cloud,
  site_id:       props.item.site_id,
  cpu_total:     props.item.cpu_total,
  mem_total_gb:  props.item.mem_total_gb,
  disk_total_tb: props.item.disk_total_tb,
  subnet_ids:    [...(props.item.subnet_ids ?? [])],
  status:        props.item.status ?? 'active',
})

// Cloud 切換時清空 subnet 選擇
watch(() => form.cloud, () => { form.subnet_ids = [] })

const cloudSubnets = computed(() => subnetsStore.byCloud(form.cloud))

const typeOpts = [
  { value: 'dedicated', label: 'Dedicated', color: 'ded' },
  { value: 'shared',    label: 'Shared',    color: 'shr' },
]
const envOpts = [
  { value: 'Prod', label: 'Prod', color: 'grn' },
  { value: 'UAT',  label: 'UAT',  color: 'pur' },
]

const error = ref('')

function save() {
  error.value = ''
  if (!form.id.trim())   { error.value = '請填寫 Pool ID';   return }
  if (!form.name.trim()) { error.value = '請填寫 Pool 名稱'; return }
  if (!form.site_id.trim()) { error.value = '請填寫 Site';   return }
  emit('save', { ...form })
}
</script>

<style scoped>
@reference "../../assets/main.css";
.field-label { @apply text-[11px] font-semibold text-ink-2; }
.field-input  { @apply border border-bord rounded-[6px] px-3 py-2 text-xs outline-none focus:border-or focus:ring-1 transition-all w-full; }
</style>
