import { defineStore } from 'pinia'
import { ref, computed } from 'vue'
import allocsData from '@data/allocations.json'
import { allocationsApi } from '../api/allocations'
import { useProjectsStore } from './projects'
import { useSystemsStore }  from './systems'

const USE_MOCK = import.meta.env.VITE_USE_MOCK !== 'false'

export const useAllocationsStore = defineStore('allocations', () => {
  const allocations = ref([])
  const loading     = ref(false)
  const error       = ref(null)

  async function init() {
    if (allocations.value.length) return
    loading.value = true
    error.value   = null
    try {
      allocations.value = USE_MOCK ? allocsData : await allocationsApi.list()
    } catch (e) {
      error.value = e.message
    } finally {
      loading.value = false
    }
  }

  // join project_id / system_id → 顯示名稱（頁面層不自行換算）
  const allocsWithNames = computed(() => {
    const projectsStore = useProjectsStore()
    const systemsStore  = useSystemsStore()
    return allocations.value.map(a => ({
      ...a,
      projectName: projectsStore.projects.find(p => p.id === a.project_id)?.name ?? a._project ?? a.project_id ?? '—',
      systemName:  systemsStore.systems.find(s => s.id === a.system_id)?.name   ?? a._system  ?? a.system_id  ?? '—',
    }))
  })

  function byPool(poolId) {
    return allocsWithNames.value.filter(a => a.pool_id === poolId)
  }

  async function addAllocation(data) {
    const created = USE_MOCK ? data : await allocationsApi.create(data)
    allocations.value.push(created)
  }

  async function updateAllocation(data) {
    if (!USE_MOCK) await allocationsApi.update(data.id, data)
    const i = allocations.value.findIndex(a => a.id === data.id)
    if (i !== -1) allocations.value[i] = { ...allocations.value[i], ...data }
  }

  async function deleteAllocation(id) {
    if (!USE_MOCK) await allocationsApi.delete(id)
    allocations.value = allocations.value.filter(a => a.id !== id)
  }

  return { allocations, loading, error, allocsWithNames, byPool, init, addAllocation, updateAllocation, deleteAllocation }
})
