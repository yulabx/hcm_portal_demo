<template>
  <div class="h-full flex flex-col">
    <!-- Page header -->
    <div class="px-8 py-4 bg-white border-b border-bord flex-shrink-0 flex items-center justify-between">
      <div>
        <h1 class="text-sm font-bold text-ink">配額管理</h1>
        <p class="text-[11px] text-ink-4 mt-0.5 font-mono">Shared Pool 配額 + 待執行申請</p>
      </div>
      <!-- Tab switcher -->
      <div class="flex border border-bord rounded-[6px] overflow-hidden text-xs font-semibold">
        <button
          class="tab-btn px-3.5 py-1.5 transition-colors"
          :class="activeTab === 'pools' ? 'bg-or text-white' : 'bg-white text-ink-3 hover:bg-surf-2'"
          @click="activeTab = 'pools'"
        >Pool 配額</button>
        <button
          class="tab-btn px-3.5 py-1.5 transition-colors"
          :class="activeTab === 'requests' ? 'bg-or text-white' : 'bg-white text-ink-3 hover:bg-surf-2'"
          @click="activeTab = 'requests'"
        >
          待執行申請
          <span v-if="pendingReqs.length" class="ml-1 bg-or text-white text-[9px] font-bold px-1.5 py-0.5 rounded-full" :class="activeTab === 'requests' ? 'bg-white text-or' : ''">
            {{ pendingReqs.length }}
          </span>
        </button>
      </div>
    </div>

    <div class="flex-1 overflow-auto p-8">

      <!-- ── Tab: Pool 配額 ── -->
      <div v-show="activeTab === 'pools'" class="max-w-[1100px] mx-auto">
        <AllocKpiStrip
          :shared-pool-count="sharedPools.length"
          :alloc-count="allocsStore.allocations.filter(a => a.status === 'active').length"
          :pending-count="pendingReqs.length"
          :over-count="overCount"
        />
        <div class="flex flex-col gap-6">
          <SharedPoolCard
            v-for="pool in sharedPools"
            :key="pool.id"
            :pool="pool"
            :allocs="allocsStore.byPool(pool.id)"
            @add="openAdd(pool)"
            @edit="openEdit"
            @remove="confirmRemove"
          />
          <div v-if="!sharedPools.length" class="py-16 text-center text-xs text-ink-4">
            目前沒有 Shared Pool
          </div>
        </div>
      </div>

      <!-- ── Tab: 待執行申請 ── -->
      <div v-show="activeTab === 'requests'" class="max-w-[860px] mx-auto">
        <div class="mb-5">
          <div class="text-sm font-bold text-ink">待執行申請</div>
          <div class="text-[11px] text-ink-4 mt-0.5">審閱申請內容，設定 Shared Pool 配額後執行開通</div>
        </div>
        <div v-if="!pendingReqs.length" class="bg-white border border-bord rounded-[10px] shadow-sm flex flex-col items-center justify-center py-16 text-ink-4">
          <div class="text-4xl mb-3 opacity-25">✅</div>
          <div class="text-sm font-semibold text-ink-3">目前沒有待執行的申請</div>
        </div>
        <div v-else class="flex flex-col gap-4">
          <PendingReqCard
            v-for="req in pendingReqs" :key="req.id"
            :req="req"
            :shared-pools="sharedPools"
            @set-alloc="openFromReq"
            @execute="executeReq"
          />
        </div>
      </div>

    </div>

    <!-- Alloc modal -->
    <AddAllocModal
      v-model="modalOpen"
      :pool="modalPool"
      :all-allocs="allocsStore.allocations"
      :edit-alloc="editAlloc"
      :prefill="modalPrefill"
      @save="handleSave"
    />
  </div>
</template>

<script setup>
import { ref, computed } from 'vue'
import { usePoolsStore }       from '../stores/pools'
import { useAllocationsStore } from '../stores/allocations'
import { useConfirm }          from '../composables/useConfirm'
import { useToast }            from '../composables/useToast'
import AllocKpiStrip  from '../components/allocation/AllocKpiStrip.vue'
import SharedPoolCard from '../components/allocation/SharedPoolCard.vue'
import AddAllocModal  from '../components/allocation/AddAllocModal.vue'
import PendingReqCard from '../components/allocation/PendingReqCard.vue'

const poolsStore  = usePoolsStore()
const allocsStore = useAllocationsStore()
const { confirm }        = useConfirm()
const { show: showToast } = useToast()

// ── Tabs ──────────────────────────────────────────────
const activeTab = ref('pools')

// ── Shared pools ──────────────────────────────────────
const sharedPools = computed(() =>
  poolsStore.poolsWithUsed.filter(p => p.type === 'shared')
)

// ── KPI: over-capacity pools ──────────────────────────
const overCount = computed(() =>
  sharedPools.value.filter(pool => {
    const allocs = allocsStore.byPool(pool.id)
    const usedCpu = allocs.reduce((s, a) => s + (a.quota_cpu    ?? 0), 0)
    const usedMem = allocs.reduce((s, a) => s + (a.quota_mem_gb ?? 0), 0)
    const cpuPct  = pool.cpu.t ? Math.round(usedCpu / pool.cpu.t * 100) : 0
    const memPct  = pool.mem.t ? Math.round(usedMem / pool.mem.t * 100) : 0
    return cpuPct >= 85 || memPct >= 85
  }).length
)

// ── Pending requests (static demo data) ──────────────
const pendingReqs = ref([
  {
    id: 'REQ-20240322-003', project: '二科', applicant: '陳美玲', created: '2024-03-22',
    systems: [
      {
        name: 'Portal-v2', code: 'SYS-PORTAL2', env: 'Prod',
        mounts: [
          { pool_id: 'S02', est_cpu: 12, est_mem: 24, note: 'Portal 改版需求，需與現有 Portal 隔離', _done: false, _key: '0' },
        ],
      },
    ],
  },
  {
    id: 'REQ-20240325-004', project: '電發專案', applicant: '王大明', created: '2024-03-25',
    systems: [
      {
        name: 'DataHub', code: 'SYS-DH', env: 'Prod',
        mounts: [
          { pool_id: 'S01', est_cpu: 10, est_mem: 20, note: '資料整合平台', _done: false, _key: '0' },
          { pool_id: 'S02', est_cpu: 8,  est_mem: 16, note: 'DR 備援用途',  _done: false, _key: '1' },
        ],
      },
    ],
  },
])

// ── Modal state ───────────────────────────────────────
const modalOpen    = ref(false)
const modalPool    = ref(null)
const editAlloc    = ref(null)
const modalPrefill = ref(null)
// when triggered from a pending request, track it to mark mount done on save
const reqContext   = ref(null)

function openAdd(pool) {
  modalPool.value    = pool
  editAlloc.value    = null
  modalPrefill.value = null
  reqContext.value   = null
  modalOpen.value    = true
}

function openEdit(alloc) {
  modalPool.value    = sharedPools.value.find(p => p.id === alloc.pool_id) ?? null
  editAlloc.value    = alloc
  modalPrefill.value = null
  reqContext.value   = null
  modalOpen.value    = true
}

function openFromReq({ req, sys, mount }) {
  const pool = sharedPools.value.find(p => p.id === mount.pool_id) ?? null
  modalPool.value    = pool
  editAlloc.value    = null
  reqContext.value   = { req, sys, mount }
  modalPrefill.value = {
    systemName:  sys.name,
    projectName: req.project,
    env:         sys.env,
    cpu:         mount.est_cpu ?? '',
    mem:         mount.est_mem ?? '',
    disk:        '',
  }
  modalOpen.value = true
}

async function handleSave(data) {
  try {
    if (editAlloc.value) {
      await allocsStore.updateAllocation({ ...editAlloc.value, ...data })
      showToast(`已更新 ${data.systemName} 的配額`)
    } else {
      const newId = 'A' + String(Date.now()).slice(-4)
      await allocsStore.addAllocation({
        id:             newId,
        pool_id:        modalPool.value.id,
        project_id:     null,
        system_id:      null,
        _project:       data.projectName,
        _system:        data.systemName,
        env:            data.env,
        quota_cpu:      data.quota_cpu,
        quota_mem_gb:   data.quota_mem_gb,
        quota_disk_tb:  data.quota_disk_tb,
        status:         'active',
      })
      showToast(`已新增 ${data.systemName} 的 Allocation`)
      // Mark mount done if from pending req
      if (reqContext.value) {
        reqContext.value.mount._done = true
        checkReqComplete(reqContext.value.req)
      }
    }
  } catch (e) {
    showToast('操作失敗：' + e.message, true)
  }
}

function checkReqComplete(req) {
  const allShared = req.systems.flatMap(s =>
    s.mounts.filter(m => sharedPools.value.some(p => p.id === m.pool_id))
  )
  // If all done, auto-move to executed (remove from list) — or wait for manual "執行開通"
}

async function confirmRemove(alloc) {
  const ok = await confirm(
    `移除 Allocation — ${alloc.systemName}`,
    `將移除「${alloc.systemName}」在此 Pool 的配額（CPU ${alloc.quota_cpu}C · Mem ${alloc.quota_mem_gb}GB · Disk ${alloc.quota_disk_tb}TB），移除後系統將無法使用此 Pool 的資源。`
  )
  if (!ok) return
  try {
    await allocsStore.deleteAllocation(alloc.id)
    showToast(`已移除 ${alloc.systemName} 的 Allocation`)
  } catch (e) {
    showToast('刪除失敗：' + e.message, true)
  }
}

async function executeReq(req) {
  const ok = await confirm(
    '執行開通',
    `確認執行申請單「${req.id}」？開通後申請單將標記為完成，系統可開始使用已分配的資源。`
  )
  if (!ok) return
  const idx = pendingReqs.value.findIndex(r => r.id === req.id)
  if (idx !== -1) pendingReqs.value.splice(idx, 1)
  showToast(`申請單 ${req.id} 已執行開通`)
}
</script>

<style scoped>
@reference "../assets/main.css";
</style>
