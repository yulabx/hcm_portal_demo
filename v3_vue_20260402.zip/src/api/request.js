// 共用 fetch 包裝，串 API 時只改這一層
const BASE = import.meta.env.VITE_API_BASE ?? ''

export async function request(path, options = {}) {
  const { body, ...rest } = options
  const res = await fetch(`${BASE}${path}`, {
    headers: { 'Content-Type': 'application/json', ...rest.headers },
    ...rest,
    ...(body !== undefined ? { body: JSON.stringify(body) } : {}),
  })
  if (!res.ok) {
    const msg = await res.text().catch(() => res.statusText)
    throw new Error(`[${res.status}] ${msg}`)
  }
  return res.json()
}
