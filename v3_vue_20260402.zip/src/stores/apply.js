import { defineStore } from 'pinia'
import { ref } from 'vue'

export const useApplyStore = defineStore('apply', () => {
  // Step 1
  const selectedProject = ref(null)   // { id, name, dept, owner, isNew? }

  // Step 2
  const systems = ref([])             // [{ uid, name, code, envs: ['Prod','UAT'] }]

  // Step 3  { 'uid:env': { dedicated: poolId|null, shared: [{pool_id,est_cpu,est_mem,est_disk}] } }
  const poolMounts = ref({})

  // History (pre-seeded with demo data)
  const history = ref([
    { id: 'REQ-20240315-001', project: '電發專案', systems: ['ERP', 'CRM'], status: 'done',    created: '2024-03-15', note: 'ERP 系統上線需求' },
    { id: 'REQ-20240318-002', project: '一科',     systems: ['OA'],         status: 'done',    created: '2024-03-18', note: '' },
    { id: 'REQ-20240322-003', project: '二科',     systems: ['Portal'],     status: 'pending', created: '2024-03-22', note: '新系統申請' },
  ])

  const currentStep = ref(1)
  let _sysCounter = 0

  // ── System management ─────────────────────────────────
  function addSystem() {
    const uid = 'sys-' + (++_sysCounter)
    systems.value.push({ uid, name: '', code: '', envs: ['Prod'] })
    poolMounts.value[uid + ':Prod'] = { dedicated: null, shared: [] }
  }

  function removeSystem(uid) {
    const s = systems.value.find(x => x.uid === uid)
    if (s) (s.envs || []).forEach(env => delete poolMounts.value[`${uid}:${env}`])
    systems.value = systems.value.filter(x => x.uid !== uid)
  }

  function toggleEnv(uid, env, checked) {
    const s = systems.value.find(x => x.uid === uid)
    if (!s) return
    const key = `${uid}:${env}`
    if (checked) {
      if (!s.envs.includes(env)) s.envs.push(env)
      if (!poolMounts.value[key]) poolMounts.value[key] = { dedicated: null, shared: [] }
    } else {
      s.envs = s.envs.filter(e => e !== env)
      delete poolMounts.value[key]
    }
  }

  // ── Pool mount management ─────────────────────────────
  function setDedicated(key, poolId) {
    if (!poolMounts.value[key]) poolMounts.value[key] = { dedicated: null, shared: [] }
    poolMounts.value[key].dedicated = poolId || null
  }

  function addShared(key) {
    if (!poolMounts.value[key]) poolMounts.value[key] = { dedicated: null, shared: [] }
    poolMounts.value[key].shared.push({ pool_id: '', est_cpu: '', est_mem: '', est_disk: '' })
  }

  function removeShared(key, idx) {
    poolMounts.value[key].shared.splice(idx, 1)
  }

  function updateShared(key, idx, field, val) {
    poolMounts.value[key].shared[idx][field] = val
  }

  // ── Submit ────────────────────────────────────────────
  function submit() {
    const id = 'REQ-' + new Date().toISOString().slice(0, 10).replace(/-/g, '') + '-' +
      String(history.value.length + 1).padStart(3, '0')
    history.value.unshift({
      id,
      project: selectedProject.value?.name ?? '—',
      systems: systems.value.map(s => s.name || '(未命名)'),
      status: 'pending',
      created: new Date().toISOString().slice(0, 10),
      note: '',
    })
    const submittedId = id
    reset()
    return submittedId
  }

  function reset() {
    selectedProject.value = null
    systems.value = []
    poolMounts.value = {}
    currentStep.value = 1
    _sysCounter = 0
  }

  return {
    selectedProject, systems, poolMounts, history, currentStep,
    addSystem, removeSystem, toggleEnv,
    setDedicated, addShared, removeShared, updateShared,
    submit, reset,
  }
})
