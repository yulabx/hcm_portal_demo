// 容量三色警示：< 70% 綠色 / 70–84% 琥珀 / ≥ 85% 紅色

export function useCapacity() {
  function pct(used, total) {
    if (!total) return 0
    return Math.round((used / total) * 100)
  }

  function colorClass(used, total) {
    const p = pct(used, total)
    if (p >= 85) return { bar: 'bg-red',  text: 'text-red' }
    if (p >= 70) return { bar: 'bg-amb',  text: 'text-amb' }
    return           { bar: 'bg-shr',  text: 'text-shr' }
  }

  return { pct, colorClass }
}
