<template>
  <div class="h-full flex flex-col">
    <!-- Page header -->
    <div class="px-8 py-5 bg-white border-b border-bord flex-shrink-0">
      <h1 class="text-sm font-bold text-ink">專案總覽</h1>
      <p class="text-[11px] text-ink-4 mt-0.5 font-mono">依專案檢視所有雲端資源配置</p>
    </div>

    <div class="flex-1 overflow-auto px-8 py-6">

      <!-- Search + filter bar -->
      <div class="flex items-center gap-2.5 mb-5 flex-wrap">
        <div class="relative flex-1 min-w-[220px] max-w-[360px]">
          <span class="absolute left-2.5 top-1/2 -translate-y-1/2 text-sm text-ink-4 pointer-events-none">🔍</span>
          <input
            v-model="searchQuery"
            type="text"
            placeholder="搜尋專案名稱或代碼…"
            class="w-full py-2.5 pr-3 pl-9 border border-bord rounded-[7px] text-sm text-ink bg-white transition-all outline-none focus:border-or focus:shadow-[0_0_0_2px_rgba(234,88,12,.12)]"
          />
        </div>
        <div class="flex gap-1.5 flex-wrap items-center">
          <span class="text-[13px] text-ink-4 font-semibold flex-shrink-0">篩選：</span>
          <button
            v-for="f in filterOptions" :key="f.value"
            class="fchip flex items-center gap-1 px-[13px] py-1.5 rounded-full text-xs font-semibold cursor-pointer border transition-all"
            :class="activeFilter === f.value
              ? 'bg-ink border-ink text-white'
              : 'border-bord bg-white text-ink-3 hover:border-bord-2 hover:bg-surf-2'"
            @click="activeFilter = f.value"
          >
            <span class="w-1.5 h-1.5 rounded-full flex-shrink-0" :style="{ background: f.dot, opacity: .7 }" />
            {{ f.label }}
          </button>
        </div>
      </div>

      <!-- Project tabs -->
      <div class="border-b border-bord mb-5 relative">
        <div class="flex gap-0.5 overflow-x-auto pb-px">
          <button
            v-for="proj in visibleProjects" :key="proj.id"
            class="proj-tab flex items-center gap-[7px] px-[18px] py-[9px] text-[13px] font-semibold text-ink-3 cursor-pointer border-b-2 border-transparent whitespace-nowrap transition-all flex-shrink-0"
            :class="selectedProj === proj.id ? 'text-ink border-b-or' : ''"
            @click="selectedProj = proj.id"
          >
            <div class="w-1.5 h-1.5 rounded-[2px] flex-shrink-0" :style="{ background: projColor(proj.id) }" />
            {{ proj.name }}
            <span
              class="font-mono text-[9px] px-[5px] py-px rounded-[3px] border"
              :class="selectedProj === proj.id
                ? 'bg-or-l border-or-m text-or-d'
                : 'bg-surf-2 border-bord text-ink-3'"
            >{{ projPoolCount(proj.id) }} pools</span>
          </button>
          <div v-if="!visibleProjects.length" class="px-4 py-3 text-xs text-ink-4">
            無符合條件的專案
          </div>
        </div>
      </div>

      <!-- Sub-view toggle -->
      <div class="flex bg-surf-2 border border-bord rounded-[7px] overflow-hidden mb-5 p-[3px] gap-0.5" style="max-width:360px">
        <button
          class="stab flex-1 px-4 py-2 text-[13px] font-semibold rounded-[5px] transition-all text-center cursor-pointer"
          :class="subView === 'cloud' ? 'bg-white text-ink shadow-sm' : 'bg-transparent text-ink-3'"
          @click="subView = 'cloud'"
        >☁ Cloud / Site</button>
        <button
          class="stab flex-1 px-4 py-2 text-[13px] font-semibold rounded-[5px] transition-all text-center cursor-pointer"
          :class="subView === 'sys' ? 'bg-white text-ink shadow-sm' : 'bg-transparent text-ink-3'"
          @click="subView = 'sys'"
        >⚙ 依系統</button>
      </div>

      <!-- Views -->
      <CloudViewPanel
        v-show="subView === 'cloud'"
        :cloud-view="currentProjData.cloudView"
        :pool-vms="poolVmsMap"
        :pool-allocs="poolAllocsMap"
        :filter="activeFilter"
      />
      <SysViewPanel
        v-show="subView === 'sys'"
        :sys-view="currentProjData.sysView"
      />

    </div>
  </div>
</template>

<script setup>
import { ref, computed } from 'vue'
import { useProjectsStore }    from '../stores/projects'
import { useSystemsStore }     from '../stores/systems'
import { usePoolsStore }       from '../stores/pools'
import { useVmsStore }         from '../stores/vms'
import { useAllocationsStore } from '../stores/allocations'
import CloudViewPanel from '../components/proj/CloudViewPanel.vue'
import SysViewPanel   from '../components/proj/SysViewPanel.vue'

const projectsStore = useProjectsStore()
const systemsStore  = useSystemsStore()
const poolsStore    = usePoolsStore()
const vmsStore      = useVmsStore()
const allocsStore   = useAllocationsStore()

// ── UI state ──────────────────────────────────────────
const searchQuery  = ref('')
const activeFilter = ref('all')
const subView      = ref('cloud')
const selectedProj = ref(null)

const filterOptions = [
  { value: 'all',       label: '全部',      dot: 'currentColor' },
  { value: 'dedicated', label: 'Dedicated', dot: '#2563eb'      },
  { value: 'shared',    label: 'Shared',    dot: '#0d9488'      },
  { value: 'prod',      label: 'Prod',      dot: '#16a34a'      },
  { value: 'uat',       label: 'UAT',       dot: '#7c3aed'      },
]

// ── Static meta ───────────────────────────────────────
const CLOUD_META = {
  private: { label: '私有雲', color: '#2563eb' },
  hicloud: { label: 'hiCloud', color: '#0e7490' },
  aws:     { label: 'AWS',     color: '#b45309' },
}
const SITE_META = {
  'tp-main': { name: '台北主中心',   type: 'main' },
  'tc-dr':   { name: '台中異備中心', type: 'dr'   },
  'e7-main': { name: '東七主中心',   type: 'main' },
  'tw-main': { name: '台灣主中心',   type: 'main' },
}
const SYS_ICON = { 'SYS-001': '⚡', 'SYS-002': '📱' }
const PROJ_COLORS = ['#2563eb', '#0d9488', '#b45309', '#7c3aed', '#dc2626']

// ── Projects (filtered by search) ────────────────────
const visibleProjects = computed(() => {
  const q = searchQuery.value.trim().toLowerCase()
  return projectsStore.projects.filter(p =>
    !q || p.name.toLowerCase().includes(q) || (p.code ?? '').toLowerCase().includes(q)
  )
})

// Auto-select first project
const firstProjId = computed(() => visibleProjects.value[0]?.id ?? null)
const effectiveProj = computed(() => {
  if (selectedProj.value && visibleProjects.value.some(p => p.id === selectedProj.value))
    return selectedProj.value
  return firstProjId.value
})

function projColor(projId) {
  const idx = projectsStore.projects.findIndex(p => p.id === projId)
  return PROJ_COLORS[idx % PROJ_COLORS.length]
}

// ── Pool lookup maps (for MiniPoolCard) ───────────────
const poolVmsMap = computed(() =>
  Object.fromEntries(
    poolsStore.poolsWithUsed.map(p => [p.id, vmsStore.byPool(p.id)])
  )
)
const poolAllocsMap = computed(() =>
  Object.fromEntries(
    poolsStore.poolsWithUsed.map(p => [p.id, allocsStore.byPool(p.id)])
  )
)

// ── Per-project pool count (for tab badge) ────────────
function projPoolCount(projId) {
  const proj = projectsStore.projects.find(p => p.id === projId)
  if (!proj) return 0
  const dedPools  = poolsStore.pools.filter(p => p.project_id === projId)
  const projAllocs = allocsStore.allocations.filter(a => a.project_id === projId)
  const shrPoolIds = [...new Set(projAllocs.map(a => a.pool_id))]
  return dedPools.length + shrPoolIds.length
}

// ── Build cloudView / sysView for current project ─────
const currentProjData = computed(() => {
  const projId = effectiveProj.value
  if (!projId) return { cloudView: {}, sysView: {} }

  const projectMap = Object.fromEntries(projectsStore.projects.map(p => [p.id, p]))
  const systemMap  = Object.fromEntries(systemsStore.systems.map(s  => [s.id, s]))

  const projAllocs  = allocsStore.allocations.filter(a => a.project_id === projId)
  const dedPools    = poolsStore.pools.filter(p => p.project_id === projId)
  const shrPoolIds  = [...new Set(projAllocs.map(a => a.pool_id))]
  const shrPools    = poolsStore.pools.filter(p => shrPoolIds.includes(p.id))
  const allPools    = [...dedPools, ...shrPools]

  const cloudView = {}
  const sysView   = {}

  for (const pool of allPools) {
    const ck  = pool.cloud
    const sm  = SITE_META[pool.site_id] ?? { name: pool.site_id, type: 'main' }
    const cm  = CLOUD_META[ck] ?? { label: ck, color: '#0f0f0f' }

    let sysName
    if (pool.type === 'shared') {
      const alloc = projAllocs.find(a => a.pool_id === pool.id)
      sysName = systemMap[alloc?.system_id]?.name ?? alloc?.system_id ?? '—'
    } else {
      sysName = systemMap[pool.system_id]?.name ?? pool.system_id ?? '—'
    }

    // cloudView
    if (!cloudView[ck]) cloudView[ck] = { label: cm.label, color: cm.color, sites: [] }
    let site = cloudView[ck].sites.find(s => s.name === sm.name)
    if (!site) {
      site = { name: sm.name, type: sm.type, pools: [] }
      cloudView[ck].sites.push(site)
    }
    site.pools.push({ id: pool.id, name: pool.name, type: pool.type, env: pool.env, sys: sysName })

    // sysView
    if (!sysView[sysName]) sysView[sysName] = { icon: SYS_ICON[pool.system_id] ?? '🗂', pools: [] }
    sysView[sysName].pools.push({
      id:    pool.id,
      cloud: cm.label,
      site:  sm.name,
      env:   pool.env,
      type:  pool.type,
    })
  }

  return { cloudView, sysView }
})
</script>

<style scoped>
@reference "../assets/main.css";
.border-b-or { border-bottom-color: #ea580c; }
</style>
