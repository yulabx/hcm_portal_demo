<template>
  <div
    class="bg-white border border-bord rounded-[8px] p-[18px] pl-[22px] cursor-pointer shadow-sm relative overflow-hidden transition-all duration-200 hover:-translate-y-0.5 hover:border-bord-2 hover:shadow-md"
    :class="{
      'opacity-30 !shadow-sm !translate-y-0 pointer-events-none': dim,
      '!border-bord-2 shadow-lg': selected,
    }"
    :style="{ '--sc-bar': accentColor }"
    @click="$emit('drill', site.id)"
  >
    <!-- Left accent bar -->
    <div class="absolute top-0 left-0 bottom-0 w-[3px] rounded-l-[8px]" :style="{ background: accentColor }" />

    <!-- Top row -->
    <div class="flex items-start justify-between mb-2">
      <div>
        <div class="text-sm font-bold text-ink">{{ site.name }}</div>
        <div class="text-[10px] text-ink-4 font-mono mt-0.5">{{ site.region }}</div>
      </div>
      <span
        class="text-[9px] font-bold uppercase px-1.5 py-0.5 rounded-[3px] border"
        :class="site.type === 'main' ? 'bg-grn-l text-grn border-grn-m' : 'bg-red-l text-red border-red-m'"
      >{{ site.type === 'main' ? '主中心' : '異備 DR' }}</span>
    </div>

    <!-- Pool badges -->
    <div class="flex gap-1 flex-wrap mb-3">
      <span v-if="dedCount" class="badge-sm bg-ded-l text-ded border border-ded-m">Ded × {{ dedCount }}</span>
      <span v-if="shrCount" class="badge-sm bg-shr-l text-shr border border-shr-m">Shr × {{ shrCount }}</span>
    </div>

    <!-- Resource bars -->
    <div class="flex flex-col gap-[7px] mb-3">
      <ResourceBar label="CPU"    :used="site.cpu.u"  :total="site.cpu.t"  unit="C"  :color="accentColor" />
      <ResourceBar label="Memory" :used="site.mem.u"  :total="site.mem.t"  unit="GB" color="#0d9488" />
      <ResourceBar label="Disk"   :used="site.disk.u" :total="site.disk.t" unit="TB" color="#2563eb" />
    </div>

    <!-- Meta row -->
    <div class="flex items-center gap-4 text-[10px] text-ink-4 font-mono border-t border-bord pt-2.5">
      <span>🗄 <span class="font-semibold text-ink-3">{{ site.pools.length }}</span> Pools</span>
      <span>🖥 <span class="font-semibold text-ink-3">{{ vmCount }}</span> VMs</span>
    </div>
  </div>
</template>

<script setup>
import { computed } from 'vue'
import ResourceBar from './ResourceBar.vue'

const props = defineProps({
  site:     { type: Object, required: true },
  poolsMap: { type: Object, required: true },  // poolId → pool object
  selected: { type: Boolean, default: false },
  dim:      { type: Boolean, default: false },
})
defineEmits(['drill'])

const accentColor = computed(() => props.site.type === 'main' ? '#16a34a' : '#dc2626')
const dedCount    = computed(() => props.site.pools.filter(id => props.poolsMap[id]?.type === 'dedicated').length)
const shrCount    = computed(() => props.site.pools.filter(id => props.poolsMap[id]?.type === 'shared').length)
const vmCount     = computed(() => props.site.pools.reduce((s, id) => s + (props.poolsMap[id]?.vmCount ?? 0), 0))
</script>

<style scoped>
@reference "../../assets/main.css";
.badge-sm { @apply text-[9px] font-bold px-1.5 py-0.5 rounded-[3px]; }
</style>
