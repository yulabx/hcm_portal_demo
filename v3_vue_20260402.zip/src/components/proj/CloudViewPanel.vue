<template>
  <div class="flex flex-col gap-3.5">
    <div
      v-for="(cd, ck) in cloudView" :key="ck"
      class="border border-bord rounded-[8px] overflow-hidden shadow-sm"
    >
      <!-- Cloud header -->
      <div class="flex items-center gap-2.5 px-4 py-[11px] border-b border-bord bg-surf-2">
        <div class="w-2.5 h-2.5 rounded-[2px]" :style="{ background: cd.color }" />
        <span class="text-[15px] font-bold tracking-[-0.01em]">{{ cd.label }}</span>
        <span class="ml-auto text-[12px] text-ink-4 font-mono">{{ totalPools(cd) }} pools</span>
      </div>

      <!-- Sites -->
      <div>
        <div v-for="(site, si) in cd.sites" :key="si" class="border-b border-bord last:border-b-0">
          <!-- Site header -->
          <div class="flex items-center gap-2 px-4 py-[10px]">
            <span
              class="text-[9px] font-bold uppercase tracking-wide px-1.5 py-0.5 rounded-[3px] border"
              :class="site.type === 'main' ? 'bg-grn-l text-grn border-grn-m' : 'bg-red-l text-red border-red-m'"
            >{{ site.type === 'main' ? '主中心' : '異備 DR' }}</span>
            <span class="text-[13px] font-semibold ml-2">{{ site.name }}</span>
            <span class="ml-auto text-[12px] text-ink-4 font-mono">{{ site.pools.length }} pools</span>
          </div>

          <!-- Mini pool cards grid -->
          <div class="px-4 pb-0 pl-10">
            <div class="grid gap-2.5" style="grid-template-columns: repeat(2, minmax(0,1fr))">
              <MiniPoolCard
                v-for="pool in filteredPools(site.pools)" :key="pool.id"
                :pool-id="pool.id"
                :pool-name="pool.name"
                :type="pool.type"
                :env="pool.env"
                :sys-name="pool.sys"
                :item-count="pool.type === 'dedicated'
                  ? (poolVms[pool.id]?.length ?? 0)
                  : (poolAllocs[pool.id]?.length ?? 0)"
                :open="openPoolKey === siteKey(ck, si) && openPoolId === pool.id"
                @toggle="togglePool(ck, si, $event)"
              />
            </div>
            <div v-if="filteredPools(site.pools).length === 0" class="text-xs text-ink-4 py-3">
              此站點在目前篩選條件下無 Pool
            </div>
          </div>

          <!-- Expand panel — full width, AFTER the grid -->
          <div
            v-if="openPoolKey === siteKey(ck, si) && openPoolId"
            class="mx-4 ml-10 mb-3.5 mt-2 border-l-[3px] border-or bg-surf-2 border border-bord rounded-b-[6px]"
          >
            <!-- Panel header -->
            <div class="flex items-center justify-between px-5 py-2.5 bg-or-l border-b border-bord">
              <span class="text-[11px] font-bold uppercase tracking-[.1em] text-or-d flex items-center gap-2">
                {{ openPool?.type === 'dedicated' ? '🖥 VM 清單' : '🔗 申請狀況' }}
                <span class="text-[9px] font-semibold px-1.5 py-0.5 rounded-[3px] bg-or-m/50 text-or-d">
                  {{ openItemCount }} 筆 · {{ openPoolId }} {{ openPool?.name }}
                </span>
              </span>
              <button
                class="text-[11px] font-semibold text-ink-3 border border-bord bg-white px-2 py-1 rounded-[4px] hover:border-or hover:text-or transition-all cursor-pointer"
                @click="openPoolId = null; openPoolKey = null"
              >✕ 收起</button>
            </div>

            <!-- VM table -->
            <div v-if="openPool?.type === 'dedicated'" class="overflow-x-auto px-5 pb-4">
              <table class="w-full text-xs border-collapse mt-3.5">
                <thead>
                  <tr class="border-b-2 border-bord">
                    <th class="th">VM 名稱</th>
                    <th class="th">狀態</th>
                    <th class="th">規格 (vCPU / RAM / Disk)</th>
                    <th class="th">環境</th>
                    <th class="th">IP 位址</th>
                  </tr>
                </thead>
                <tbody>
                  <tr
                    v-for="v in openVms" :key="v.id"
                    class="border-b border-bord hover:bg-or-l/30 transition-colors"
                  >
                    <td class="td">
                      <span class="dot" :class="v.status === 'running' ? 'dot-run' : 'dot-stop'" />
                      <span class="font-mono text-[11px] font-semibold">{{ v.name }}</span>
                    </td>
                    <td class="td">
                      <span class="badge-s" :class="v.status === 'running' ? 'bg-grn-l text-grn border-grn-m' : 'bg-surf-2 text-ink-3 border-bord'">
                        {{ v.status === 'running' ? 'Running' : 'Stopped' }}
                      </span>
                    </td>
                    <td class="td font-mono text-[11px] text-ink-2 whitespace-nowrap">
                      {{ v.vcpu }} vCPU · {{ fmtGB(v.ram_gb) }} · {{ fmtGB(v.disk_gb) }}
                    </td>
                    <td class="td">
                      <span class="badge-s" :class="(v.tags?.env || openPool?.env) === 'Prod' ? 'bg-ded-l text-ded border-ded-m' : 'bg-pur-l text-pur border-pur-m'">
                        {{ v.tags?.env || openPool?.env }}
                      </span>
                    </td>
                    <td class="td font-mono text-[11px] text-ink-3">{{ v.ip || '—' }}</td>
                  </tr>
                  <tr v-if="!openVms.length">
                    <td colspan="5" class="td text-center text-ink-4 py-6">尚無 VM</td>
                  </tr>
                </tbody>
              </table>
            </div>

            <!-- Alloc table -->
            <div v-else class="overflow-x-auto px-5 pb-4">
              <table class="w-full text-xs border-collapse mt-3.5">
                <thead>
                  <tr class="border-b-2 border-bord">
                    <th class="th">專案</th>
                    <th class="th">系統</th>
                    <th class="th">環境</th>
                    <th class="th">CPU 配額</th>
                    <th class="th">Memory 配額</th>
                  </tr>
                </thead>
                <tbody>
                  <tr
                    v-for="a in openAllocs" :key="a.id"
                    class="border-b border-bord hover:bg-or-l/30 transition-colors"
                  >
                    <td class="td font-bold">{{ a.projectName }}</td>
                    <td class="td text-ink-3">{{ a.systemName }}</td>
                    <td class="td">
                      <span class="badge-s" :class="a.env === 'Prod' ? 'bg-ded-l text-ded border-ded-m' : 'bg-pur-l text-pur border-pur-m'">{{ a.env }}</span>
                    </td>
                    <td class="td font-mono text-ink-2">{{ a.quota_cpu }}C</td>
                    <td class="td font-mono text-ink-2">{{ a.quota_mem_gb }}GB</td>
                  </tr>
                  <tr v-if="!openAllocs.length">
                    <td colspan="5" class="td text-center text-ink-4 py-6">尚無 Allocation</td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>

        </div>
      </div>
    </div>

    <div v-if="!Object.keys(cloudView).length" class="py-12 text-center text-xs text-ink-4">
      此專案尚無資源
    </div>
  </div>
</template>

<script setup>
import { ref, computed } from 'vue'
import MiniPoolCard from './MiniPoolCard.vue'

const props = defineProps({
  cloudView:  { type: Object, default: () => ({}) },
  poolVms:    { type: Object, default: () => ({}) },
  poolAllocs: { type: Object, default: () => ({}) },
  filter:     { type: String, default: 'all' },
})

// ── Open state: one panel open at a time globally ─────
const openPoolKey = ref(null)  // siteKey string
const openPoolId  = ref(null)  // pool.id string

function siteKey(ck, si) { return `${ck}-${si}` }

function togglePool(ck, si, poolId) {
  const key = siteKey(ck, si)
  if (openPoolKey.value === key && openPoolId.value === poolId) {
    openPoolKey.value = null
    openPoolId.value  = null
  } else {
    openPoolKey.value = key
    openPoolId.value  = poolId
  }
}

// Find the pool object for the open panel
const openPool = computed(() => {
  if (!openPoolId.value) return null
  for (const cd of Object.values(props.cloudView)) {
    for (const site of cd.sites) {
      const found = site.pools.find(p => p.id === openPoolId.value)
      if (found) return found
    }
  }
  return null
})

const openVms      = computed(() => props.poolVms[openPoolId.value]    ?? [])
const openAllocs   = computed(() => props.poolAllocs[openPoolId.value] ?? [])
const openItemCount = computed(() =>
  openPool.value?.type === 'dedicated' ? openVms.value.length : openAllocs.value.length
)

// ── Helpers ───────────────────────────────────────────
function totalPools(cd) {
  return cd.sites.reduce((s, site) => s + site.pools.length, 0)
}

function filteredPools(pools) {
  if (props.filter === 'all')       return pools
  if (props.filter === 'dedicated') return pools.filter(p => p.type === 'dedicated')
  if (props.filter === 'shared')    return pools.filter(p => p.type === 'shared')
  if (props.filter === 'prod')      return pools.filter(p => p.env === 'Prod')
  if (props.filter === 'uat')       return pools.filter(p => p.env === 'UAT')
  return pools
}

function fmtGB(gb) { return gb >= 1024 ? +(gb / 1024).toFixed(1) + ' TB' : gb + ' GB' }
</script>

<style scoped>
@reference "../../assets/main.css";
.th       { @apply px-3 py-2.5 text-left text-[10px] font-bold uppercase tracking-[.1em] text-ink-4 whitespace-nowrap bg-white; }
.td       { @apply px-3 py-2.5; }
.dot      { @apply inline-block w-1.5 h-1.5 rounded-full mr-1.5 align-middle; }
.dot-run  { @apply bg-grn; box-shadow: 0 0 4px rgba(34,197,94,.5); }
.dot-stop { @apply bg-bord-2; }
.badge-s  { @apply text-[10px] font-bold px-1.5 py-0.5 rounded-[3px] border; }
</style>
