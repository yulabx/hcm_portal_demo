import { defineStore } from 'pinia'
import { ref, computed } from 'vue'
import projectsData from '@data/projects.json'
import { projectsApi } from '../api/projects'

const USE_MOCK = import.meta.env.VITE_USE_MOCK !== 'false'

export const useProjectsStore = defineStore('projects', () => {
  const projects = ref([])
  const loading  = ref(false)
  const error    = ref(null)

  async function init() {
    if (projects.value.length) return
    loading.value = true
    error.value   = null
    try {
      projects.value = USE_MOCK ? projectsData : await projectsApi.list()
    } catch (e) {
      error.value = e.message
    } finally {
      loading.value = false
    }
  }

  const projectMap = computed(() =>
    Object.fromEntries(projects.value.map(p => [p.id, p]))
  )

  function findById(id) {
    return projectMap.value[id] ?? null
  }

  async function addProject(data) {
    const created = USE_MOCK ? data : await projectsApi.create(data)
    projects.value.push(created)
  }

  async function updateProject(data) {
    if (!USE_MOCK) await projectsApi.update(data.id, data)
    const i = projects.value.findIndex(p => p.id === data.id)
    if (i !== -1) projects.value[i] = { ...projects.value[i], ...data }
  }

  return { projects, loading, error, projectMap, findById, init, addProject, updateProject }
})
