<template>
  <div class="flex flex-col gap-4">

    <!-- Filter chips -->
    <div class="flex items-center gap-2">
      <button
        v-for="opt in filterOpts" :key="opt.val"
        class="text-xs font-semibold px-3 py-1.5 rounded-full border transition-all"
        :class="filter === opt.val ? 'bg-ink text-white border-ink' : 'bg-white text-ink-3 border-bord hover:bg-surf-2'"
        @click="filter = opt.val"
      >{{ opt.label }}</button>
    </div>

    <!-- History list -->
    <div class="flex flex-col gap-3">
      <div
        v-for="(h, i) in filteredHistory" :key="h.id"
        class="bg-white border border-bord rounded-[10px] shadow-sm p-5 flex items-start gap-4"
        :style="{ animationDelay: i * 30 + 'ms' }"
      >
        <div
          class="w-9 h-9 rounded-[8px] flex items-center justify-center flex-shrink-0 text-lg"
          :class="h.status === 'done' ? 'bg-grn-l' : 'bg-amb-l'"
        >{{ h.status === 'done' ? '✅' : '⏳' }}</div>

        <div class="flex-1 min-w-0">
          <div class="flex items-center gap-2 flex-wrap">
            <span class="font-mono text-xs font-bold text-ink">{{ h.id }}</span>
            <span
              class="text-[9px] font-bold uppercase tracking-wide px-1.5 py-0.5 rounded-[3px] border"
              :class="h.status === 'done' ? 'bg-grn-l text-grn border-grn-m' : 'bg-amb-l text-amb border-amb-m'"
            >{{ h.status === 'done' ? '已完成' : '待執行' }}</span>
          </div>
          <div class="text-xs font-semibold text-ink mt-1">{{ h.project }}</div>
          <div class="text-[11px] text-ink-4 mt-0.5">系統：{{ h.systems.join('、') }}</div>
          <div v-if="h.note" class="text-[11px] text-ink-3 mt-0.5 italic">{{ h.note }}</div>
        </div>

        <div class="text-[10px] text-ink-4 font-mono flex-shrink-0">{{ h.created }}</div>
      </div>

      <div v-if="!filteredHistory.length" class="text-center py-16 text-ink-4 text-xs">
        沒有符合的申請記錄
      </div>
    </div>

  </div>
</template>

<script setup>
import { ref, computed } from 'vue'
import { useApplyStore } from '../../stores/apply'

const applyStore = useApplyStore()

const filter = ref('all')
const filterOpts = [
  { val: 'all',     label: '全部' },
  { val: 'pending', label: '待執行' },
  { val: 'done',    label: '已完成' },
]

const filteredHistory = computed(() =>
  applyStore.history.filter(h => filter.value === 'all' || h.status === filter.value)
)
</script>

<style scoped>
@reference "../../assets/main.css";
</style>
