import { request } from './request'

export const allocationsApi = {
  list:   ()         => request('/api/allocations'),
  create: (data)     => request('/api/allocations',       { method: 'POST',   body: data }),
  update: (id, data) => request(`/api/allocations/${id}`, { method: 'PUT',    body: data }),
  delete: (id)       => request(`/api/allocations/${id}`, { method: 'DELETE' }),
}
